const mongoose = require('mongoose');

const usuario = mongoose.Schema({
    nome_usuario: { type: String },
    senha: { type: String },
    email: { type: String },
    instagram: { type: String },
    apikey: { type: String },
    defaultKey: { type: String },
    premium: { type: String },
    banido: { type: String },    
    motivo_ban: { type: String },
    admin: { type: String },
    limit: { type: Number },
    totalreq: { type: Number },
    status: { type: String },
    resgatar: { type: String },
    valoresgatar: { type: Number },
    musica: { type: String },
    perfil: { type: String },    
    jid: { type: String },
    numero_zap: { type: String },
    dinheiro: { type: Number },
    exp: { type: Number },
    nivel: { type: Number },
    bronze: { type: Number },
    prata: { type: Number },
    ouro: { type: Number },
    diamante: { type: Number }
}, { versionKey: false });
module.exports.usuario = mongoose.model('ayu', usuario);

const mensagemSchema = new mongoose.Schema({
  texto: { type: String, required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuário' },
  criadoEm: { type: Date, default: Date.now }
});

module.exports.mensagemSchema = mongoose.model('mensagemSchema', mensagemSchema);

const blockedIPs = new mongoose.Schema({
  ip: { type: String, required: true }
}, { versionKey: false });

module.exports.blockedIPs = mongoose.model('blockedIPs', blockedIPs);

const ig = mongoose.Schema({
    nome: { type: String },
    senha: { type: String }
}, { versionKey: false });
module.exports.ig = mongoose.model('contasig', ig);


const Utils = mongoose.Schema({
    total: { type: Number },
    today: { type: Number },
    visitor: { type: Number },
    ia: { type: String },
    util: { type: String }
}, { versionKey: false });
module.exports.Utils = mongoose.model('util', Utils);
