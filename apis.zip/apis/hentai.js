__path = process.cwd()
const { verificaKey, limitAdd, isLimit, dinheiroadd, expfarm } = require('../backend/db')

const fs = require('fs')

const paramtroerro = __path + '/views/ErroLink.html' //400
const semapikey = __path + '/views/SemKey.html' //404
const semlimit = __path + '/views/SemLimit.html' //429

const { getBuffer , getRandom} = require("../func.backend/buff");

const { hentaiGeral, hentaivids } = require('../func.backend/api')


async function hentaimp4(req, res) {
 let apikey = req.query.apikey
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
hentaivids().then(result => {
res.json({
status: 'operando', 
admin: 'https://wa.me/5562936180708', 
resultado: result
})
}).catch(error => {
console.log(error);
res.json({
status: 'parado', 
admin: 'https://wa.me/5562936180708', 
resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
})
});
}

 
 async function ass(req, res) {
 	try {
 let apikey = req.query.apikey
 if (!apikey) return res.sendFile(paramtroerro)
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
hentaiGeral("ass").then(async resultado => {
//console.log(resultado)
buff = await getBuffer(resultado)
res.type('png')
res.send(buff)
})
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

 async function hentai(req, res) {
 	try {
 let apikey = req.query.apikey
 if (!apikey) return res.sendFile(paramtroerro)
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
hentaiGeral("hentai").then(async resultado => {
//console.log(resultado)
buff = await getBuffer(resultado)
res.type('png')
res.send(buff)
})
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

 async function milf(req, res) {
 	try {
 let apikey = req.query.apikey
 if (!apikey) return res.sendFile(paramtroerro)
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
hentaiGeral("milf").then(async resultado => {
//console.log(resultado)
buff = await getBuffer(resultado)
res.type('png')
res.send(buff)
})
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

 async function oral(req, res) {
 	try {
 let apikey = req.query.apikey
 if (!apikey) return res.sendFile(paramtroerro)
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
hentaiGeral("oral").then(async resultado => {
//console.log(resultado)
buff = await getBuffer(resultado)
res.type('png')
res.send(buff)
})
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

 async function paizuri(req, res) {
 	try {
 let apikey = req.query.apikey
 if (!apikey) return res.sendFile(paramtroerro)
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
hentaiGeral("paizuri").then(async resultado => {
//console.log(resultado)
buff = await getBuffer(resultado)
res.type('png')
res.send(buff)
})
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

 async function ecchi(req, res) {
 	try {
 let apikey = req.query.apikey
 if (!apikey) return res.sendFile(paramtroerro)
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
hentaiGeral("ecchi").then(async resultado => {
//console.log(resultado)
buff = await getBuffer(resultado)
res.type('png')
res.send(buff)
})
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

 async function ero(req, res) {
 	try {
 let apikey = req.query.apikey
 if (!apikey) return res.sendFile(paramtroerro)
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
hentaiGeral("ero").then(async resultado => {
//console.log(resultado)
buff = await getBuffer(resultado)
res.type('png')
res.send(buff)
})
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

module.exports = { 
ass,
hentai,
milf,
oral,
paizuri,
ecchi,
ero,
hentaimp4
}
