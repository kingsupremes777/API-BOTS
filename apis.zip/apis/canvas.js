__path = process.cwd()
const {
 verificaKey,
 limitAdd,
 isLimit,
 dinheiroadd,
 expfarm
} = require('../backend/db')

const fs = require('fs')
const { writeFile } = require('fs-extra')
const sayz = require("discord-card-canvas")
const { muzicard } = require("muzicard");

const paramtroerro = __path + '/views/ErroLink.html' //400
const semapikey = __path + '/views/SemKey.html' //404
const semlimit = __path + '/views/SemLimit.html' //429
const canvafy = require("canvafy");

const Cannvas = require("../func.backend/akame-welcome2");
const Caxinha = require('../func.backend/caixinha');
const adorartv = require('../func.backend/canvas/adorartv/adorartv');
const editcanvas = require('../func.backend/canvas/editcanvas/editcanvas');
const lolifofa = require('../func.backend/canvas/lolifofa/lolifofa');
const lolifofaa = require('../func.backend/canvas/lolifofaa/lolifofaa');
const lolipc = require('../func.backend/canvas/lolinopc/lolinopc');
const menubysayo = require('../func.backend/canvas/menubysayo/menubysayo');
const brasils = require('../func.backend/canvas/brasil/brasil');
const editvermelha = require('../func.backend/canvas/editvermelha/editvermelha');
const editbranca = require('../func.backend/canvas/editbranca/editbranca');
const tumulo = require('../func.backend/canvas/tumulo/tumulo');
const carinho = require('../func.backend/carinho');
const bvadeus = require('../func.backend/canvas/bemvindo/bemvindo');
const menudios = require('../func.backend/canvas/menu/menu');
const pingc = require('../func.backend/canvas/ping/ping');
const bvadeus2 = require('../func.backend/canvas/bemvindo2/bemvindo2');
const welkard = require('../func.backend/wel');
const sayofy = require('../func.backend/sayofy');
const { Card } = require("../func.backend/editco");
const Welcomer  = require("../func.backend/gifcome");
const { Zap } = require("../func.backend/zap");
const { Vasco } = require("../func.backend/vasco");

async function ping(req, res) {
try {
const apikey = req.query.apikey;
const avatar = req.query.avatar;
const wallpaper = req.query.wallpaper;
const cor1 = req.query.cor1;
const cor2 = req.query.cor2;
const usuario = req.query.usuario;
const infoping = req.query.infoping;
 if (avatar === undefined ||  wallpaper === undefined || cor1 === undefined || cor2 === undefined || usuario === undefined || infoping === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  const pingzera = await pingc(`${usuario}`, `${infoping}`, `${avatar}`,  `${wallpaper}`, `#${cor1}`, `#${cor2}`);
        res.type('png')
        res.send(pingzera)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function menudioss(req, res) {
try {
const apikey = req.query.apikey;
const avatar = req.query.avatar;
const fundo = req.query.fundo;
const cor1 = req.query.cor1;
const cor2 = req.query.cor2;
const cor3 = req.query.cor3;
const texto1 = req.query.texto1;
const texto2 = req.query.texto2;
 if (avatar === undefined ||  texto1 === undefined || texto2 === undefined || cor3 === undefined || cor1 === undefined || cor2 === undefined || fundo === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  const meudios = await menudios(`${avatar}`, `${fundo}`, `#${cor1}`,  `#${cor2}`, `#${cor3}`, `${texto1}`, `${texto2}`);
        res.type('png')
        res.send(meudios)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function bemvdadeus(req, res) {
try {
const apikey = req.query.apikey;
const img = req.query.img;
const img2 = req.query.img2;
const texto = req.query.texto;
const texto2 = req.query.texto2;
const texto3 = req.query.texto3;
const cor1 = req.query.cor1;
const cor2 = req.query.cor2;
const cor3 = req.query.cor3;
 if (img === undefined || img2 === undefined || texto === undefined || texto2 === undefined || texto3 === undefined || cor1 === undefined || cor2 === undefined || cor3 === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  const menusayoadeus = await bvadeus(`${img}`, `${img2}`, `${texto}`, `${texto2}`, `${texto3}`, `#${cor1}`, `#${cor2}`, `#${cor3}`);
        res.type('png')
        res.send(menusayoadeus)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function bemvdadeus2(req, res) {
try {
const apikey = req.query.apikey;
const img = req.query.img;
const img2 = req.query.img2;
const texto = req.query.texto;
const texto2 = req.query.texto2;
const texto3 = req.query.texto3;
const texto4 = req.query.texto4;
const cor1 = req.query.cor1;
const cor2 = req.query.cor2;
const fundo = req.query.fundo;
 if (img === undefined || img2 === undefined || texto === undefined || texto2 === undefined || texto3 === undefined || texto4 === undefined || cor1 === undefined || cor2 === undefined || fundo === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  const menusayoadeus = await bvadeus2(`${img}`, `${img2}`, `${fundo}`,  `${texto}`, `${texto2}`, `${texto3}`, `${texto4}`, `#${cor1}`, `#${cor2}`);
        res.type('png')
        res.send(menusayoadeus)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function menubysayoz(req, res) {
try {
const apikey = req.query.apikey;
const avatar = req.query.avatar;
const fundo = req.query.fundo;	
const cor1 = req.query.cor1;	
const cor2 = req.query.cor2;	
const cor3 = req.query.cor3;	
const nome = req.query.nome;	
const msg = req.query.msg;	
 if (avatar === undefined || apikey === undefined || fundo === undefined || cor1 === undefined || cor2 === undefined || cor3 === undefined || nome === undefined || msg === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  console.log(avatar,
  fundo,
  {
    cor1: '#' + cor1,
    cor2: '#' + cor2,
    cor3: '#' + cor3,
  },
  {
    nome1: nome ? nome : 'sem nome',
    nome2: msg ? msg : 'sem msg',
  })
  img = await menubysayo(
  avatar,
  fundo,
  {
    cor1: '#' + cor1,
    cor2: '#' + cor2,
    cor3: '#' + cor3,
  },
  {
    nome1: nome ? nome : 'sem nome',
    nome2: msg ? msg : 'sem msg',
  }
);
        res.type('png')
        res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function carinhor(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await carinho(`${image}`);
  res.type('gif')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function editcanva(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
const nick = req.query.nick;
 if (image === undefined || apikey === undefined || nick === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await editcanvas(`${image}`, `${nick}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function editred(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
const nick = req.query.nick;
 if (image === undefined || apikey === undefined || nick === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await editvermelha(`${image}`, `${nick}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function editwite(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
const nick = req.query.nick;
 if (image === undefined || apikey === undefined || nick === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await editbranca(`${image}`, `${nick}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}


async function brasil(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await brasils(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function interro(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await tumulo(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}


async function pcloli(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await lolipc(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function lolifofss(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await lolifofaa(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function lolifofs(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await lolifofa(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function adoratv(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await adorartv(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}
                
async function comunismo(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.comunism(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function bolsonaro(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.bolsonaro(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function affect(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.affect(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function beautiful(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.beautiful(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function blurr(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.blur(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function bnw(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.bnw(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function circle(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.circle(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function del(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.del(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function dither(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.dither(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function facepalm(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.facepalm(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function gay(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.gay(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function invert(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.invert(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function jail(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.jail(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function magik(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.magik(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function pixelate(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.pixelate(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function rip(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.rip(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function sepia(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.sepia(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function rotate(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.rotate(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function trash(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.trash(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function wanted(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.wanted(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function wasted(req, res) {
try {
const apikey = req.query.apikey;
const image = req.query.img;
 if (image === undefined || apikey === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  img = await Caxinha.canvas.wasted(`${image}`);
  res.type('png')
  res.send(img)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}



async function welcome(req, res) {
 	try {
 const apikey = req.query.apikey;
 const nome = req.query.nome; 
 const nomegp = req.query.nomegp; 
 const perfil = req.query.perfil;
 const membros = req.query.membros;
 const titulo = req.query.titulo;  
 const numero = req.query.numero;
 const cor = req.query.cor;
 const lcor = req.query.lcor;
 const tcor = req.query.tcor;
 const fundo = req.query.fundo;
  if (apikey === undefined || nome === undefined || nomegp === undefined || titulo === undefined || membros === undefined || fundo === undefined || perfil === undefined || numero === undefined || cor === undefined || lcor === undefined || tcor === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
var image = await new Cannvas.Welcome()
.setTextTitle(`${titulo}`)
  .setUsername(`${nome}`)
  .setDiscriminator(`${numero}`)
  .setMemberCount(`${membros}`)
  .setGuildName(`${nomegp}`)
  .setAvatar(`${perfil}`)
  .setColor("border", `#${cor}`)
  .setColor("username-box", `#${cor}`)
  .setColor("discriminator-box", `#${cor}`)
  .setColor("message-box", `#${cor}`)
  .setColor("title", `#${tcor}`)
  .setColor("avatar", `#${cor}`)
  .setColor("Username", `#${lcor}`)
  .setColor("Message", `#${lcor}`)
  .setColor("Discriminator", `#${lcor}`)
  .setColor("Hashtag", `#${lcor}`) 
  .setBackground(`${fundo}`)
  .toAttachment();
  data = image.toBuffer();
        res.type('png')
        res.send(data)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function goodbye(req, res) {
 	try {
 const apikey = req.query.apikey;
 const nome = req.query.nome; 
 const nomegp = req.query.nomegp; 
 const perfil = req.query.perfil;
 const membros = req.query.membros;
 const titulo = req.query.titulo;  
 const numero = req.query.numero;
 const cor = req.query.cor;
 const lcor = req.query.lcor;
 const tcor = req.query.tcor;
 const fundo = req.query.fundo;
  if (apikey === undefined || nome === undefined || nomegp === undefined || titulo === undefined || membros === undefined || fundo === undefined || perfil === undefined || numero === undefined || cor === undefined || lcor === undefined || tcor === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
var image = await new Cannvas.Goodbye()
.setTextTitle(`${titulo}`)
  .setUsername(`${nome}`)
  .setDiscriminator(`${numero}`)
  .setMemberCount(`${membros}`)
  .setGuildName(`${nomegp}`)
  .setAvatar(`${perfil}`)
  .setColor("border", `#${cor}`)
  .setColor("username-box", `#${cor}`)
  .setColor("discriminator-box", `#${cor}`)
  .setColor("message-box", `#${cor}`)
  .setColor("title", `#${tcor}`)
  .setColor("avatar", `#${cor}`)
  .setColor("Username", `#${lcor}`)
  .setColor("Message", `#${lcor}`)
  .setColor("Discriminator", `#${lcor}`)
  .setColor("Hashtag", `#${lcor}`) 
  .setBackground(`${fundo}`)
  .toAttachment();
  data = image.toBuffer();
        res.type('png')
        res.send(data)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}






async function twitch(req, res) {
 	try {
 const apikey = req.query.apikey;
 const nome = req.query.nome; 
 const usuario = req.query.usuario; 
 const comentario = req.query.comentario;
 const perfil = req.query.perfil;
  if (apikey === undefined || nome === undefined || usuario === undefined || comentario === undefined || perfil === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
var image = await new canvafy.Tweet()
  .setTheme("dim")
  .setUser({displayName: nome, username: usuario})
  .setVerified(true)
  .setComment(comentario)
  .setAvatar(perfil)
  .build();
        res.type('png')
        res.send(image)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function namoro(req, res) {
 	try {
 const apikey = req.query.apikey;
 const avatar1 = req.query.avatar1; 
 const avatar2 = req.query.avatar2; 
 const fundo = req.query.fundo;
  if (apikey === undefined || avatar1 === undefined || avatar2 === undefined || fundo === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
var image = await new canvafy.Ship()
    .setAvatars(avatar1, avatar2)
    .setBackground("image", fundo)
    .setBorder("#ff0000")
    .setOverlayOpacity(0.5)
    .build();
//  data = image.toBuffer();
        res.type('png')
        res.send(image)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}


async function levelup2(req, res) {
 	try {
 const apikey = req.query.apikey;
 const perfil = req.query.perfil; 
 const nome = req.query.nome; 
 const fundo = req.query.fundo;
 const levelantigo = req.query.levelantigo;
 const levelnovo = req.query.levelnovo;
  if (apikey === undefined || perfil === undefined || nome === undefined || fundo === undefined || levelantigo === undefined || levelnovo === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  console.log(levelantigo, levelnovo)
  var num2 = Number(levelantigo); // 
  var num3 = Number(levelnovo); //
  var image = await new canvafy.LevelUp()
    .setAvatar(perfil)
    .setBackground("image", fundo)
    .setUsername(nome)
    .setBorder("#000000")
    .setAvatarBorder("#ff0000")
    .setOverlayOpacity(0.7)
    .setLevels(num3,num2)
    .build();
//  data = image.toBuffer();
        res.type('png')
        res.send(image)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}


async function menudit(req, res) {
 	try {
 const apikey = req.query.apikey;
 const perfil = req.query.perfil; 
 const titulo1 = req.query.titulo1; 
 const fundo = req.query.fundo;
 const nome = req.query.nome; 
  if (apikey === undefined || titulo1 === undefined || fundo === undefined || nome === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
var image = await new Card()
    .setTitle(titulo1)
    .setName(nome)
    .setAvatar(perfil)
    .setMessage("a")
    .setBackground(fundo)
    .setColor("FF0000")
    .build();
        res.type('png')
        res.send(image)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function zapd(req, res) {
 	try {
 const apikey = req.query.apikey;
 const perfil = req.query.perfil; 
 const nome = req.query.nome;  
 const numero = req.query.numero; 
 const bio = req.query.bio; 
 const horas = req.query.horas; 
  if (apikey === undefined || nome === undefined || numero === undefined|| bio === undefined || horas === undefined || perfil === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
var image = await new Zap()
    .setName(nome)
    .setAvatar(perfil)
    .setNumero("+"+numero)
    .setBio(bio)
    .setHoras(horas)
    .setBackground("https://telegra.ph/file/5b70c56dcb8c8ba2e5651.png")
    .build();
        res.type('png')
        res.send(image)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function vasco(req, res) {
 	try {
 const apikey = req.query.apikey;
 const perfil = req.query.perfil; 
 const titulo1 = req.query.titulo1; 
 const nome = req.query.nome; 
  if (apikey === undefined || titulo1 === undefined || nome === undefined || perfil === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
var image = await new Vasco()
    .setTitle(titulo1)
    .setName(nome)
    .setAvatar(perfil)
    .setMessage("a")
    .setBackground("https://telegra.ph/file/a0b7a46d237d2573de512.jpg")
    .setColor("FFFFFF")
    .build();
  res.type('png')
        res.send(image)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function menufy(req, res) {
 	try {
 const apikey = req.query.apikey;
 const perfil = req.query.perfil; 
 const titulo1 = req.query.titulo1; 
 const titulo2 = req.query.titulo2; 
 const fundo = req.query.fundo;
 const corborda = req.query.corborda;
 const coravatar = req.query.coravatar; 
  if (apikey === undefined || titulo1 === undefined || titulo2 === undefined || fundo === undefined || corborda === undefined || coravatar === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
var image = await new canvafy.WelcomeLeave()
  .setAvatar(perfil)
  .setBackground("image", fundo)
  .setTitle(titulo1)
  .setDescription(titulo2)
  .setBorder('#'+corborda)
  .setAvatarBorder('#'+coravatar)
  .setOverlayOpacity(0.3)
  .build();
  res.type('png')
        res.send(image)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function welgodby(req, res) {
 	try {
 const apikey = req.query.apikey;
 const perfil = req.query.perfil; 
 const titulo1 = req.query.titulo1; 
 const autor = req.query.autor; 
 const gp = req.query.grupo;
  if (apikey === undefined || titulo1 === undefined || autor === undefined || gp === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
 console.log(titulo1)
var image = await new welkard.welCard()
  .setName(titulo1)
  .setAuthor(autor)
  .setServer(gp)
  .setColor("auto")
  .setBrightness(50)
  .setThumbnail(perfil)
  .build();
  res.type('png')
        res.send(image)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function spotifyc(req, res) {
 	try {
 const apikey = req.query.apikey;
 const autor = req.query.autor; 
 const album = req.query.album; 
 const minuto1 = req.query.minuto1; 
 const minuto2 = req.query.minuto2;
 const titulo = req.query.titulo; 
 const fundo = req.query.fundo; 
  if (apikey === undefined || autor === undefined || album === undefined || minuto1 === undefined || minuto2 === undefined || titulo === undefined || fundo === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  var num2 = Number(minuto1); // 
  var num3 = Number(minuto2); //
var image = await new canvafy.Spotify()
    .setAuthor(autor)
    .setAlbum(album)
    .setTimestamp(num2,num3)
    .setImage(fundo)
    .setTitle(titulo)
    .setBlur(5)
    .setOverlayOpacity(0.7)
    .build();
//  data = image.toBuffer();
  res.type('png')
        res.send(image)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function cardrankz(req, res) {
 	try {
 const apikey = req.query.apikey;
 const perfil = req.query.perfil; 
 const nome = req.query.nome; 
 const rank = req.query.rank;
 const level = req.query.level;
 const xp = req.query.xp; 
 const needxp = req.query.needxp; 
  if (apikey === undefined || perfil === undefined || nome === undefined || rank === undefined || level === undefined || xp === undefined || needxp === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  var num1 = Number(level); // 
  var num2 = Number(rank); // 
  var num3 = Number(xp); //
  var num4 = Number(needxp); // 
  const canvasRank = await new sayz.RankCardBuilder({
    currentLvl: num1,
    currentRank: num2,
    currentXP: num3,
    requiredXP: num4,
    fontDefault: 'Inter',
    backgroundColor: { background: '#190707', bubbles: '#ff0c0c' },
    avatarImgURL: perfil,
    nicknameText: { content: nome },
    userStatus: 'online',
    requiredXPColor: '#7F8381',
    currentXPColor: '#ff0c0c',
    avatarBackgroundColor: '#ff0c0c',
    colorTextDefault: '#ff0c0c',
    progressBarColor: '#ff0c0c',
}).build();
  data = await canvasRank.toBuffer();
  res.type('png')
        res.send(data)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function musicaz(req, res) {
 	try {
 const apikey = req.query.apikey;
 const capa = req.query.capa; 
 const titulo = req.query.titulo; 
 const autor = req.query.autor;
 const inicio = req.query.inicio;
 const fim = req.query.fim; 
  if (apikey === undefined || capa === undefined || titulo === undefined || autor === undefined || inicio === undefined || fim === undefined) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  const cardmsc = new muzicard()
        .setName(titulo)
        .setAuthor(autor)
        .setColor("auto")
        .setTheme("neonx")
        .setBrightness(69)
        .setThumbnail(capa)
        .setProgress(69)
        .setStartTime(inicio)
        .setEndTime(fim)
const data = await cardmsc.build();
  res.type('png')
        res.send(data)
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

module.exports = {
welcome,
goodbye,
comunismo,
bolsonaro,
bnw,
blurr,
affect,
beautiful,
circle,
del,
gay,
invert,
facepalm,
dither,
jail,
magik,
pixelate,
rip,
sepia,
rotate,
trash,
wanted,
wasted,
twitch,
namoro,
levelup2,
menufy,
spotifyc,
cardrankz,
musicaz,
welgodby,
menudit,
zapd,
vasco,
adoratv,
lolifofs,
lolifofss,
pcloli,
interro,
brasil,
editcanva,
carinhor,
menubysayoz,
editred,
editwite,
bemvdadeus,
bemvdadeus2,
menudioss,
ping
}
