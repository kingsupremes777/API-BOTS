__path = process.cwd()
const { verificaKey, limitAdd, isLimit, dinheiroadd, expfarm } = require('../backend/db')
const axios = require("axios");
const cheerio = require("cheerio");
const request = require('request');
const fs = require('fs')
const yts = require("yt-search")
const gis = require('g-i-s')

const paramtroerro = __path + '/views/ErroLink.html' //400
const semapikey = __path + '/views/SemKey.html' //404
const semlimit = __path + '/views/SemLimit.html' //429

const {animesonline, xnxxPesquisa, animeshentaiPesquisa, pinterestVideo, searchSpotify, tiktokSearch, pinterest_gif, cota, filmes, wikipedia, wikipediat, biblia, playstore, apkgara, xvz, pensador, styletext, getgrupos, gpwhatsapp, hentaistube, nerding, apkmodhacker, xvideos, uptodown, pornhub, soundl, st, gpsrc, dafontSearch, dafontDown, igstalk, ff, papeldeparede, htdl, xvideoss, xvideosdl, assistithtdl, assistitht, pornogratis, wallmob, pinterest, wall4kpaper, scrapeZacaNoticias } = require('../func.backend/api')

async function PortalZacarias(req, res) {
  let apikey = req.query.apikey
  if (!apikey) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  scrapeZacaNoticias().then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function animeshentaiPesquisaX(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  animeshentaiPesquisa(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}


async function xnxxPesquisaa(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  xnxxPesquisa(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function tiktokpesquisa(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  tiktokSearch(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function spotifysrc(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  searchSpotify(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}


async function googleimg(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  gis(nome, async (error, resultado) => {
    if (error) {
      console.log(error);
      res.status(500).send({
        status: 500,
        mensagem: 'Erro no Servidor Interno'
      });
    } else {
      const json = resultado;
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }
  });
}
async function film(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  filmes(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}
async function cotacao(req, res) {
  let apikey = req.query.apikey
  let moeda_a = req.query.moeda
  let moeda_b = req.query.para
  if (!apikey) return res.sendFile(paramtroerro)
  if (!moeda_a) return res.sendFile(paramtroerro) 
  if (!moeda_b) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  console.log(apikey)
  cota(moeda_a, moeda_b).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function wiki(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  wikipedia(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}



async function bibliaa(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.versiculo
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  biblia(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function playstoree(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  playstore(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function apkgaraa(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  apkgara(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}


async function ytss(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  yts(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function wallpp(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  wall4kpaper(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}
async function instastalk(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  igstalk(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2).replace(/,\s*\[/g, ',\n[').replace(/\],\s*\[/g, '],\n[')}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function xvds(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  xvz(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}
async function pensadorr(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  pensador(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}


async function hentaistuber(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  hentaistube(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function assistithtsrc(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  assistitht(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function pornhubsrc(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  pornhub(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function pornogratiss(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  pornogratis(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function gpsale(req, res) {
  let apikey = req.query.apikey
  if (!apikey) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  getgrupos().then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function apkmodhack(req, res) {
 let apikey = req.query.apikey
 let nome = req.query.nome
 if (!apikey) return res.sendFile(paramtroerro)
 if (!nome) return res.sendFile(paramtroerro) 
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
 await limitAdd(apikey);
await expfarm(apikey);
apkmodhacker(nome).then(resultado => {
res.json(resultado)
}).catch(error => {
console.log(error);
res.status(500).send({
status: 500,
mensagem: 'Erro no Servidor Interno'
})
});
}

async function gpwhatsappR(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  gpwhatsapp(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function nerdingR(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  nerding(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function uptodownR(req, res) {
 let apikey = req.query.apikey
 let nome = req.query.nome
 if (!apikey) return res.sendFile(paramtroerro)
 if (!nome) return res.sendFile(paramtroerro) 
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
 await limitAdd(apikey);
await expfarm(apikey);
uptodown(nome).then(resultado => {
res.json(resultado)
}).catch(error => {
console.log(error);
res.status(500).send({
status: 500,
mensagem: 'Erro no Servidor Interno'
})
});
}

async function gpsrcR(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  gpsrc(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function dafontSearchR(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  dafontSearch(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function ffR(req, res) {
 let apikey = req.query.apikey
 let nome = req.query.nome
 if (!apikey) return res.sendFile(paramtroerro)
 if (!nome) return res.sendFile(paramtroerro) 
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
 await limitAdd(apikey);
await expfarm(apikey);
ff(nome).then(resultado => {
res.json(resultado)
}).catch(error => {
console.log(error);
res.status(500).send({
status: 500,
mensagem: 'Erro no Servidor Interno'
})
});
}

async function papeldeparedeR(req, res) {
 let apikey = req.query.apikey
 let nome = req.query.nome
 if (!apikey) return res.sendFile(paramtroerro)
 if (!nome) return res.sendFile(paramtroerro) 
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
 await limitAdd(apikey);
await expfarm(apikey);
papeldeparede(nome).then(resultado => {
res.json(resultado)
}).catch(error => {
console.log(error);
res.status(500).send({
status: 500,
mensagem: 'Erro no Servidor Interno'
})
});
}

async function pinMp4(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  pinterestVideo(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function pin(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  pinterest(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function pingif(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  pinterest_gif(nome).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

module.exports = { 
apkmodhack,
gpwhatsappR,
nerdingR,
uptodownR,
gpsrcR,
dafontSearchR,
ffR,
papeldeparedeR,
pin,
gpsale,
hentaistuber,
assistithtsrc,
pornhubsrc,
pornogratiss,
pensadorr,
xvds,
instastalk,
wallpp,
ytss,
bibliaa,
playstoree,
apkgaraa,
wiki,
googleimg,
cotacao,
film,
pingif,
spotifysrc,
tiktokpesquisa,
pinMp4,
animeshentaiPesquisaX,
xnxxPesquisaa,
PortalZacarias
}
