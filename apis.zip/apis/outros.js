require('../configuração.js')
__path = process.cwd()
const { verificaKey, limitAdd, isLimit, dinheiroadd, expfarm } = require('../backend/db')
const fs = require('fs')
const axios = require('axios')
const util = require('util')

const simsimi = require("../func.backend/sim");

const paramtroerro = __path + '/views/ErroLink.html' //400
const semapikey = __path + '/views/SemKey.html' //404
const semlimit = __path + '/views/SemLimit.html' //429

const { TelegraPh, AyuUp } = require("../func.backend/uploader");
const fetch = require('node-fetch');
const { rastrear, globosporte, g1, signos, geminiAi } = require('../func.backend/api')
const { toPTT } = require('../func.backend/converter.js')
const { getBuffer, getRandom } = require("../func.backend/buff");

 
 
 const fetchJson = async (url, options) => {
	try {
		options ? options: {}
		const res = await axios({
			method: 'GET',
			url: url,
			headers: {
				'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
			},
			...options
		})
		return res.data
	} catch (err) {
		return err
	}
}

 
async function dbsbot(req, res) {
  const json = dbsbots;
  const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
  const html = `
    <html>
      <head>
        <style>${cssFile}</style>
      </head>
      <body>
        <div class="cardapi">
          <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
        </div>
      </body>
    </html>
  `;

  // Check if the request is from a browser or a script/robot
  const userAgent = req.header('User-Agent');
  if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
    // Browser request, send HTML response
    res.set('Content-Type', 'text/html');
    res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
  } else {
    // Script/robot request, send JSON response
    res.json(json);
  }
}

async function globoesportes(req, res) {
  let apikey = req.query.apikey
  if (!apikey) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  globosporte().then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}
async function signo(req, res) {
 let apikey = req.query.apikey
 let sig = req.query.signo
 if (apikey === undefined || sig === undefined) return res.sendFile(paramtroerro)
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
    signos(sig).then(resultado => {
        const json = resultado;
        const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
        <html>
            <head>
                <style>${cssFile}</style>
            </head>
            <body>
                <div class="cardapi">
                    <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
                </div>
            </body>
        </html>
    `;

        // Check if the request is from a browser or a script/robot
        const userAgent = req.header('User-Agent');
        if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
            // Browser request, send HTML response
            res.set('Content-Type', 'text/html');
            res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
        } else {
            // Script/robot request, send JSON response
            res.json(json);
        }
    }).catch(error => {
        console.log(error);
        res.status(500).send({
            status: 500,
            mensagem: 'Erro no Servidor Interno'
        })
    });
}

async function g1s(req, res) {
  let apikey = req.query.apikey
  if (!apikey) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  g1().then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}
async function rastre(req, res) {
  let apikey = req.query.apikey
  let id = req.query.id
  if (!apikey) return res.sendFile(paramtroerro)
  if (!id) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  rastrear(id).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function gemini(req, res) {
  let apikey = req.query.apikey
  let pergunta = req.query.pergunta
  if (!apikey) return res.sendFile(paramtroerro)
  if (!pergunta) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  geminiAi(pergunta).then(resultado => {
    const json = resultado;
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function gethtml(req, res) {
try {
let apikey = req.query.apikey
let site = req.query.site
if (!apikey) return res.sendFile(paramtroerro)
if (!site) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
expfarm(apikey)
fetch(site).then(res => res.text())
.then(i =>{
res.json({html: i})
})   
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}



async function simis(req, res) {
try {
let apikey = req.query.apikey
let dm = req.query.pergunta
if (!apikey) return res.sendFile(paramtroerro)
if (!dm) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
const encoder = new TextEncoder();
const response = await simsimi(dm,"pt")
res.json({
response
		})
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: "ia off-line", info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: err
		})
	}
}






async function imgig(req, res) { 
img = await fetchJson(`https://nekos.life/api/v2/img/waifu`)
res.type('jpg')
res.send(await getBuffer(img.url))
}

async function chatgpt(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.pergunta
  let modelo = req.query.modelo
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  if (!modelo) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    rs = await fetchJson(encodeURI(`https://itzpire.com/ai/gpt?model=${modelo}&q=`+nome))
    const json = {resposta: rs.data.response};
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  } catch(error) {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  };
}

async function blackbox(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.pergunta
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    rs = await fetchJson(encodeURI(`https://itzpire.com/ai/blackbox-ai?q=`+nome))
    const json = {resposta: rs.result};
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  } catch(error) {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  };
}

module.exports = { 
gethtml,
rastre,
imgig,
simis,
globoesportes,
g1s,
chatgpt,
blackbox,
dbsbot,
signo,
gemini
}
