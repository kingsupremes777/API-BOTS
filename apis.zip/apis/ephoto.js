__path = process.cwd()

const { verificaKey, limitAdd, isLimit, dinheiroadd, expfarm } = require('../backend/db')
const { download_Url } = require("../func.backend/function");

const mintake = require("../func.backend/mintake");

const path = require('path');
const fs = require('fs')


const paramtroerro = __path + '/views/ErroLink.html' //400
const semapikey = __path + '/views/SemKey.html' //404
const semlimit = __path + '/views/SemLimit.html' //429


const { getBuffer , getRandom} = require("../func.backend/buff");



//***************@ EPHOTO360*************************\\



//video 1 text

async function pubgv(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
mintake 
  .ephoto2("https://ephoto360.com/tao-avatar-video-pubg-phong-cach-nhieu-song-glitch-627.html", [
    nome,
  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('mp4')
res.send(ephotobuff)
})
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}
}  



async function anonovo(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/tao-thiep-video-new-year-countdown-2022-888.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('mp4')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function natalmsg(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/tao-thiep-video-giang-sinh-dep-va-an-tuong-danh-tang-ban-be-va-nguoi-than-885.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('mp4')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function trigrev(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-video-logo-con-ho-ky-thuat-so-862.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('mp4')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



// 1 texto

async function areia(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-chu-tren-nen-cat-trang-tuyet-dep-663.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function tela(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-chu/hieu-ung-chu-tren-vai-62.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  

//daqui

async function blackpinkepo(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-chu-phong-cach-blackpink-doc-dao-712.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function brotoluz(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-chu/tao-hieu-ung-chu-mam-anh-sang-74.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function balckpingv2(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-tao-logo-phong-cach-blackpink-truc-tuyen-843.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function borracha(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/tao-hieu-ung-tay-xoa-chu-truc-tuyen-850.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function brilhante(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/tao-hieu-ung-chu-phat-sang-online-834.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function papel(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-chu-cat-giay-nghe-thuat-online-824.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function diabo(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-chu-neon-canh-ac-quy-online-808.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function urso(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/tao-logo-mascot-gau-xam-phong-cach-den-trang-truc-tuyen-801.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function blur(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-viet-chu-len-cua-kinh-mua-tam-trang-dep-682.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function vietnam(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/tao-hieu-ung-chu-quoc-ky-viet-nam-truc-tuyen-884.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function crack(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/tao-hieu-ung-chu-vet-nut-3d-online-832.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function goldt(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-chu/hieu-ung-chu-vang-moi-271.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function grafit4(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-chu/viet-chu-graffiti-4-178.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function biscoito(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-chu/tao-chu-banh-vung-103.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



async function pig(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/hieu-ung-chu-3d-cung-heo-cute-dang-yeu-397.html", [

    nome,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  



//radio 1 texto

async function seta(req, res) {

try {

let nome = req.query.nome

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

let radio = "e0723d60-fc0d-421f-bf8f-a9b9b61e4be6"

mintake 

  .ephoto("https://ephoto360.com/tao-hieu-ung-mui-ten-dinh-kem-chu-ky-nhieu-mau-846.html", [

    nome,

  ],radio).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  

// 2 texto

async function grafite(req, res) {

try {

let nome = req.query.nome

let nome2 = req.query.nome2

let apikey = req.query.apikey

if (!nome) return res.sendFile(paramtroerro)

if (!nome2) return res.sendFile(paramtroerro)

if (!apikey) return res.sendFile(paramtroerro)

let check = await verificaKey(apikey)

if (!check) return res.sendFile(semapikey)

let limit = await isLimit(apikey);

if (limit) return res.sendFile(semlimit)

await limitAdd(apikey);

await expfarm(apikey);

mintake 

  .ephoto2("https://ephoto360.com/viet-chu-graffiti-nghe-thuat-tren-tuong-day-mau-sac-792.html", [

    nome, nome2,

  ]).then(async(data) => {
const ephotobuff = await getBuffer(`https://s1.ephoto360.com${data}`)
res.type('png')
res.send(ephotobuff)

})

} catch(err) {

console.log(err)

res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })

}

}  

     

  

module.exports = { 
pubgv,

anonovo,

natalmsg,

trigrev,

areia,

tela,

blackpinkepo,

brotoluz,

balckpingv2,

borracha,

brilhante,

papel,

diabo,

urso,

blur,

vietnam,

crack,

goldt,

grafit4,

biscoito,

pig,

seta,

grafite

}

