__path = process.cwd()

const { verificaKey, limitAdd, isLimit, dinheiroadd, expfarm } = require('../backend/db')
const { download_Url } = require("../func.backend/function");
const photooxyz = require("../func.backend/photooxy");
const path = require('path');
const fs = require('fs')

const paramtroerro = __path + '/views/ErroLink.html' //400
const semapikey = __path + '/views/SemKey.html' //404
const semlimit = __path + '/views/SemLimit.html' //429
const { getBuffer , getRandom} = require("../func.backend/buff");


async function shadowx(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/shadow-text-effect-in-the-sky-394.html", nome)
console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function stonex(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/online-3d-white-stone-text-effect-utility-411.html", nome)
console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function writez(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/write-art-quote-on-wood-heart-370.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function summerz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/3d-summer-text-effect-367.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function wolfmetalz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/create-a-wolf-metal-text-effect-365.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function naturez(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/make-nature-3d-text-effects-364.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function rosesz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/yellow-roses-text-360.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function naturetypoz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/create-vector-nature-typography-355.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function quotesunderz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/quotes-under-fall-leaves-347.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function shinez(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/rainbow-shine-text-223.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function smokez(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/other-design/create-an-easy-smoke-type-effect-390.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function lovez(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/create-a-picture-of-love-message-377.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function undergrassz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/make-quotes-under-grass-376.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function doublelovez(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/love-text-effect-372.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function coffecupz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/put-any-text-in-to-coffee-cup-371.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function underwaterz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/creating-an-underwater-ocean-363.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function smokyneonz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/make-smoky-neon-glow-effect-343.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function starsz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/write-stars-text-on-the-night-sky-200.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function raimbowz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/glow-rainbow-effect-generator-201.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function ballonz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/royal-look-text-balloon-effect-173.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function metallicez(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/illuminated-metallic-effect-177.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function embroideryz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/create-embroidery-text-online-191.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

async function flamingz(req, res) {
try {
let nome = req.query.nome
let apikey = req.query.apikey
if (!nome) return res.sendFile(paramtroerro)
if (!apikey) return res.sendFile(paramtroerro)
let check = await verificaKey(apikey)
if (!check) return res.sendFile(semapikey)
let limit = await isLimit(apikey);
if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
console.log(nome)
let photoxx = await photooxyz.photoOxy("https://photooxy.com/logo-and-text-effects/realistic-flaming-text-effect-online-197.html", nome)
//console.log(photoxx)
buff = await getBuffer(photoxx)
res.type('jpg')
res.send(buff)
} catch(err) {
console.log(err)
res.status(500).send({ status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error' })
}
}

module.exports = { 
shadowx,
stonex,
writez,
summerz,
wolfmetalz,
naturez,
rosesz,
naturetypoz,
quotesunderz,
shinez,
smokez,
lovez,
undergrassz,
doublelovez,
coffecupz,
underwaterz,
smokyneonz,
starsz,
raimbowz,
ballonz,
metallicez,
embroideryz,
flamingz
}