__path = process.cwd()
const { verificaKey, limitAdd, isLimit,  dinheiroadd, expfarm } = require('../backend/db')

const fs = require('fs')
const paramtroerro = __path + '/views/ErroLink.html' //400
const semapikey = __path + '/views/SemKey.html' //404
const semlimit = __path + '/views/SemLimit.html' //429
const axios = require("axios")

const { styletext, textmakers, tempo, igStalks, ssweb, translate, tiktokstalk, tkstalk, donodozap } = require('../func.backend/api')
const { TelegraPh } = require("../func.backend/uploader");

const { getBuffer, getRandom } = require("../func.backend/buff");

const util = require('util')

async function donodozaps(req, res) {
  let apikey = req.query.apikey
  let numero = req.query.numero
  if (!apikey) return res.sendFile(paramtroerro)
  if (!numero) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    donodozap(numero).then(async resultado => {
      const json = {
        status: 'online', 
        admin: 'https://wa.me/5562936180708', 
        resultado
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'inativo', 
        admin: 'https://wa.me/5562936180708', 
        resultado: error
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'inativo', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}

async function tkstalks(req, res) {
  let apikey = req.query.apikey
  let usuario = req.query.usuario
  if (!apikey) return res.sendFile(paramtroerro)
  if (!usuario) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    tkstalk(usuario).then(async resultado => {
      const json = {
        status: 'online', 
        admin: 'https://wa.me/5562936180708', 
        resultado
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'inativo', 
        admin: 'https://wa.me/5562936180708', 
        resultado: error
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'inativo', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}
   

   
   



async function tikstalk(req, res) {
  let apikey = req.query.apikey
  let usuario = req.query.usuario
  if (!apikey) return res.sendFile(paramtroerro)
  if (!usuario) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    tiktokstalk(usuario).then(async resultado => {
      const json = {
        status: 'online', 
        admin: 'https://wa.me/5562936180708', 
        resultado
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'inativo', 
        admin: 'https://wa.me/5562936180708', 
        resultado: error
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'inativo', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}

async function tradutor(req, res) {
  let apikey = req.query.apikey
  let msg = req.query.msg
  let idioma = req.query.idioma
  if (!apikey) return res.sendFile(paramtroerro)
  if (!msg) return res.sendFile(paramtroerro)
  if (!idioma) return res.sendFile(paramtroerro)  
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    translate(msg, idioma).then(resultado => {
      const json = {
        status: 'operando', 
        admin: 'https://wa.me/5562936180708', 
        resultado: resultado
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'inativo', 
        admin: 'https://wa.me/5562936180708', 
        resultado: error
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'inativo', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}

async function print(req, res) {
    let apikey = req.query.apikey
    let link = req.query.link
    if (!apikey) return res.sendFile(paramtroerro)
    if (!link) return res.sendFile(paramtroerro) 
    let check = await verificaKey(apikey)
    if (!check) return res.sendFile(semapikey)
    let limit = await isLimit(apikey);
    if (limit) return res.sendFile(semlimit)
    await limitAdd(apikey);
   await expfarm(apikey);
   ssweb(link).then(resultado => {
res.type('png')
res.send(resultado)
   }).catch(error => {
   console.log(error);
   res.json({
      status: 'inativo', 
      admin: 'https://wa.me/5562936180708', 
      resultado: error
      })
   });
   }



async function igstalkk(req, res) {
  let apikey = req.query.apikey
  let usuario = req.query.usuario
  if (!apikey) return res.sendFile(paramtroerro)
  if (!usuario) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    igStalks(usuario).then(resultado => {
      const json = {
        status: 'operando', 
        admin: 'https://wa.me/5562936180708', 
        resultado: resultado
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'inativo', 
        admin: 'https://wa.me/5562936180708', 
        resultado: error
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'inativo', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}
async function tempoagora(req, res) {
  let apikey = req.query.apikey
  let estado = req.query.estado
  if (!apikey) return res.sendFile(paramtroerro)
  if (!estado) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    tempo(estado).then(resultado => {
      const json = {
        status: 'operando', 
        admin: 'https://wa.me/5562936180708', 
        resultado: resultado
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'inativo', 
        admin: 'https://wa.me/5562936180708', 
        resultado: error
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'inativo', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}




async function metadinha(req, res) {
  try {
    let apikey = req.query.apikey
    if (!apikey) return res.sendFile(paramtroerro)
    let check = await verificaKey(apikey)
    if (!check) return res.sendFile(semapikey)
    let limit = await isLimit(apikey);
    if (limit) return res.sendFile(semlimit)
    await limitAdd(apikey);
    await expfarm(apikey);
    json = JSON.parse(fs.readFileSync(__path +'/func.backend/metadinha.json').toString())
    random = json[Math.floor(Math.random() * json.length)]
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(random, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(random);
    }
  } catch(err) {
    const json = {
      status: 'inativo', 
      admin: 'https://wa.me/5562936180708', 
      resultado: err
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}

async function styletextR(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  styletext(nome).then(resultado => {
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(resultado, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(resultado);
    }
  }).catch(error => {
    const json = {
      status: 'inativo', 
      admin: 'https://wa.me/5562936180708', 
      resultado: error
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  });
}

module.exports = { 
metadinha,
styletextR,
tempoagora,
igstalkk,
print,
tradutor,
tikstalk,
tkstalks,
donodozaps
}
