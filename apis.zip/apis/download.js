__path = process.cwd()
const { verificaKey, limitAdd, isLimit, dinheiroadd, expfarm } = require('../backend/db')

const fs = require('fs')
const axios = require('axios')
const paramtroerro = __path + '/views/ErroLink.html' //400
const semapikey = __path + '/views/SemKey.html' //404
const semlimit = __path + '/views/SemLimit.html' //429


const yts = require("yt-search")
const { youtubedl, youtubedlv2, snapsave } = require("@bochilteam/scraper")

const { getBuffer, getRandom } = require("../func.backend/buff");


const util = require('util')


const { ttdownloader } = require("../func.backend/tkdl");
const { twitterdl } = require("../func.backend/twitterdl");
const {
 topflixdl,
 topflix
} = require("../func.backend/topflix");

const { 
soundl,
 igdl,
 spotifydl,
 facebook_video,
 tt,
 pindl,
 searchSpotify,
 xvideosDown,
 xnxxDownload,
 scrapeDetalhesNoticia, scrapeAllVideos
} = require('../func.backend/api')

const { 
  ytSearch
} = require('../func.backend/ytdl')

const mediafire = require("../func.backend/mediafire");

const fetchJson = async (url, options) => {
	try {
		options ? options: {}
		const res = await axios({
			method: 'GET',
			url: url,
			headers: {
				'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
			},
			...options
		})
		return res.data
	} catch (err) {
		return err
	}
}

async function PortalZacariasDl(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    scrapeDetalhesNoticia(query).then(result => {
      const json = {
        status: 'operando', 
        admin: 'https://wa.me/5562936180708', 
        resultado: result
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'parado', 
        admin: 'https://wa.me/5562936180708', 
        resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}

async function PortalZacariasDlAll(req, res) {
  let apikey = req.query.apikey
  if (!apikey) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    scrapeAllVideos().then(result => {
      const json = {
        status: 'operando', 
        admin: 'https://wa.me/5562936180708', 
        resultado: result
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'parado', 
        admin: 'https://wa.me/5562936180708', 
        resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}

async function xnxxDow(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    xnxxDownload(query).then(result => {
      const json = {
        status: 'operando', 
        admin: 'https://wa.me/5562936180708', 
        resultado: result
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'parado', 
        admin: 'https://wa.me/5562936180708', 
        resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}

async function xvideoDow(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    xvideosDown(query).then(result => {
      const json = {
        status: 'operando', 
        admin: 'https://wa.me/5562936180708', 
        resultado: result
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'parado', 
        admin: 'https://wa.me/5562936180708', 
        resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}

async function pintdl(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    pindl(query).then(result => {
      const json = {
        status: 'operando', 
        admin: 'https://wa.me/5562936180708', 
        resultado: result
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'parado', 
        admin: 'https://wa.me/5562936180708', 
        resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}

async function ttk2(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  tt(query).then(result => {
    const json = {
      status: 'operando', 
      admin: 'https://wa.me/5562936180708', 
      resultado: result
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  });
}


async function playv_2(req, res) {
 let apikey = req.query.apikey
 let query = req.query.nome
 let q = req.query.qualidade
 if (!apikey) return res.sendFile(paramtroerro)
 if (!query) return res.sendFile(paramtroerro) 
 if (!q) return res.sendFile(paramtroerro) 
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
try{
const search = yts(query)
.then(async(data) => {
const url = []
const pormat = data.all
for (let i = 0; i < pormat.length; i++) {
if (pormat[i].type == 'video') {
let dapet = pormat[i]
url.push(dapet.url)
}
}
console.log(url)
const yt = await youtubedl(url[0]).catch(async () => await youtubedlv2(url[0])).catch(async () => await res.send("deu b.o")); 
const dl_url = await yt.video[q].download(); 
const tamanhoH = await yt.video[q].fileSizeH; 
const tamanho = await yt.video[q].fileSize; 
const qualidade = q;
const titulo = await yt.title;
const capa = await yt.thumbnail;
const buff = await getBuffer(dl_url)
console.log(yt)
/*res.json({
status: 'operando', 
admin: 'https://wa.me/5562936180708', 
titulo,
capa,
qualidade,
tamanhoH,
tamanho,
baixar: dl_url
})*/
res.type("mp4")
res.send(buff)
})
} catch(error) {
console.log(error);
res.json({
status: 'parado', 
admin: 'https://wa.me/5562936180708', 
resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
})
};

}

async function play_2(req, res) {
 let apikey = req.query.apikey
 let query = req.query.nome
 let q = '128kbps'; 
 if (!apikey) return res.sendFile(paramtroerro)
 if (!query) return res.sendFile(paramtroerro) 
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
try{
const search = yts(query)
.then(async(data) => {
const url = []
const pormat = data.all
for (let i = 0; i < pormat.length; i++) {
if (pormat[i].type == 'video') {
let dapet = pormat[i]
url.push(dapet.url)
}
}

console.log(url)
const yt = await youtubedl(url[0]).catch(async () => await youtubedlv2(url[0])).catch(async () => await res.send("deu b.o")); 
const dl_url = await yt.audio[q].download(); 
const tamanhoH = await yt.audio[q].fileSizeH; 
const tamanho = await yt.audio[q].fileSize; 
const qualidade = q;
const titulo = await yt.title;
const capa = await yt.thumbnail;
const buff = await getBuffer(dl_url)
console.log(yt)
/*res.json({
status: 'operando', 
admin: 'https://wa.me/5562936180708', 
titulo,
capa,
qualidade,
tamanhoH,
tamanho,
baixar: dl_url
})*/
res.type("mp3")
res.send(buff)
})
} catch(error) {
console.log(error);
res.json({
status: 'parado', 
admin: 'https://wa.me/5562936180708', 
resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
})
};

}

async function ytmp4_2(req, res) {
 let apikey = req.query.apikey
 let query = req.query.link
 let q = req.query.qualidade
 if (!apikey) return res.sendFile(paramtroerro)
 if (!query) return res.sendFile(paramtroerro) 
 if (!q) return res.sendFile(paramtroerro) 
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
try{
const yt = await youtubedl(query).catch(async () => await youtubedlv2(query)).catch(async () => await res.send("deu b.o")); 
const dl_url = await yt.video[q].download(); 
const tamanhoH = await yt.video[q].fileSizeH; 
const tamanho = await yt.video[q].fileSize; 
const qualidade = q;
const titulo = await yt.title;
const capa = await yt.thumbnail;
const buff = await getBuffer(dl_url)
console.log(yt)
/*res.json({
status: 'operando', 
admin: 'https://wa.me/5562936180708', 
titulo,
capa,
qualidade,
tamanhoH,
tamanho,
baixar: dl_url
})*/
res.type("mp4")
res.send(buff)
} catch(error) {
console.log(error);
res.json({
status: 'parado', 
admin: 'https://wa.me/5562936180708', 
resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
})
};
}

async function ytmp3_2(req, res) {
 let apikey = req.query.apikey
 let query = req.query.link
 let q = '128kbps'; 
 if (!apikey) return res.sendFile(paramtroerro)
 if (!query) return res.sendFile(paramtroerro) 
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
try{
const yt = await youtubedl(query).catch(async () => await youtubedlv2(query)).catch(async () => await res.send("deu b.o")); 
const dl_url = await yt.audio[q].download(); 
const tamanhoH = await yt.audio[q].fileSizeH; 
const tamanho = await yt.audio[q].fileSize; 
const qualidade = q;
const titulo = await yt.title;
const capa = await yt.thumbnail;
const buff = await getBuffer(dl_url)
console.log(yt)
/*res.json({
status: 'operando', 
admin: 'https://wa.me/5562936180708', 
titulo,
capa,
qualidade,
tamanhoH,
tamanho,
baixar: dl_url
})*/
res.type("mp3")
res.send(buff)
} catch(error) {
console.log(error);
res.json({
status: 'parado', 
admin: 'https://wa.me/5562936180708', 
resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
})
};
}

async function threds(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro)
  if (!query.includes('threads.net')) return res.json({
    status: 'parado', 
    admin: 'https://wa.me/5562936180708', 
    resultado: 'preciso de um link que seja do threads!!!'
  })    
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    rs = await fetchJson(encodeURI(`https://tools.betabotz.eu.org/tools/threadsdl?url=`+query))
    const json = {
      status: 'operando', 
      admin: 'https://wa.me/5562936180708', 
      resultado: rs.result
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  } catch(error) {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  };
}

async function igdl2(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro)
  if (!query.includes('instagram.com')) return res.json({
    status: 'parado', 
    admin: 'https://wa.me/5562936180708', 
    resultado: 'preciso de um link que seja do instagram!!!'
  })    
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    rs = await fetchJson(encodeURI(`https://tools.betabotz.eu.org/tools/instagramdl?url=`+query))
    const json = {
      status: 'operando', 
      admin: 'https://wa.me/5562936180708', 
      resultado: rs.result.map(({ wm, ...rest }) => ({ ...rest, criador: "sayoz" }))
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  } catch(error) {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  };
}

async function igdlr(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro) 
  if (!query.includes('instagram.com')) return res.json({
    status: 'parado', 
    admin: 'https://wa.me/5562936180708', 
    resultado: 'preciso de um link que seja do Instagram!!!'
  }) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  igdl(query).then(result => {
    const json = {
      status: 'operando', 
      admin: 'https://wa.me/5562936180708', 
      resultado: result
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  });
}

async function spotifyplay(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);

  // Pesquisar música no Spotify
  searchSpotify(nome).then(resultado => {
    const musica = resultado[0]; // Selecionar a primeira música encontrada
    const link = musica.link;

    // Download da música do Spotify
    spotifydl(link).then(result => {
      const json = {
        status: 'operando', 
        admin: 'https://wa.me/5562936180708', 
        resultado: result
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'parado', 
        admin: 'https://wa.me/5562936180708', 
        resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  }).catch(error => {
    console.log(error);
    res.status(500).send({
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    })
  });
}

async function spotifys(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  spotifydl(query).then(result => {
    const json = {
      status: 'operando', 
      admin: 'https://wa.me/5562936180708', 
      resultado: result
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  });
}

async function facebookvd(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  facebook_video(query).then(result => {
    const json = {
      status: 'operando', 
      admin: 'https://wa.me/5562936180708', 
      resultado: result
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  });
}



async function tiktokdl(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro)
  if (!query.includes('tiktok.com')) return res.json({
    status: 'parado', 
    admin: 'https://wa.me/5562936180708', 
    resultado: 'preciso de um link que seja do TikTok!!!'
  })    
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    rs = await fetchJson(encodeURI(`https://www.tikwm.com/api/?url=`+query))
    const json = {
      status: 'operando', 
      admin: 'https://wa.me/5562936180708', 
      resultado: rs
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  } catch(error) {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  };
}
async function twidl(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro)
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  twitterdl(query).then(result => {
    const json = {
      status: 'operando', 
      admin: 'https://wa.me/5562936180708', 
      resultado: result
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }).catch(error => {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  });
}
async function sounddl(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro) 
  if (!query.includes('soundcloud.com')) return res.json({
    status: 'parado', 
    admin: 'https://wa.me/5562936180708', 
    resultado: 'preciso de um link que seja do SoundCloud!!!'
  })      
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    soundl(query).then(result => {
      const json = {
        status: 'operando', 
        admin: 'https://wa.me/5562936180708', 
        resultado: result
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'parado', 
        admin: 'https://wa.me/5562936180708', 
        resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}

async function topdl(req, res) {
 let apikey = req.query.apikey
 let query = req.query.link
 if (!apikey) return res.sendFile(paramtroerro)
 if (!query) return res.sendFile(paramtroerro) 
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
topflixdl(query).then(result => {
res.json({
status: 'operando', 
admin: 'https://wa.me/5562936180708', 
resultado: result
})
}).catch(error => {
console.log(error);
res.json({
status: 'parado', 
admin: 'https://wa.me/5562936180708', 
resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
})
});
}

async function topsrc(req, res) {
  let apikey = req.query.apikey
  let query = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro) 
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    topflix(query).then(result => {
      const json = {
        status: 'operando', 
        admin: 'https://wa.me/5562936180708', 
        resultado: result
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'parado', 
        admin: 'https://wa.me/5562936180708', 
        resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}

async function mediafiredl(req, res) {
  let apikey = req.query.apikey
  let query = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!query) return res.sendFile(paramtroerro) 
  if (!query.includes('mediafire.com')) return res.json({
    status: 'parado', 
    admin: 'https://wa.me/5562936180708', 
    resultado: 'preciso de um link que seja do MediaFire!!!'
  })       
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  try {
    mediafire(query).then(result => {
      const json = {
        status: 'operando', 
        admin: 'https://wa.me/5562936180708', 
        resultado: result
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    }).catch(error => {
      const json = {
        status: 'parado', 
        admin: 'https://wa.me/5562936180708', 
        resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
      };
      const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
      const html = `
        <html>
          <head>
            <style>${cssFile}</style>
          </head>
          <body>
            <div class="cardapi">
              <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
            </div>
          </body>
        </html>
      `;

      // Check if the request is from a browser or a script/robot
      const userAgent = req.header('User-Agent');
      if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
        // Browser request, send HTML response
        res.set('Content-Type', 'text/html');
        res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
      } else {
        // Script/robot request, send JSON response
        res.json(json);
      }
    });
  } catch(err) {
    const json = {
      status: 'parado', 
      admin: 'https://wa.me/5562936180708', 
      resultado: 'ocorreu um erro no servidor interno, contate o admin no número acima!!'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(json);
    }
  }
}

module.exports = { 
tiktokdl,
twidl,
sounddl,
topdl,
topsrc,
mediafiredl,
igdlr,
igdl2,
threds,
ytmp3_2,
ytmp4_2,
playv_2,
play_2,
spotifys,
facebookvd,
ttk2,
pintdl,
spotifyplay,
xvideoDow,
xnxxDow,
PortalZacariasDlAll,
PortalZacariasDl
}
