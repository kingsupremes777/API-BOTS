__path = process.cwd()
const { verificaKey, limitAdd, isLimit, dinheiroadd, expfarm } = require('../backend/db')
const axios = require("axios");
const cheerio = require("cheerio");
const request = require('request');
const fs = require('fs')
const fetch = require('node-fetch')

const paramtroerro = __path + '/views/ErroLink.html' //400
const semapikey = __path + '/views/SemKey.html' //404
const semlimit = __path + '/views/SemLimit.html' //429

const { waifur, animesonline, hentaiword, mangas, mangatodos, mangaspesquisa, frasesanime, trevomangadl, trevomanga, Mangax, animeVideo, animeVideo2 } = require('../func.backend/api')
const { getBuffer , getRandom} = require("../func.backend/buff");

async function animeStatus2(req, res) {
  let apikey = req.query.apikey
  if (!apikey) return res.sendFile(paramtroerro)	
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  animeVideo2().then(resultado => {
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(resultado, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(resultado);
    }
  }).catch(error => {
    const json = {
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.status(500).send(json);
    }
  });
}

async function animeStatus(req, res) {
  let apikey = req.query.apikey
  if (!apikey) return res.sendFile(paramtroerro)	
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  animeVideo().then(resultado => {
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(resultado, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(resultado);
    }
  }).catch(error => {
    const json = {
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.status(500).send(json);
    }
  });
}

async function mangxx(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro)  	
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  Mangax(nome).then(resultado => {
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(resultado, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(resultado);
    }
  }).catch(error => {
    const json = {
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.status(500).send(json);
    }
  });
}


 async function waifu(req, res) {
 	try {
 let apikey = req.query.apikey
 if (!apikey) return res.sendFile(paramtroerro)
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
waifur().then(async resultado => {
console.log(resultado)
buff = await getBuffer(resultado[0].imagem)
res.type('png')
res.send(buff)
})
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function frasesanimes(req, res) {
  let apikey = req.query.apikey
  if (!apikey) return res.sendFile(paramtroerro) 	
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  frasesanime().then(resultado => {
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(resultado, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(resultado);
    }
  }).catch(error => {
    const json = {
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.status(500).send(json);
    }
  });
}

 async function animesrandoms(req, res) {
 	try {
 let apikey = req.query.apikey
 let categoria = req.query.categoria
 if (!apikey) return res.sendFile(paramtroerro)
 if (!categoria) return res.sendFile(paramtroerro)
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
await fetch(`https://api.waifu.pics/sfw/${categoria}`)
		.then(response => response.json())
		.then(async quote =>  {
buff = await getBuffer(quote.url)
res.type('png')
res.send(buff)
})
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}
 async function hentaisrandoms(req, res) {
 	try {
 let apikey = req.query.apikey
 let categoria = req.query.categoria
 if (!apikey) return res.sendFile(paramtroerro)
 if (!categoria) return res.sendFile(paramtroerro)
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
await limitAdd(apikey);
await expfarm(apikey);
await fetch(`https://api.waifu.pics/nsfw/${categoria}`)
		.then(response => response.json())
		.then(async quote =>  {
buff = await getBuffer(quote.url)
res.type('png')
res.send(buff)
})
	} catch(err) {
		console.log(err)
		res.status(500).send({
			status: 500, info: 'ops, aconteceu um erro no servidor interno, contate o admin pelo Whatsapp wa.me/5562981386093', resultado: 'error'
		})
	}
}

async function pesquisamangatrevo(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro)  	
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  trevomanga(nome).then(resultado => {
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(resultado, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(resultado);
    }
  }).catch(error => {
    const json = {
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.status(500).send(json);
    }
  });
}

async function dlmangatrevor(req, res) {
  let apikey = req.query.apikey
  let link = req.query.link
  if (!apikey) return res.sendFile(paramtroerro)
  if (!link) return res.sendFile(paramtroerro)  	
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  trevomangadl(link).then(resultado => {
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(resultado, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(resultado);
    }
  }).catch(error => {
    const json = {
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.status(500).send(json);
    }
  });
}

async function pesquisamanga(req, res) {
  let apikey = req.query.apikey
  let nome = req.query.nome
  if (!apikey) return res.sendFile(paramtroerro)
  if (!nome) return res.sendFile(paramtroerro)  	
  let check = await verificaKey(apikey)
  if (!check) return res.sendFile(semapikey)
  let limit = await isLimit(apikey);
  if (limit) return res.sendFile(semlimit)
  await limitAdd(apikey);
  await expfarm(apikey);
  mangaspesquisa(nome).then(resultado => {
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(resultado, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.json(resultado);
    }
  }).catch(error => {
    const json = {
      status: 500,
      mensagem: 'Erro no Servidor Interno'
    };
    const cssFile = fs.readFileSync('public/css/red.css', 'utf8');
    const html = `
      <html>
        <head>
          <style>${cssFile}</style>
        </head>
        <body>
          <div class="cardapi">
            <h2 class="jsoncode">${JSON.stringify(json, null, 2)}</h2>            
          </div>
        </body>
      </html>
    `;

    // Check if the request is from a browser or a script/robot
    const userAgent = req.header('User-Agent');
    if (userAgent && userAgent.indexOf('Mozilla') !== -1) {
      // Browser request, send HTML response
      res.set('Content-Type', 'text/html');
      res.send(`<html><head><style>${cssFile}</style></head><body>${html}</body></html>`);
    } else {
      // Script/robot request, send JSON response
      res.status(500).send(json);
    }
  });
}

/* precisa arrumar
async function mangar(req, res) {
 let apikey = req.query.apikey
 let nome = req.query.nome
 let capitulo = req.query.capitulo
 if (!apikey) return res.sendFile(paramtroerro)
 if (!nome) return res.sendFile(paramtroerro) 
 if (!capitulo) return res.sendFile(paramtroerro) 	
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
 await limitAdd(apikey);
await expfarm(apikey);
mangas(nome, capitulo).then(resultado => {
res.json(resultado)
}).catch(error => {
console.log(error);
res.status(500).send({
status: 500,
mensagem: 'Erro no Servidor Interno'
})
});
}*/

async function mangatds(req, res) {
 let apikey = req.query.apikey
 let nome = req.query.nome
 let capitulo = req.query.capitulo
 if (!apikey) return res.sendFile(paramtroerro)
 if (!nome) return res.sendFile(paramtroerro) 
 if (!capitulo) return res.sendFile(paramtroerro) 	
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
 await limitAdd(apikey);
await expfarm(apikey);
mangatodos(nome, capitulo).then(resultado => {
res.json(resultado)
}).catch(error => {
console.log(error);
res.status(500).send({
status: 500,
mensagem: 'Erro no Servidor Interno'
})
});
}

async function animesonlines(req, res) {
 let apikey = req.query.apikey
 let nome = req.query.nome
 if (!apikey) return res.sendFile(paramtroerro)
 if (!nome) return res.sendFile(paramtroerro) 
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
 await limitAdd(apikey);
await expfarm(apikey);
animesonline(nome).then(resultado => {
res.json(resultado)
}).catch(error => {
console.log(error);
res.status(500).send({
status: 500,
mensagem: 'Erro no Servidor Interno'
})
});
}

async function hentaiwordr(req, res) {
 let apikey = req.query.apikey
 let nome = req.query.nome
 if (!apikey) return res.sendFile(paramtroerro)
 if (!nome) return res.sendFile(paramtroerro) 
 let check = await verificaKey(apikey)
 if (!check) return res.sendFile(semapikey)
 let limit = await isLimit(apikey);
 if (limit) return res.sendFile(semlimit)
 await limitAdd(apikey);
await expfarm(apikey);
hentaiword(nome).then(resultado => {
res.json(resultado)
}).catch(error => {
console.log(error);
res.status(500).send({
status: 500,
mensagem: 'Erro no Servidor Interno'
})
});
}







module.exports = { 
waifu,
hentaiwordr,
hentaisrandoms,
animesrandoms,
//mangar,
animesonlines,
mangatds,
pesquisamanga,
frasesanimes,
pesquisamangatrevo,
dlmangatrevor,
mangxx,
animeStatus2,
animeStatus
}
