const axios = require('axios')
const fetch = require('node-fetch')
const FormData = require('form-data')
const FileType = require('file-type')
const fs = require('fs')
const { fromBuffer } = FileType

async function uptotelegra (input) {
	return new Promise(async (resolve, reject) => {
		const form = new FormData();
		let fileStream;

		if (Buffer.isBuffer(input)) {
			fileStream = input;
			form.append("files[]", fileStream, "uploaded-file.jpg");
		} else if (typeof input === "string") {
			fileStream = fs.createReadStream(input);
			form.append("files[]", fileStream);
		} else {
			return reject(new Error("Invalid input type"));
		}

		try {
			const response = await axios({
				url: "https://uguu.se/upload.php",
				method: "POST",
				headers: {
					"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36",
					...form.getHeaders(),
				},
				data: form,
			});
			resolve(response.data.files[0].url);
		} catch (error) {
			reject(error);
		}
	});
}

module.exports.TelegraPh = uptotelegra
