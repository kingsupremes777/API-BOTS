<h1 id="BuildOptions">BuildOptions</h1>

<h2>Properties</h2>

PARAMETER | TYPE | DESCRIPTION | EXAMPLE
--- | --- | --- | ---
name | [String](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String) | Font name | Manrope
path | [String](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String) | Font path | /fonts/Manrope.ttf