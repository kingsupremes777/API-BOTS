const fs = require("fs");
const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");

module.exports = async (img) => {
  
  const canvasWidth = 735;
      const canvasHeight = 909;

      const centerX = canvasWidth / 2;
      const centerY = canvasHeight / 2;

      const canvas = createCanvas(canvasWidth, canvasHeight);
      const ctx = canvas.getContext("2d");

      await loadImage('./func.backend/canvas/adorartv/img/base.png').then(async (image) => {
        const scale = Math.max(
          canvasWidth / image.width,
          canvasHeight / image.height
        );
        const imageWidth = image.width * scale;
        const imageHeight = image.height * scale;
        const imageX = (canvasWidth - imageWidth) / 2;
        const imageY = (canvasHeight - imageHeight) / 2;

      await loadImage(img).then((image) => {
        ctx.save();
        ctx.rotate(- 0.05);
        ctx.drawImage(image, 350, 10, 400, 400);
        ctx.restore();
      });
        ctx.drawImage(image, imageX, imageY, imageWidth, imageHeight);
       
      })
  return canvas.toBuffer("image/png")
}



