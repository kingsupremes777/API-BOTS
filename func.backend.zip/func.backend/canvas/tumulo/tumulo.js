const fs = require("fs");
const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");

        function drawImage(ctx, image, x, y, w, h, degrees) {
            ctx.save();
            ctx.translate(x + w / 2, y + h / 2);
            ctx.rotate(degrees * Math.PI / 180.0);
            ctx.translate(-x - w / 2, -y - h / 2);
            ctx.drawImage(image, x, y, w, h);
            ctx.restore();
        }

module.exports = async (img) => {
  
  const canvasWidth = 680;
      const canvasHeight = 609;

      const centerX = canvasWidth / 2;
      const centerY = canvasHeight / 2;

      const canvas = createCanvas(canvasWidth, canvasHeight);
      const ctx = canvas.getContext("2d");

      await loadImage('https://telegra.ph/file/aacff9407f5e05eb61c22.png').then(async (image) => {
        const scale = Math.max(
          canvasWidth / image.width,
          canvasHeight / image.height
        );
        const imageWidth = image.width * scale;
        const imageHeight = image.height * scale;
        const imageX = (canvasWidth - imageWidth) / 2;
        const imageY = (canvasHeight - imageHeight) / 2;
        ctx.drawImage(image, imageX, imageY, imageWidth, imageHeight);
        
      await loadImage(img).then((image) => {
        drawImage(ctx, image,102,145, 145, 140, -4);
      });
        
       
      })
  return canvas.toBuffer("image/png")
}



