const fs = require("fs");
const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");

        function drawImage(ctx, image, x, y, w, h, degrees) {
            ctx.save();
            ctx.translate(x + w / 2, y + h / 2);
            ctx.rotate(degrees * Math.PI / 180.0);
            ctx.translate(-x - w / 2, -y - h / 2);
            ctx.drawImage(image, x, y, w, h);
            ctx.restore();
        }

module.exports = async (img) => {
  
  const canvasWidth = 400;
      const canvasHeight = 400;

      const centerX = canvasWidth / 2;
      const centerY = canvasHeight / 2;

      const canvas = createCanvas(canvasWidth, canvasHeight);
      const ctx = canvas.getContext("2d");

      await loadImage('https://telegra.ph/file/74e3565b3d4dcfd111a7f.png').then(async (image) => {
        const scale = Math.max(
          canvasWidth / image.width,
          canvasHeight / image.height
        );
        const imageWidth = image.width * scale;
        const imageHeight = image.height * scale;
        const imageX = (canvasWidth - imageWidth) / 2;
        const imageY = (canvasHeight - imageHeight) / 2;
      await loadImage(img).then((image) => {
        ctx.save();
        ctx.rotate(- 0.01);
        ctx.drawImage(image, 24,60, 163, 126);
        ctx.restore();
      });
        ctx.drawImage(image, imageX, imageY, imageWidth, imageHeight);
       
      })
  return canvas.toBuffer("image/png")
}



