const fs = require("fs");
const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");
GlobalFonts.registerFromPath("./fonts/Bangers.ttf", "banger");

module.exports = async (img, img2, texto, texto2, texto3, cor1, cor2, cor3) => {
   try {
   const canvasWidth = 1028;
  const canvasHeight = 1028;

  const centerX = canvasWidth / 2;
  const centerY = canvasHeight / 2;

  const canvas = createCanvas(canvasWidth, canvasHeight);
  const ctx = canvas.getContext("2d");
  

  await loadImage('./func.backend/canvas/bemvindo/img/base.png').then(async (image) => {
    const scale = Math.max(
      canvasWidth / image.width,
      canvasHeight / image.height
    );
    const imageWidth = image.width * scale;
    const imageHeight = image.height * scale;
    const imageX = (canvasWidth - imageWidth) / 2;
    const imageY = (canvasHeight - imageHeight) / 2;
    ctx.save();
    ctx.beginPath();
    ctx.fillStyle = cor3; 
    ctx.roundRect(imageX, imageY, imageWidth, imageHeight, -20);
    ctx.fill();
    ctx.restore();

    await loadImage(img2).then((image) => {
    ctx.save();
    ctx.beginPath();
    ctx.strokeStyle = cor2; 
    ctx.lineWidth = 15; 
    ctx.roundRect(450, 60, 540, 900, 100);
    ctx.clip();
    ctx.drawImage(image, 450, 60, 540, 900);
    ctx.stroke(); 
    ctx.restore();
    });
    
    ctx.save();
    ctx.beginPath();
    ctx.strokeStyle = cor2; 
    ctx.lineWidth = 15; 
    ctx.filter = 'blur(10px)';
    ctx.fillStyle = '#000'; 
    ctx.globalAlpha = 0.5;
    ctx.roundRect(225, 82, 520, 120, 20);
    ctx.fill();
    ctx.stroke(); 
    ctx.restore();
    
    ctx.save();
    ctx.beginPath();
    ctx.strokeStyle = cor2; 
    ctx.lineWidth = 15; 
    ctx.filter = 'blur(10px)';
    ctx.fillStyle = '#000'; 
    ctx.globalAlpha = 0.5;
    ctx.roundRect(40, 750, 490, 100, 20);
    ctx.fill();
    ctx.stroke(); 
    ctx.restore();
    
    ctx.save();
    ctx.beginPath();
    ctx.strokeStyle = cor2; 
    ctx.lineWidth = 15; 
    ctx.filter = 'blur(10px)';
    ctx.fillStyle = '#000'; 
    ctx.globalAlpha = 0.5;
    ctx.roundRect(200, 880, 700, 100, 20);
    ctx.fill();
    ctx.stroke(); 
    ctx.restore();
    

    

    await loadImage(img).then((image) => {
    ctx.save();
    ctx.beginPath();
    ctx.shadowColor = cor2; 
    ctx.shadowBlur = 10;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
    ctx.strokeStyle = cor2; 
    ctx.lineWidth = 15; 
    ctx.roundRect(54, 240, 495, 495, 50);
    ctx.clip();
    ctx.drawImage(image, 54, 240, 495, 495);
    ctx.stroke(); 
    ctx.restore();
    });
    
    const textWidth = ctx.measureText(texto).width;
    const x = 210 + (600 - textWidth) / 2;
    const y = 100 + (154) / 2;
    ctx.save();
    ctx.fillStyle = cor1;
    ctx.font = `100px banger`;
    ctx.textAlign = "center";
    ctx.fillText(texto.toUpperCase(), x, y);
    ctx.restore();
    const textWidth2 = ctx.measureText(texto2).width;
    const x2 = -70 + (700 - textWidth2) / 2;
    const y2 = 940 + (100 - 70) / 2;
    ctx.save();
    ctx.fillStyle = cor1;
    ctx.font = `70px banger`;
    ctx.textAlign = "left";
    ctx.fillText(texto2.toUpperCase(), x2, y2);
    ctx.restore();
    const textWidth3 = ctx.measureText(texto3).width;
    const x3 = 55 + (490 - textWidth3) / 2;
    const y3 = 795 + (100 - 45) / 2;
    ctx.save();
    ctx.fillStyle = cor1;
    ctx.font = `65px banger`;
    ctx.textAlign = "center";
    ctx.fillText(texto3.toUpperCase(), x3, y3);
    ctx.restore();
  })
  return canvas.toBuffer("image/png")
  } catch (error) {
    console.error(error);
  }
}
