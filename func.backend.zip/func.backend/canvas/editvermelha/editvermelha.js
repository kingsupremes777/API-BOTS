const fs = require("fs");
const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");

GlobalFonts.registerFromPath("./fonts/Bangers.ttf", "banger");

module.exports = async (img, texto) => {
  
    const canvasWidth = 512;
  const canvasHeight = 512;

  const centerX = canvasWidth / 2;
  const centerY = canvasHeight / 2;

  const canvas = createCanvas(canvasWidth, canvasHeight);
  const ctx = canvas.getContext("2d");

  await loadImage('./func.backend/canvas/editvermelha/img/base.png').then(async (image) => {
    const scale = Math.max(
      canvasWidth / image.width,
      canvasHeight / image.height
    );
    const imageWidth = image.width * scale;
    const imageHeight = image.height * scale;
    const imageX = (canvasWidth - imageWidth) / 2;
    const imageY = (canvasHeight - imageHeight) / 2;
      await loadImage("./func.backend/canvas/editvermelha/img/fundo.png").then((image) => {
      ctx.drawImage(image, imageX, imageY, imageWidth, imageHeight);
    });

    await loadImage(img).then((image) => {
      ctx.save();
      ctx.arc(centerX, 208, 158, 0, 2 * Math.PI);
      ctx.fillStyle = "#ff0000"
      ctx.clip();
      ctx.drawImage(image, centerX - 157, centerY - 205, 315, 315);
      ctx.restore();
    });


   
    ctx.drawImage(image, imageX, imageY, imageWidth, imageHeight);

  
    ctx.save();
    ctx.fillStyle = "#ff0000";
    ctx.filter = 'blur(3px)';
    ctx.font = `100px banger`;
    ctx.textAlign = "center";
    ctx.shadowColor="black";
    ctx.shadowBlur=10;
     ctx.strokeStyle = '#000000'; // outline color
    ctx.lineWidth = 5; // outline width
    ctx.strokeText(texto.toUpperCase(), centerX - 19, centerY + 210);
    ctx.fillText(texto.toUpperCase(), centerX - 19, centerY + 210);
    ctx.restore();
    
    ctx.save();
    ctx.fillStyle = "#ff0000";
    ctx.filter = 'blur(1px)';
    ctx.font = `100px banger`;
    ctx.textAlign = "center";
    ctx.shadowColor="black";
    ctx.shadowBlur=10;
   
    ctx.fillText(texto.toUpperCase(), centerX - 14, centerY + 200);
    ctx.restore();


  })
      await loadImage("./func.backend/canvas/editvermelha/img/reflexo.png").then((image) => {

      ctx.drawImage(image, centerX - 60, centerY - 310, 315, 315);
    });
  return canvas.toBuffer("image/png")
}
