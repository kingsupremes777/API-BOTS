const fs = require("fs");
const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");
GlobalFonts.registerFromPath("./fonts/Bangers.ttf", "banger");

module.exports = async (img, img2, fundo, texto, texto2, texto3, texto4, cor1, cor2) => {
  try {
    const canvasWidth = 1050;
    const canvasHeight = 1028;

    const centerX = canvasWidth / 2;
    const centerY = canvasHeight / 2;

    const canvas = createCanvas(canvasWidth, canvasHeight);
    const ctx = canvas.getContext("2d");

    // Desenhe o fundo branco
    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);

    await loadImage(fundo).then(async (image) => {
      const scale = Math.max(
        canvasWidth / image.width,
        canvasHeight / image.height
      );
      const imageWidth = image.width * scale;
      const imageHeight = image.height * scale;
      const imageX = (canvasWidth - imageWidth) / 2;
      const imageY = (canvasHeight - imageHeight) / 2;
      ctx.drawImage(image, imageX, imageY, imageWidth, imageHeight);
    });
    
    
     //círculo azul no centro
    ctx.fillStyle = "#000"; // Cor azul
    ctx.beginPath();
    ctx.arc(centerX - 20, centerY - 20, 0, 0, 2 * Math.PI); // Raio de 50 pixels
    ctx.fill();
    
    //linha 2
    ctx.save();
    ctx.strokeStyle = cor2; 
    ctx.lineWidth = 15; 
    ctx.filter = 'blur(10px)';
    ctx.fillStyle = '#000'; 
    ctx.globalAlpha = 1;
    ctx.fillStyle = cor2;
    ctx.beginPath();
    ctx.roundRect(centerX + 190, centerY  +260, 20, 155, -20);
    ctx.fill();
    ctx.stroke(); 
    ctx.restore() 

    // bolha 2
    ctx.save();
    ctx.beginPath();
    ctx.strokeStyle = cor2; 
    ctx.lineWidth = 15; 
    ctx.filter = 'blur(10px)';
    ctx.fillStyle = '#000'; 
    ctx.globalAlpha = 1;
    ctx.fillStyle = cor2; // Cor verde
    ctx.arc(centerX + 190, centerY  +190, 180, 0, 2 * Math.PI); 
    ctx.fill();
    ctx.stroke(); 
    ctx.restore()
    
        // bolha 2.1
     await loadImage(img2).then((image) => {
    ctx.save();
    ctx.beginPath();
    ctx.fillStyle = cor2; // Cor verde
    ctx.arc(centerX + 190, centerY  +190, 170, 0, 2 * Math.PI); 
    ctx.clip();
    ctx.drawImage(image, centerX +15, centerY  +16, 350, 350);
    ctx.restore()
   })
    
    
     //linha 1
    ctx.save();
    ctx.strokeStyle = cor2; 
    ctx.lineWidth = 15; 
    ctx.filter = 'blur(10px)';
    ctx.fillStyle = '#000'; 
    ctx.globalAlpha = 1;
    ctx.fillStyle = cor2;
    ctx.beginPath();
    ctx.roundRect(280, 590, 20, 155, 20);
    ctx.fill();
    ctx.stroke(); 
    ctx.restore()
    
    // bolha 1 
    ctx.save();
    ctx.beginPath();
    ctx.strokeStyle = cor2; 
    ctx.lineWidth = 15; 
    ctx.filter = 'blur(10px)';
    ctx.fillStyle = '#000'; 
    ctx.globalAlpha = 1;
    ctx.fillStyle = cor2;
    ctx.arc(centerX + -230, centerY  -145, 225, 0, 2 * Math.PI); 
    ctx.fill();
    ctx.stroke(); 
    ctx.restore()
    //bolha 1.2
    await loadImage(img).then((image) => {
    ctx.save();
    ctx.beginPath();
    ctx.fillStyle = cor2; 
    ctx.arc(centerX + -230, centerY  -145, 215, 0, 2 * Math.PI); 
    ctx.clip();
    ctx.drawImage(image, centerX + -450, centerY  -364, 440, 440);
    ctx.restore()
   });
    
    
    //caixa do texto 1
    ctx.save();
    ctx.beginPath();
    ctx.strokeStyle = cor2; 
    ctx.lineWidth = 15; 
    ctx.filter = 'blur(10px)';
    ctx.fillStyle = '#000'; 
    ctx.globalAlpha = 1;
    ctx.roundRect(475, 82, 520, 120, 20);
    ctx.fill();
    ctx.stroke(); 
    ctx.restore();
    //caixa do texto 2
    ctx.save();
    ctx.beginPath();
    ctx.strokeStyle = cor2; 
    ctx.lineWidth = 15; 
    ctx.filter = 'blur(10px)';
    ctx.fillStyle = '#000'; 
    ctx.globalAlpha = 1;
    ctx.roundRect(40, 750, 490, 100, 20);
    ctx.fill();
    ctx.stroke(); 
    ctx.restore();
    //caixa do texto 3
ctx.save();
ctx.beginPath();
ctx.strokeStyle = cor2; 
ctx.lineWidth = 15; 
ctx.filter = 'blur(10px)';
ctx.fillStyle = '#000'; 
ctx.globalAlpha = 1;
ctx.translate(centerX, centerY); // Move the origin to the center
ctx.rotate(Math.PI / -3.7); // Rotate by 45 degrees
ctx.roundRect(-200, -34, 320, 100, 20);
ctx.fill();
ctx.stroke(); 
ctx.restore();

    //caixa do texto 4
    ctx.save();
    ctx.beginPath();
    ctx.strokeStyle = cor2; 
    ctx.lineWidth = 15; 
    ctx.filter = 'blur(10px)';
    ctx.fillStyle = '#000'; 
    ctx.globalAlpha = 1;
    ctx.roundRect(500, 930, 490, 80, 20);
    ctx.fill();
    ctx.stroke(); 
    ctx.restore();
    
    //textos
    
    // txt 1
 const textWidth = ctx.measureText(texto).width;
    const x = 460 + (600 - textWidth) / 2;
    const y = 100 + (154) / 2;
    ctx.save();
    ctx.fillStyle = cor1;
    ctx.font = `100px banger`;
    ctx.textAlign = "center";
    ctx.fillText(texto.toUpperCase(), x, y);
    ctx.restore();
  //txt2
const textWidth2 = ctx.measureText(texto2).width;
const x2 = -textWidth2 / 2;
const y2 = 0;
ctx.save();
ctx.fillStyle = cor1;
ctx.font = `70px banger`;
ctx.textAlign = "center";
ctx.translate(centerX, centerY); // Move the origin to the center
ctx.rotate(Math.PI / -3.7); // Rotate by 45 degrees
ctx.fillText(texto2.toUpperCase(), x2-25, y2+45);
ctx.restore();
    
    //txt3
    const textWidth3 = ctx.measureText(texto3).width;
    const x3 = 55 + (490 - textWidth3) / 2;
    const y3 = 795 + (100 - 45) / 2;
    ctx.save();
    ctx.fillStyle = cor1;
    ctx.font = `65px banger`;
    ctx.textAlign = "center";
    ctx.fillText(texto3.toUpperCase(), x3, y3);
    ctx.restore();
    
     //txt4
    const textWidth4 = ctx.measureText(texto4).width;
    const x4 = 525 + (490 - textWidth4) / 2;
    const y4 = 967 + (100 - 45) / 2;
    ctx.save();
    ctx.fillStyle = cor1;
    ctx.font = `65px banger`;
    ctx.textAlign = "center";
    ctx.fillText(texto4.toUpperCase(), x4, y4);
    ctx.restore();

    return canvas.toBuffer("image/png");
  } catch (error) {
    console.error(error);
  }
};
