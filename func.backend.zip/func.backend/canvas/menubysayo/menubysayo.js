const fs = require("fs");
const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");
GlobalFonts.registerFromPath("./fonts/nue.ttf", "nue");

module.exports = async (avatar, fundo, cores, nomes) => {
  const canvasLargura = 1000;
  const canvasAltura = 600;

  const centerX = canvasLargura / 2;
  const centerY = canvasAltura / 2;

  const canvas = createCanvas(canvasLargura, canvasAltura);
  const ctx = canvas.getContext("2d");

  try {
    const [fundodaimg, image] = await Promise.all([
      loadImage(fundo),
      loadImage(avatar),
    ]);

    const scale = Math.max(
      canvasLargura / fundodaimg.width,
      canvasAltura / fundodaimg.height
    );
    const x = canvas.width / 2;
    const y = canvas.height / 2;
    const imageLargura = fundodaimg.width * scale;
    const imageAltura = fundodaimg.height * scale;
    const imageX = (canvasLargura - imageLargura) / 2;
    const imageY = (canvasAltura - imageAltura) / 2;
    ctx.drawImage(fundodaimg, 0, 0, 1000, 335);
    await loadImage('https://telegra.ph/file/63d7e9139fc107634b762.png').then((image) => {
      ctx.drawImage(image, 0, 0, 1000, 335);
    });

    ctx.fillStyle = "000";
    ctx.beginPath();
    ctx.roundRect(imageX, 335, 1200, 400, -20);
    ctx.fill();

    const numDots = 100;
    const dotRadius = 5;
    for (let i = 0; i < numDots; i++) {
      const x = Math.random() * (imageX + 1200);
      const y = Math.random() * (335 + 400);
      ctx.beginPath();
      ctx.shadowColor = cores.cor3;
      ctx.shadowBlur = 10;
      ctx.shadowOffsetX = 2;
      ctx.shadowOffsetY = 2;
      ctx.fillStyle = cores.cor2;
      ctx.arc(x, y, dotRadius, 0, 2 * Math.PI);
      ctx.fillStyle = cores.cor2;
      ctx.fill();
    }
    ctx.shadowColor = cores.cor2;
    ctx.shadowBlur = 10;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 2;
    ctx.fillStyle = cores.cor1;
    ctx.beginPath();
    ctx.save();
    ctx.globalAlpha = 0.7;
    ctx.roundRect(200, 440, 599, 60, 20); // adjusted y position
    ctx.fill();

    ctx.beginPath();
    ctx.roundRect(300, 505, 400, 60, 20); // adjusted y position
    ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.fillStyle = cores.cor3;
    ctx.font = `50px nue`;
    ctx.textAlign = "center";
    ctx.shadowColor = cores.cor2;
    ctx.shadowBlur = 100;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
    ctx.fillText(nomes.nome1, centerX, centerY + 180); // adjusted y position
    ctx.font = `30px nue`;
    ctx.fillText(nomes.nome2, centerX, centerY + 240); // adjusted y position
    ctx.restore();

    ctx.beginPath();
    ctx.shadowColor = cores.cor2;
    ctx.shadowBlur = 50;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
    ctx.arc(centerX, centerY, 135, 0, 2 * Math.PI);
    ctx.fillStyle = cores.cor2;
    ctx.fill();

    ctx.beginPath();
    ctx.arc(centerX, centerY, 130, 0, 2 * Math.PI);
    ctx.clip();
    ctx.drawImage(image, centerX - 130, centerY - 130, 260, 260);

  return canvas.toBuffer("image/png")
  } catch (error) {
    console.error(error);
  }
}
