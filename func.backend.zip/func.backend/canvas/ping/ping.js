const fs = require("fs");
const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");

GlobalFonts.registerFromPath("./fonts/Bangers.ttf", "banger");
// Função para desenhar um retângulo com bordas circulares
function roundRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.arcTo(x + width, y, x + width, y + radius, radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.arcTo(x + width, y + height, x + width - radius, y + height, radius);
  ctx.lineTo(x + radius, y + height);
  ctx.arcTo(x, y + height, x, y + height - radius, radius);
  ctx.lineTo(x, y + radius);
  ctx.arcTo(x, y, x + radius, y, radius);
  ctx.closePath();
}
module.exports = async (nome, ping, img, img2, cor1, cor2) => {
  
    const canvasWidth = 700;
    const canvasHeight = 900;

    const centerX = canvasWidth / 2;
    const centerY = canvasHeight / 2;

    const canvas = createCanvas(canvasWidth, canvasHeight);
    const ctx = canvas.getContext("2d");

   

      ctx.fillStyle = cor2;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);

    
     
    
    await loadImage(img).then((image) => {
      // Desenhar o círculo
      ctx.save();
      ctx.arc(centerX-200, centerY+300, 150, 0, 2 * Math.PI); 
      ctx.strokeStyle = cor1; // cor da borda
      ctx.lineWidth = 10; // largura da borda
      ctx.shadowColor = cor1; // cor da sombra
      ctx.shadowBlur = 10; // intensidade da sombra
      ctx.stroke(); // desenhar a borda
      ctx.clip();
      ctx.drawImage(image, centerX + -348, centerY  +150, 297, 297);
      ctx.restore()
    });
    await loadImage(img2).then((image) => {
      // Desenhar o retângulo amarelo com bordas arredondadas
        ctx.save();
      ctx.fillStyle = "#ffff00";
      roundRect(ctx, centerX - 340, 0, 680, 350, 20);
      ctx.clip();
       ctx.drawImage(image, centerX + -340, 0,  680, 350);
       ctx.restore()
        });
     ctx.save();
    // Desenhar o retângulo com bordas circulares
    ctx.strokeStyle = cor1;
    ctx.lineWidth = 5; // largura da borda
    ctx.shadowColor = cor1;
    ctx.shadowBlur = 50; // embaçamento das bordas
    roundRect(ctx, centerX-250, centerY-50, 600, 150, 20);
    ctx.stroke();
    ctx.shadowBlur = 0; // remover o efeito de embaçamento
     ctx.restore()
      // Desenhar o texto dentro do retângulo
      ctx.font = '60px "banger"';
      ctx.fillStyle = cor1; 
      ctx.textAlign = "center";
      ctx.fillText(ping, centerX+45, centerY+45);


    ctx.font = '90px "banger"';
    ctx.fillStyle = cor1;
    ctx.textAlign = "center";
    ctx.shadowColor = cor2;
    ctx.shadowBlur = 5;
    ctx.strokeStyle = '#000'; 
    ctx.lineWidth = 0; 

    const texto = nome;
    const espaco = 45; 
    const x = centerX + -0;
    const y = centerY + 340;

    for (let i = 0; i < texto.length; i++) {
      ctx.strokeText(texto[i].toUpperCase(), x + 10 + (i * espaco), y+15);
      ctx.fillText(texto[i].toUpperCase(), x + (i * espaco), y);
    }
  return canvas.toBuffer("image/png")
}
