const fs = require("fs");
const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");
GlobalFonts.registerFromPath("./fonts/nue.ttf", "nue");

module.exports = async (avatar, fundo, cor1, cor2, cor3, nome1, nome2) => {
   try {
   const canvasWidth = 1280;
  const canvasHeight = 550;

  const centerX = canvasWidth / 2;
  const centerY = canvasHeight / 2;

  const canvas = createCanvas(canvasWidth, canvasHeight);
  const ctx = canvas.getContext("2d");


     await loadImage(fundo).then(async (image) => {
       const scale = Math.max(
         canvasWidth / image.width,
         canvasHeight / image.height
       );
       const imageWidth = image.width * scale;
       const imageHeight = image.height * scale;
       const imageX = (canvasWidth - imageWidth) / 2;
       const imageY = (canvasHeight - imageHeight) / 2;

       // Draw the image with a blur effect
       ctx.fillStyle = cor1; // black color
       ctx.fillRect(0, 0, canvasWidth, canvasHeight);

       ctx.save();

  

       
       ctx.save();
       ctx.beginPath();
       ctx.strokeStyle = cor2; 
       ctx.lineWidth = 5;
       ctx.fillStyle = '#000'; 
        ctx.globalAlpha = 1;
        ctx.roundRect(35, 0, 1200, 350, 20);
        ctx.clip();
       ctx.drawImage(image, 35, 0, 1200, 350)
        ctx.stroke(); 
        ctx.restore();
        ctx.save();
       

         //bolha 1.2
         await loadImage(avatar).then((image) => {
         ctx.save();
         ctx.beginPath();
         ctx.strokeStyle = cor2;
           ctx.lineWidth = 5; 
         ctx.fillStyle = "#000"; 
         ctx.arc(250, 350, 200, 0, 2 * Math.PI); 
         ctx.clip();
         ctx.drawImage(image, 50, 150, 450, 450);
           ctx.stroke(); 
         ctx.restore()
        });

       ctx.save();
       ctx.beginPath();
       ctx.strokeStyle = cor2; 
       ctx.lineWidth = 5; 
       ctx.fillStyle = '#000'; 
       ctx.roundRect(460, 453, 500, 60, 20);
       ctx.fill();
       ctx.stroke(); 
       ctx.restore();
       ctx.save();
       ctx.fillStyle = cor2;

       ctx.save();
        ctx.beginPath();
        ctx.strokeStyle = cor2; 
        ctx.lineWidth = 5; 
        ctx.fillStyle = '#000'; 
        ctx.roundRect(460, 360, 700, 80, 20);
        ctx.fill();
        ctx.stroke(); 
        ctx.restore();
        ctx.save();
        ctx.fillStyle = cor3;
    
       ctx.font = `60px nue`;
       ctx.textAlign = "left";
       ctx.shadowColor="black";
       ctx.shadowBlur=10;
       ctx.fillText(nome1.toUpperCase(), 475, 420);
       ctx.restore();

       ctx.save();
       ctx.fillStyle = cor3;
       ctx.filter = 'blur(0px)';
       ctx.font = `40px nue`;
       ctx.textAlign = "left";
       ctx.shadowColor="black";
       ctx.shadowBlur=10;
       ctx.fillText(nome2.toUpperCase(), 475, 500);
         ctx.restore();
     })
 return canvas.toBuffer("image/png")
  } catch (error) {
    console.error(error);
  }
}
