const fs = require("fs");
const { createCanvas, loadImage, GlobalFonts } = require("@napi-rs/canvas");

GlobalFonts.registerFromPath("./fonts/Bangers.ttf", "banger");

module.exports = async (img, texto) => {
  
  const canvasWidth = 1280;
  const canvasHeight = 1278;

  const centerX = canvasWidth / 2;
  const centerY = canvasHeight / 2;

  const canvas = createCanvas(canvasWidth, canvasHeight);
  const ctx = canvas.getContext("2d");

  await loadImage('./func.backend/canvas/editcanvas/img/base.png').then(async (image) => {
    const scale = Math.max(
      canvasWidth / image.width,
      canvasHeight / image.height
    );
    const imageWidth = image.width * scale;
    const imageHeight = image.height * scale;
    const imageX = (canvasWidth - imageWidth) / 2;
    const imageY = (canvasHeight - imageHeight) / 2;
    await loadImage('./func.backend/canvas/editcanvas/img/fundo.png').then((image) => {
      ctx.drawImage(image, imageX, imageY, imageWidth, imageHeight);
    });

    await loadImage(img).then((image) => {
      ctx.drawImage(image, imageX, imageY, imageWidth, imageHeight);
    });

  
 

    await loadImage('./func.backend/canvas/editcanvas/img/gradiante.png').then((image) => {
 
      ctx.drawImage(image, imageX, -125, imageWidth, imageHeight);
    });
    ctx.save();
    ctx.fillStyle = "#c000ff";
    ctx.filter = 'blur(3px)';
    ctx.font = `300px banger`;
    ctx.textAlign = "center";
    ctx.shadowColor="black";
    ctx.shadowBlur=150;
    ctx.lineWidth=50;
    ctx.fillText(texto.toUpperCase(), 605, centerY + 360);
    ctx.restore();
    ctx.drawImage(image, imageX, imageY, imageWidth, imageHeight);

  })
  return canvas.toBuffer("image/png")
}
