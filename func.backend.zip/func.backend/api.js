const axios = require("axios");
const cheerio = require("cheerio");
const request = require('request');
const { youtubedl, youtubedlv2, youtubedlv3 } = require('@bochilteam/scraper')
const yts = require("yt-search")
const fs = require("fs");
const { Chatbot, GeminiInput, SupportedChatModels } = require('intellinode');
const { JSDOM } = require('jsdom');
const fetch = require('node-fetch');
const { ndown } = require("nayan-media-downloader")

const scrapeZacaNoticias = async () => {
  try {
    // Configuração dos headers para simular um navegador
    const headers = {
      "Accept-Language": "pt-BR,pt;q=0.9",
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    };

    // Envia a requisição e carrega o HTML
    const response = await axios.get("https://portaldozacarias.com.br/site/noticias/so-videos/", { headers });
    const $ = cheerio.load(response.data);

    // Cria uma array para armazenar os dados das notícias
    const noticiasData = [];

    // Procura pelas notícias na página
    const noticias = $('.noticias-interna li');

    // Loop pelas notícias
    noticias.each((index, element) => {
      const titulo = $(element).find('.titulo-noticias a').text().trim();
      const link = "https://portaldozacarias.com.br/site/" + $(element).find('.titulo-noticias a').attr('href');
      const imagem = "https://portaldozacarias.com.br/site/"+$(element).find('.foto img').attr('src');

      // Cria um objeto com os dados da notícia
      const noticiaInfo = {
        titulo: titulo,
        link: link,
        imagem: imagem
      };

      // Adiciona o objeto ao array
      noticiasData.push(noticiaInfo);
    });

    return noticiasData;

  } catch (error) {
    console.error(`Erro ao carregar a página: ${error.message}`);
    return { erro_na_solicitacao: "Erro ao carregar a página" };
  }
};


const scrapeDetalhesNoticia = async (url) => {
  try {
    // Configuração dos headers para simular um navegador
    const headers = {
      "Accept-Language": "pt-BR,pt;q=0.9",
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    };

    // Envia a requisição e carrega o HTML
    const response = await axios.get(url, { headers });
    const $ = cheerio.load(response.data);

    // Extrai as informações da notícia
    const titulo = $('h1.titulo').text().trim();
    const data = $('.data').eq(1).text().trim();
    const conteudo = $('#corpo').text().trim();

    // Extrai as imagens relacionadas à notícia
    const imagens = [];
    $('.imagem-interna img').each((index, element) => {
      const src = "https://portaldozacarias.com.br/site/" + $(element).attr('src');
      if (src) {
        imagens.push(src);
      }
    });

    // Extrai os vídeos relacionados à notícia
    const videos = [];
    $('.video-vd source').each((index, element) => {
      const src = "https://portaldozacarias.com.br/site/" + $(element).attr('src');
      if (src) {
        videos.push(src);
      }
    });

    // Cria um objeto com os dados da notícia
    const noticiaInfo = {
      titulo,
      data,
      conteudo,
      imagens,
      videos
    };

    return noticiaInfo;

  } catch (error) {
    console.error(`Erro ao carregar a página: ${error.message}`);
    return { erro_na_solicitacao: "Erro ao carregar a página" };
  }
};


const scrapeNoticias = async () => {
  try {
    const headers = {
      "Accept-Language": "pt-BR,pt;q=0.9",
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    };

    const response = await axios.get("https://portaldozacarias.com.br/site/noticias/so-videos/", { headers });
    const $ = cheerio.load(response.data);

    const noticiasData = [];

    $('.noticias-interna li').each((index, element) => {
      const titulo = $(element).find('.titulo-noticias a').text().trim();
      const link = "https://portaldozacarias.com.br/site/" + $(element).find('.titulo-noticias a').attr('href');
      
      noticiasData.push({ titulo, link });
    });

    return noticiasData;

  } catch (error) {
    console.error(`Erro ao carregar a página: ${error.message}`);
    return [];
  }
};

const scrapeDetalhesNoticiaz = async (url) => {
  try {
    const headers = {
      "Accept-Language": "pt-BR,pt;q=0.9",
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    };

    const response = await axios.get(url, { headers });
    const $ = cheerio.load(response.data);

    const videos = [];
    const titulo = $('h1.titulo').text().trim();

    $('.video-vd source').each((index, element) => {
      const src = $(element).attr('src');
      if (src) {
        videos.push({ titulo, video: "https://portaldozacarias.com.br/site/" + src });
      }
    });

    return videos;

  } catch (error) {
    console.error(`Erro ao carregar a página: ${error.message}`);
    return [];
  }
};

const scrapeAllVideos = async () => {
  const noticias = await scrapeNoticias();
  let allVideos = [];

  for (const noticia of noticias) {
    const videos = await scrapeDetalhesNoticiaz(noticia.link);
    allVideos = allVideos.concat(videos);
  }

  return allVideos;
};


const animeshentaiPesquisa = async (nome) => {
  try {
    // Configuração da requisição
    const headers = {
      "Accept-Language": "pt-BR,pt;q=0.9",
      "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "user-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
    };

    // Envia a requisição e carrega o HTML
    const response = await axios.get("https://animeshentai.tv/?s=" + nome, { headers });
    const $ = cheerio.load(response.data);

    // Cria uma array para armazenar os dados dos animes
    const animeData = [];

    // Procura pelos animes na página
    const animeBlocks = $('.post');

    // Loop pelos animes
    animeBlocks.each((index, element) => {
      const animeTitle = $(element).find('.entry-title').text();
      const animeImage = $(element).find('img').attr('src');
      const animeLink = $(element).find('a.lnk-blk').attr('href');
      const animeViews = $(element).find('.views').text();
      const animeEpisode = $(element).find('.num-episode').text();
      const animeQuality = $(element).find('.quality').text();
      const animeLang = $(element).find('.lang img').attr('alt');

      // Cria um objeto com os dados do anime
      const animeInfo = {
        titulo: animeTitle,
        imagem: animeImage,
        link: animeLink,
        views: animeViews,
        episodio: animeEpisode,
        qualidade: animeQuality,
        idioma: animeLang
      };

      // Adiciona o objeto ao array
      animeData.push(animeInfo);
    });

    return animeData;

  } catch (error) {
    console.error(`Erro ao carregar a página: ${error.message}`);
    return { erro_na_solicitacao: "Chame: 5562936180708" };
  }
};

const xnxxPesquisa = async (nome) => {
  try {
    // Configuração da requisição
    const headers = {
      "Accept-Language": "pt-BR,pt;q=0.9",
      "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "user-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
    };

    // Envia a requisição e carrega o HTML
    const response = await axios.get("https://www.xnxx.com/search/"+nome, { headers });
    const $ = cheerio.load(response.data);

    // Cria uma array para armazenar os dados dos vídeos
    const videoData = [];

    // Procura pelos vídeos na página
    const videoBlocks = $('.thumb-block');

    // Loop pelos vídeos
    videoBlocks.each((index, element) => {
      const videoId = $(element).attr('data-id');
      const videoTitle = $(element).find('.thumb-under p a').text();
      const capa = $(element).find('img').attr('src');
      const link = "https://www.xnxx.com"+$(element).find('a').attr('href');

      // Cria um objeto com os dados do vídeo
      const videoInfo = {
        id: videoId,
        titulo: videoTitle,
        link: link
      };

      // Adiciona o objeto ao array
      videoData.push(videoInfo);
    });

    return videoData;

  } catch (error) {
    console.error(`Erro ao carregar a página: ${error.message}`);
    return { erro_na_solicitacao: "Chame: 5562936180708" };
  }
};

const xnxxDownload = async (url) => {
  try {
    // Configuração da requisição
    const headers = {
      "Accept-Language": "pt-BR,pt;q=0.9",
      "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "user-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
    };

    // Envia a requisição e carrega o HTML
    const response = await axios.get(url, { headers });
    const $ = cheerio.load(response.data);

    // Cria uma array para armazenar os dados do vídeo
    const videoData = [];

    // Procura pelo script com o tipo application/ld+json
    const scriptTag = $('script[type="application/ld+json"]');

    if (scriptTag.length > 0) {
      const jsonData = JSON.parse(scriptTag.text());
      const videoInfo = {
        titulo: jsonData.name,
        descricao: jsonData.description,
        thumbnail: jsonData.thumbnailUrl[0],
        dataDePublicacao: jsonData.uploadDate,
        duracao: jsonData.duration,
        visualizacoes: jsonData.interactionStatistic.userInteractionCount,
        urlDoVideo: jsonData.contentUrl
      };
      videoData.push(videoInfo);
    } else {
      console.log('Não foi encontrado o script com o JSON');
    }

    return videoData;

  } catch (error) {
    console.error(`Erro ao carregar a página: ${error.message}`);
    return { erro_na_solicitacao: "Chame: 5562936180708" };
  }
};

const xvideosDown = async (url) => {
  try {
    // Configuração da requisição
    const headers = {
      "Accept-Language": "pt-BR,pt;q=0.9",
      "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "user-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
    };

    // Envia a requisição e carrega o HTML
    const response = await axios.get(url, { headers });
    const $ = cheerio.load(response.data);

    // Cria uma array para armazenar os dados do vídeo
    const videoData = [];

    // Procura pelo script com o tipo application/ld+json
    const scriptTag = $('script[type="application/ld+json"]');

    if (scriptTag.length > 0) {
      const jsonData = JSON.parse(scriptTag.text());
      const videoInfo = {
        titulo: jsonData.name,
        descricao: jsonData.description,
        duracao: jsonData.duration,
        dataDePublicacao: jsonData.uploadDate,
        download: jsonData.contentUrl
      };
      videoData.push(videoInfo);
    } else {
      console.log('Não foi encontrado o script com o JSON');
    }

    return videoData;

  } catch (error) {
    console.error(`Erro ao carregar a página: ${error.message}`);
    return { erro_na_solicitacao: "Chame: 5562936180708" };
  }
};

async function tiktokSearch(query) {
  return new Promise(async (resolve, reject) => {
    try {
      const response = await fetch("https://tikwm.com/api/feed/search", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          Cookie: "current_language=en",
          "User-Agent":
            "Mozilla/5.0 (Linux Android 10 K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
        },
        body: new URLSearchParams({
          keywords: query,
          count: 10,
          cursor: 0,
          HD: 1,
        }),
      }).then((v) => v.json());
      const videos = response.data.videos;
      if (videos.length === 0) {
        reject("Tidak ada video ditemukan.");
      } else {
        const dann = Math.floor(Math.random() * videos.length);
        const video = videos.map((v) => {
          return {
            titulo: v.title,
            cover: v.cover,
            original_cover: v.origin_cover,
            link: `https://www.tiktok.com/@${v.author.unique_id}/video/${v.video_id}`,
            sem_marcadDgua: v.play,
            marcaDgua: v.wmplay,
            musica: v.music_info,
            visualisacoes: v.play_count,
            likes: v.digg_count,
            comentarios: v.comment_count || null,
            compartilhamentos: v.share_count,
            download: v.download_count || null,
            saves: v.collect_count || null,
            data: v.create_time * 1000,
          };
        });

        resolve(video);
      }
    } catch (error) {
      reject(error);
    }
  });
}

const pindl = async (link) => {
  try {
    const html = await axios.get('https://www.savepin.app/download.php?url='+link,{
      headers: {
        "Accept-Language" : "pt-BR,pt;q=0.9",
        "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
      }
    })
    const $ = cheerio.load(html.data);
    const resultados = [];

    $('table tbody tr').each((index, element) => {
      const qualidade = $(element).find('td.video-quality').text().trim();
      const href = $(element).find('td a').attr('href');
      if (href.includes("force-save.php?url=")) {
        if (qualidade === "Thumbnail") {
          const linkDownload = decodeURIComponent(href.split("url=")[1])
          resultados.push({ tipo: 'imagem', url: linkDownload });
        } else if (href.endsWith('.gif')) {
          const linkDownload = decodeURIComponent(href.split("url=")[1])
          resultados.push({ tipo: 'gif', url: linkDownload });
        } else {
          const linkDownload = decodeURIComponent(href.split("url=")[1])
          resultados.push({ tipo: 'vídeo', qualidade: qualidade, url: linkDownload });
        }
      }
    });

    return resultados;
  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

const pinterestVideoUrl = async (nome) => {
  try {
    const html = await axios.get(`https://br.pinterest.com/search/pins/?q=${nome}`, {
      headers: {
        "cookie" : '_auth=1; _pinterest_sess=TWc9PSZ2NjR5RStuSUo4c0ZtN1dCMDRHdFk0TlNUV3BpNkg2RGd4UVVKTUYrVW1TNjJHL1hsOGpaSTlJWnhITnA0S3Fnc2R5MXIzYy9ITFF3WG5PS3Jzb1ptUkxNMTVDeTR3WGhGaXFncVNoeVllbm5Vdk5ZR042a3RFeDhocU83SG1XZHJQVEhya3lYeXorWXZsa045Y1ovQlRpM0tPb1FML0RobEFFTGx5RDhHZVl4WnNFTUpTV2RnSUpDRTdMUDNHWGVwakhvU0FjRWdEMFhhUGc2YmE1UUpFaXdra2NRaFgzOCt0YTVScDRWRGx0M1BaSzJCUXA3RjNlMnVubTNhSUpUNGZVYzljamIvZXdjRUFVVUlKSElOb2p6SzFxRGVrRGZCT2lTVHBtdFBGWHcxa2R6dHlqM2JnNTNldjFEZ3pwOEZ3Q3FuekRWcWNtTGcyS0tvZG5PUmo1ZXdFU25iSkxyY2RLS2N1K0I1emllUkUzc1RYemJoZG80TVliczB5OXh5eXpDUmR3YWExUzk4TFI3MU91aFR3PT0mWkF2b0dhR29KeEcwUnprR2pGVHMxVzh0K0dzPQ==; __Secure-s_a=S1JVcGovaEpGTGhQdVJzZTJlTTF4R25LeWJ5R0tFSUlUYjJHYWRiYkszdEhUZzdmdXdQUllPS3NnVkViMElRQ09yUXZ1VWdOOTNzTUw5Z053clVMSVNxWmZHck1NUmM2MzVYRW02SnJaV2diZHpKYkxFa1FUTHBqNmlsV2wvZVdSSVlzUWJXblkzTVBIbUZMSEdRWFoyclg3MDUxbDBtQVE4Y2VWalhRdUM0bHNycnltU0NiQlVtRGZYbDRyNDJFQWhLV2FCZGVHMmVIcENWNTNGaytucDgvaUJYQWFkQVNrcGtXcGJzMVE4Qk9xaEZhTXJnZUlrcFJFeDRRelZLTis4QnBrQzRDUFl0TnhsYjExYmY5Qlk0LzVwSUZ6OGdyZTU0a3k4aUVTcFk9JmhQck5XUXdkYzZBMVlvSjZCQUtOSndFTGxtTT0=; _b="AX1q9yyQiPhIkp/T6frYJ+PfqogQwXAUKdtZwpxiUNzRjoq27SYZy6cLfZEdIdm9Jvg="; cm_sub=none; ar_debug=1'
      }
    })
    const $ = cheerio.load(html.data);
    const produtos = [];
    $('div > a').each((i, el) => {
      const tag = $(el);
      const link = "https://br.pinterest.com"+tag.attr('href');
      if (link && link.includes('/pin/')) {
        produtos.push({ link });
      }
    });
    return produtos;
  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

async function pinterestVideo(nome) {
  try {
    const pins = await pinterestVideoUrl(nome);
    const downloads = await Promise.all(pins.map(pin => pindl(pin.link)));
    return downloads;
  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
}

function pickRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)]
}

async function tkstalk(user) {
    return new Promise(async(resolve, reject) => {
        const getplink = await axios.get(`https://urlebird.com/search/?q=${user}`)
        const plink = cheerio.load(getplink.data)('body > div.main').find('div.info.text-truncate > a').attr('href')
        if(!plink) return resolve({status: false, message: 'User not found!'})
        const vidlink = await axios.get(plink)
        const $ = cheerio.load(vidlink.data)
        const array = []
        $('#thumbs > div > a').each(function(){
            array.push($(this).attr('href'))
        })
        const { data } = await axios.get(await pickRandom(array))
        const $$ = cheerio.load(data)
        const soundl = $$('body').find('div.music > a').attr('href')
        if(soundl) sound = await axios.get(soundl)
        else sound = false
        const $$$ = cheerio.load(sound.data)
        resolve({
                usuario: $('body').find('div.col-md-auto.text-center.text-md-left.pl-0 > h1').text(),
                nome: $('body').find('div.col-md-auto.text-center.text-md-left.pl-0 > div > h5').text(),
                bio: $('body > div.main').find('div.col-md-auto.text-center.text-md-left.pl-0 > div > p').text(),
                seguidores: $('body > div.main').find('div.col-7.col-md-auto.text-truncate').text().split('🦄 ')[1],
                foto: $('body > div.main').find('div.col-md-auto.justify-content-center.text-center > img').attr('src')
        })
    })
}

function tiktokstalk(username) {
  return new Promise((resolve, reject) => {
    let urlUsername = username.includes('@')? username : `@${username}`;
    let url = `https://www.tiktok.com/${urlUsername}`
    fetch(url)
     .then(response => {
        return response.text()
      })
     .then(html => {
        let regex = /(?<=avatarLarger":").+?(?=","avatarMedium)/
        let regex2 = /(?<=tiktok.com\/)@[a-zA-z0-9.]*/
        console.log(regex2)
        let profile_picture_encoded = html.match(regex)[0]
        let perfil = decodeURIComponent(JSON.parse(`"${profile_picture_encoded}"`))
        let usuario = username.split("@")[1]
        
        resolve({ usuario, perfil })
      })
     .catch(err => {
        console.log(err)
        reject(err)
      })
  })
}

async function tt(url) {
  let response = await axios.post("https://www.tikwm.com/api", {}, {
    params: {
      url: url,
      count: 12,
      cursor: 0,
      web: 1,
      hd: 1
    }
  });
  return response.data;
} 

async function translate(query = "", lang) {
	if (!query.trim()) return "";
	const url = new URL("https://translate.googleapis.com/translate_a/single");
	url.searchParams.append("client", "gtx");
	url.searchParams.append("sl", "auto");
	url.searchParams.append("dt", "t");
	url.searchParams.append("tl", lang);
	url.searchParams.append("q", query);

	try {
		const response = await fetch(url.href);
		const data = await response.json();
		if (data) {
			return [data[0].map((item) => item[0].trim()).join("\n"), data[2]];
		} else {
			return "";
		}
	} catch (err) {
		throw err;
	}
}

async function ssweb(url, device = 'desktop'){
     return new Promise((resolve, reject) => {
          const base = 'https://www.screenshotmachine.com'
          const param = {
            url: url,
            device: device,
            cacheLimit: 0
          }
          axios({url: base + '/capture.php',
               method: 'POST',
               data: new URLSearchParams(Object.entries(param)),
               headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
               }
          }).then((data) => {
               const cookies = data.headers['set-cookie']
               if (data.data.status == 'success') {
                    axios.get(base + '/' + data.data.link, {
                         headers: {
                              'cookie': cookies.join('')
                         },
                         responseType: 'arraybuffer'
                    }).then(({ data }) => {
              
                         resolve(data)
                    })
               } else {
                    reject({ status: 404, author: 'Dims', message: data.data })
               }
          }).catch(reject)
     })
}

async function animeVideo() {
    const url = 'https://shortstatusvideos.com/anime-video-status-download/';
    const response = await fetch(url);
    const html = await response.text();
    const $ = cheerio.load(html);

    const videos = [];

    $('a.mks_button.mks_button_small.squared').each((index, element) => {
        const href = $(element).attr('href');
        const titulo = $(element).closest('p').prevAll('p').find('strong').text();
        videos.push({
            titulo,
            download: href
        });
    });

    const randomIndex = Math.floor(Math.random() * videos.length);
    const randomVideo = videos[randomIndex];

    return randomVideo;
}

async function animeVideo2() {
    const url = 'https://mobstatus.com/anime-whatsapp-status-video/';
    const response = await fetch(url);
    const html = await response.text();
    const $ = cheerio.load(html);

    const videos = [];
    const titulo = $('strong').text();

    $('a.mb-button.mb-style-glass.mb-size-tiny.mb-corners-pill.mb-text-style-heavy').each((index, element) => {
        const href = $(element).attr('href');
        videos.push({
            titulo,
            download: href
        });
    });

    const randomIndex = Math.floor(Math.random() * videos.length);
    const randomVideo = videos[randomIndex];

    return randomVideo;
}

async function soundl(url){ 
   return new Promise(async(resolve, reject) => { 
     try { 
       const getToken = await axios.get('https://soundcloudmp3.org/', { 
         headers: { 
           "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0", 
           "cookie": "XSRF-TOKEN=eyJpdiI6ImsrUTZJTVQxbWwwSGZHWkFVem16SkE9PSIsInZhbHVlIjoiMFA0RFk1ZFE0dzI4emJ0VWZFZGVSSGxwd3U2NkhzK2g5XC9xekFtNE1kajdGaVJvUHZMdUJ6SUR6XC9qQm55NUtaZGVlU0llSE5TRmtGM2xKOGRnYUJQZz09IiwibWFjIjoiY2YxNjQxOWRiNDNkODlmYzQ4M2Q0ZTdlNTUxNmQ0MDVhNTFkMGI0MTVlNzZlY2NlMDNhYTBkODg2MzE4YTk5YyJ9; laravel_session=eyJpdiI6Im8zbUk1UkRSOHpDanBXVzJpdmRNZXc9PSIsInZhbHVlIjoiWlNTRnVYZVwvb21PRjJhaU81UFRKRDRIb0dOUWRPSjAxcGV1MEhYV1NnbTA4M0FvT2lJQmQrb3JDRzh4Y3UxTkdlNFwvSlhLSnF4TmZUTHRUUVBPNGNTQT09IiwibWFjIjoiMDQwZTFlNDNkYzFlOWNhOTVlM2E3NDNlM2M5N2MyNTkyMTQ1ZTQwNGYwNGQ2ZDlhYTY0MTE4Nzc0M2UzMGEwMCJ9" 
         } 
       }) 
       const dom = new JSDOM(getToken.data).window.document 
       const a = dom.querySelector('#conversionForm').innerHTML 
       const token = /<input name="_token" type="hidden" value="(.*?)">/g.exec(a)[1] 
       const config = { 
         _token: token, 
         lang: "en", 
         url: url, 
         submit: '' 
       } 
  
       const { data, status } = await axios('https://soundcloudmp3.org/converter', { 
         method: 'POST', 
         data: new URLSearchParams(Object.entries(config)), 
         headers: { 
           "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0", 
           "cookie": "XSRF-TOKEN=eyJpdiI6ImsrUTZJTVQxbWwwSGZHWkFVem16SkE9PSIsInZhbHVlIjoiMFA0RFk1ZFE0dzI4emJ0VWZFZGVSSGxwd3U2NkhzK2g5XC9xekFtNE1kajdGaVJvUHZMdUJ6SUR6XC9qQm55NUtaZGVlU0llSE5TRmtGM2xKOGRnYUJQZz09IiwibWFjIjoiY2YxNjQxOWRiNDNkODlmYzQ4M2Q0ZTdlNTUxNmQ0MDVhNTFkMGI0MTVlNzZlY2NlMDNhYTBkODg2MzE4YTk5YyJ9; laravel_session=eyJpdiI6Im8zbUk1UkRSOHpDanBXVzJpdmRNZXc9PSIsInZhbHVlIjoiWlNTRnVYZVwvb21PRjJhaU81UFRKRDRIb0dOUWRPSjAxcGV1MEhYV1NnbTA4M0FvT2lJQmQrb3JDRzh4Y3UxTkdlNFwvSlhLSnF4TmZUTHRUUVBPNGNTQT09IiwibWFjIjoiMDQwZTFlNDNkYzFlOWNhOTVlM2E3NDNlM2M5N2MyNTkyMTQ1ZTQwNGYwNGQ2ZDlhYTY0MTE4Nzc0M2UzMGEwMCJ9" 
         } 
       }) 
       if (status === 200) { 
         const tot = [] 
         const $ = cheerio.load(data) 
         const link = $('#ready-group > a').attr('href') 
         if (typeof link === 'undefined') return resolve({ developer: '@xorizn', mess: 'no result found' }) 
         const img = $('#preview > div.info.clearfix > img').attr('src') 
         $('#preview > div.info.clearfix > p').each(function (i, u) { tot.push($(u).text().replace(':', ': ')) }) 
         const hasil = { 
           titulo: tot[0], 
           link: link ? link : 'err', 
           capa: img ? img : 'https://i.ibb.co/G7CrCwN/404.png', 
           cap: `${tot.join("\n")}` 
         } 
         resolve(hasil) 
       } else { 
         console.log('No result found') 
       } 
     } catch (error) { 
       console.error(error) 
     } 
   }) 
}



async function Mangax(manga){ 
   return new Promise(async(resolve, reject) => { 
     try { 
       const { data } = await axios.get('https://myanimelist.net/manga.php?q='+manga+'&cat=manga') 
       let results = [] 
       var $ = cheerio.load(data); 
       $('div.js-categories-seasonal > table').each((i, u) => { 
         for(let i = 1; i < 10; i++){ 
           let b = $(u).find('td.borderClass:nth-child(2)')[i] 
           let c = $(u).find('td.borderClass:nth-child(3)')[i] 
           let d = $(u).find('td.borderClass:nth-child(4)')[i] 
           let e = $(u).find('td.borderClass:nth-child(5)')[i] 
           let f = $(u).find('td.borderClass:nth-child(1)')[i] 
           let link = $(b).find('a:nth-child(2)').attr('href') 
           if (typeof link === 'undefined') return 
           results.push({ 
             titulo: $(b).find('a.hoverinfo_trigger > strong').text(), 
             tipo: $(c).text().trim(), 
             vol: $(d).text().trim(), 
             score: $(e).text().trim(), 
             link: link, 
             capa: $(f).find('a.hoverinfo_trigger > img').attr('data-src') 
           }) 
         } 
       }); 
       if (results.every(x => x === undefined)) return { mess: 'No result found' }; 
       resolve(results) 
     } catch (error) { 
       console.error(error.toString()) 
     } 
   }) 
 }

function hentaivids() {
    return new Promise((resolve, reject) => {
        const page = Math.floor(Math.random() * 1153)
        axios.get('https://sfmcompile.club/page/'+page)
        .then((data) => {
            const $ = cheerio.load(data.data)
            const hasil = []
            $('#primary > div > div > ul > li > article').each(function (a, b) {
                hasil.push({
                    titulo: $(b).find('header > h2').text(),
                    link: $(b).find('header > h2 > a').attr('href'),
                    categoria: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
                    compartilhamentos: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
                    visualizacoes: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
                    tipo: $(b).find('source').attr('type') || 'image/jpeg',
                    video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
                    video_2: $(b).find('video > a').attr('href') || ''
                })
            })
            resolve(hasil)
        })
    })
}

async function geminiAi(q) {
  const input = new GeminiInput();
  input.addUserMessage(q);
  const geminiBot = new Chatbot("AIzaSyCLVJdE0YEg4s-eRzBjS3g2G1bboep-ONU", SupportedChatModels.GEMINI);
  const responses = await geminiBot.chat(input);
  return responses;
}

async function igStalks(username) {
  try {
    const { data, status } = await axios.get(`https://igram.world/api/ig/userInfoByUsername/${username}`, {
      headers: {
        "User-Agent": "PostmanRuntime/7.37.0"
      }
    })
    if (data.result.user.pronouns.length === 0) {
      var pronoun = ""
    } else {
      const splPron = data.result.user.pronouns
      const addSlash = splPron.join("/")
      var pronoun = addSlash
    }
    const res = data.result.user
    const result = {
      status: true,
      username: res.username,
      nome: res.full_name,
      seguidores: res.follower_count,
      seguindo: res.following_count,
      pronomes: pronoun,
      verificado: res.is_verified,
      privado: res.is_private,
      totalpostagens: res.media_count,
      bio: res.biography,
      linkBio: res.external_url,
      linkConta: `https://instagram.com/${username}`,
      fotPerfil: res.hd_profile_pic_url_info.url,
      pkId: res.pk_id
    }
    return result
  } catch (err) {
    console.log(result)
    return err
  }
}

async function searchSpotify(query) {
    try {
        const access_token = await getAccessToken();
        const response = await axios.get(`https://api.spotify.com/v1/search?q=${query}&type=track&limit=10`, {
            headers: {
                Authorization: `Bearer ${access_token}`,
            },
        });
        const data = response.data;
        const tracks = data.tracks.items.map(item => ({
            nome: item.name,
            artistas: item.artists.map(artist => artist.name).join(', '),
            views: item.popularity,
            link: item.external_urls.spotify,
            capa: item.album.images[0].url,
            duracao_ms: item.duration_ms,
        }));
        return tracks;
    } catch (error) {
        console.error('Error searching Spotify:', error);
        throw 'An error occurred while searching for songs on Spotify.';
    }
}

async function getAccessToken() {
    try {
        const client_id = 'acc6302297e040aeb6e4ac1fbdfd62c3';
        const client_secret = '0e8439a1280a43aba9a5bc0a16f3f009';
        const basic = Buffer.from(`${client_id}:${client_secret}`).toString("base64");
        const response = await axios.post('https://accounts.spotify.com/api/token', 'grant_type=client_credentials', {
            headers: {
                Authorization: `Basic ${basic}`,
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        const data = response.data;
        return data.access_token;
    } catch (error) {
        console.error('Error getting Spotify access token:', error);
        throw 'An error occurred while obtaining Spotify access token.';
    }
}

async function facebook_video(url){ 
   return new Promise(async(resolve, reject) => { 
     try { 
       const config = { 
         'id': url, 
         'locale': 'id' 
       } 
       const { data, status } = await axios('https://getmyfb.com/process', { 
         method: 'POST', 
         data: new URLSearchParams(Object.entries(config)), 
         headers: { 
           "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36", 
           "cookie": "PHPSESSID=914a5et39uur28e84t9env0378; popCookie=1; prefetchAd_4301805=true" 
         } 
       }) 
       if (status === 200) { 
         const $ = cheerio.load(data) 
         const thumb = $('div.container > div.results-item > div.results-item-image-wrapper').find('img').attr('src') 
         const video_hd = $('div.container > div.results-download > ul > li:nth-child(1) > a').attr('href') 
         const video_sd = $('div.container > div.results-download > ul > li:nth-child(2) > a').attr('href') 
         const hasil = { 
           capa: thumb, 
           video_sd: video_sd, 
           video_hd: video_hd 
         }; 
         resolve(hasil) 
       } else { 
         console.log('No result found') 
       } 
     } catch (error) { 
       console.error(error) 
     } 
   }) 
}

async function spotifydl(url)  {
  return new Promise(async (resolve, reject) => {
    try {
      const spotify = await axios.get(`https://api.fabdl.com/spotify/get?url=${encodeURIComponent(url)}`, {
          headers: {
            accept: "application/json, text/plain, */*",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "sec-ch-ua": "\"Not)A;Brand\";v=\"24\", \"Chromium\";v=\"116\"",
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": "\"Android\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "cross-site",
            Referer: "https://spotifydownload.org/",
            "Referrer-Policy": "strict-origin-when-cross-origin",
          },
        }
      );
      const dims = await axios.get(`https://api.fabdl.com/spotify/mp3-convert-task/${spotify.data.result.gid}/${spotify.data.result.id}`, {
          headers: {
            accept: "application/json, text/plain, */*",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "sec-ch-ua": "\"Not)A;Brand\";v=\"24\", \"Chromium\";v=\"116\"",
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": "\"Android\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "cross-site",
            Referer: "https://spotifydownload.org/",
            "Referrer-Policy": "strict-origin-when-cross-origin",
          },
        }
      );
      const result = {};
      result.titulo = spotify.data.result.name;
      result.tipo = spotify.data.result.type;
      result.artistas = spotify.data.result.artists;
      result.duracao = spotify.data.result.duration_ms;
      result.capa = spotify.data.result.image;
      result.download = "https://api.fabdl.com" + dims.data.result.download_url;
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
};

const filmes = async (nome) => {
  try {
    // pegar o html do link
    const html = await axios.get(`https://www.adorocinema.com/pesquisar/?q=${nome}`,{
  headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              })
    const $ = cheerio.load(html.data);
//console.log(html.data)
    // criar uma array do produto
    const produtos = [];
    // Percorra cada produto na página
    $('.entity-card-list').each((i, el) => {
      const tag = $(el);
      const nome = tag.find('.meta-title-link').text().trim();
      const desc = tag.find('.content-txt').text().trim();
      const direcao = tag.find('.meta-body-direction > .dark-grey-link').text().trim();
      const elenco = tag.find('.meta-body-actor > .dark-grey-link').text().trim();
      const titulo_original = tag.find('.meta-body-item > .dark-grey').text().trim();
      const avaliacoesz = tag.find('.stareval.stareval-small.stareval-theme-default > .stareval-note').text().trim();
      const data = tag.find('.meta-body-item.meta-body-info > .date').text().trim();
      const arr = avaliacoesz.split(",");
      resultado = {
        titulo: nome ? nome : 'tohka apis',
        tituloORiginal: titulo_original ? titulo_original : 'tohka apis',
        data: data ? data : 'tohka apis',
        direcao: direcao ? direcao : 'tohka apis',
        elencos: elenco ? elenco : 'tohka apis',
        descricao: desc ? desc : 'tohka apis'

      }
      produtos.push( resultado );
    });

    return produtos;

  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

const cota = async (moeda1, moeda2) => {
  try {
    const html = await axios.get(`https://wise.com/br/currency-converter/${moeda1}-to-${moeda2}-rate`,{
              headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
            }
              })
    const $ = cheerio.load(html.data);
      let string = $('.text-xs-center.text-lg-left').find('.d-inline-block').text().trim()
      resultado = {
          conversao: string ? string: 'tohka-ultimate'

      }
      return resultado;
  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

const wikipedia = async (nome) => {
  try {
    // pegar o html do link
    const html = await axios.get(`https://pt.wikipedia.org/w/index.php?fulltext=1&search=${nome}&title=Especial:Pesquisar&ns0=1`,{
  headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              })
    const $ = cheerio.load(html.data);
//console.log(html.data)
    // criar uma array do produto
    const produtos = [];

    // Percorra cada produto na página
    $('li.mw-search-result').each((i, el) => {
      const tag = $(el);
      const link = 'https://pt.wikipedia.org' + tag.find('a').attr('href');
      const nome = tag.find('.mw-search-result-heading').text().trim();
      const desc = tag.find('.searchresult').text().trim();
      const data = tag.find('.mw-search-result-data').text().trim();
      const capa = 'https:' + tag.find('img').attr('src')
      resultado = {
        nome: nome ? nome : 'tohka apis',
        descricao: desc ? desc : 'tohka apis',
        data: data ? data : 'tohka apis',
        capa: capa ? capa : 'https://tohka.tech/img/ayu.jpg',
        link: link ? link : 'https://tohka.tech'

      }
      produtos.push( resultado );
    });

    return produtos;

  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

const wikipediat = async (link) => {
  try {
    const html = await axios.get(link,{
              headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              })
    const $ = cheerio.load(html.data);
      let img = $('.mw-halign-center').find('img').attr('src') ? $('.mw-halign-center').find('img').attr('src') : '//tohka.tech/img/ayu.jpg';
      let titulo = $('.firstHeading').find('.mw-page-title-main').text().trim();
      let wiki = $('.mw-content-ltr.mw-parser-output').find('p').text().trim();
      let previsao2 = $('div.zoxrel').find('p').text().trim().split("\n")[0].split("CapricórnioAquárioPeixes")[1]
      resultado = {
        img: 'https:'+img,
        titulo: titulo ? titulo: 'tohka-ultimate',
          wiki: wiki ? wiki: 'tohka-ultimate'

      }
      return resultado;
  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

//funcionando 100%
const biblia = async (versiculo) => {
  try {
    // pegar o html do link
    const html = await axios.get(`https://www.bibleserver.com/OL/${versiculo}`,{
  headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              })
    const $ = cheerio.load(html.data);
//console.log(html.data)
    // criar uma array do produto
    const produtos = [];

    // Percorra cada produto na página
    $('.chapter').each((i, el) => {
      const tag = $(el);
      const bible_name = tag.find('h2.bible-name').text().trim();
      const versiculo = tag.find('.verse').text().trim();
      

      produtos.push({ bible_name, versiculo });
    });

    return produtos;

  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

//funcionando 100%
const playstore = async (nome) => {
  try {
    // pegar o html do link
    const html = await axios.get(`https://play.google.com/store/search?q=${nome}`,{
  headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              })
    const $ = cheerio.load(html.data);
//console.log(html.data)
    // criar uma array do produto
    const produtos = [];

    // Percorra cada produto na página
    $('.ULeU3b').each((i, el) => {
      const tag = $(el);
      const nome = tag.find('.DdYX5').text().trim();
      const empresa = tag.find('.wMUdtb').text().trim();
      const avaliacao = tag.find('.w2kbF').text().trim();
      const link2 = tag.find('a').attr('href')
      const capa = tag.find('img').attr('src')
      const link = 'https://play.google.com' + link2

      produtos.push({ nome, empresa, avaliacao, capa, link });
    });

    return produtos;

  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};


//funcionando 100%
const apkgara = async (nome) => {
  try {
    // pegar o html do link
    const html = await axios.get(`https://apkgara.com/?s=${nome}`,{
  headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              })
     //         console.log(html.data)
    const $ = cheerio.load(html.data);
//console.log(html.data)
    // criar uma array do produto
    const produtos = [];

    // Percorra cada produto na página
    $('.item-box-home2').each((i, el) => {
      const tag = $(el);
      const nome = tag.find('.info-title').text().trim();
      const versao = tag.find('.v-info').text().trim();
      const capa = tag.find('img').attr('data-src');
      const link = tag.find('a').attr('href');


      produtos.push({ nome, versao, capa, link });
    });

    return produtos;

  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};


const signos = async (signo) => {
  try {
    const html = await axios.get(`https://joaobidu.com.br/horoscopo/signos/previsao-${signo}/`,{
              headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              })
    const $ = cheerio.load(html.data);
      let img = $('div.theiaPostSlider_slides').find('img').attr('src');
      let titulo = $('div.zox-tit1').find('h1.entry-title').text().trim();
      let previsao = $('div.hoscopoInterna').find('#hoje').text().trim();
      let previsao2 = $('div.zoxrel').find('p').text().trim().split("\n")[0].split("CapricórnioAquárioPeixes")[1]
      resultado = {
        img: img,
        titulo: titulo ? titulo: 'tohka-ultimate',
        previsao_do_dia: previsao ? previsao: 'tohka-ultimate',
        previsao: previsao2 ? previsao2: 'tohka-ultimate'
        
      }
      return resultado;
  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

const getBuffer = async (url, options) => {
        try {
                options ? options : {}
                const res = await axios({
                        method: "get",
                        url,
                        headers: {
                                'DNT': 1,
                                'Upgrade-Insecure-Request': 1
                        },
                        ...options,
                        responseType: 'arraybuffer'
                })
                return res.data
        } catch (e) {
                console.log(`Error : ${e}`)
        }
}

const toanime = async (img) => {
const buff = await getBuffer(img)
  const base64String = Buffer.from(buff, "binary").toString("base64");


  try {
    const apiResponse = await axios.post(
      "https://www.drawever.com/api/photo-to-anime",
      {
        data: `data:image/png;base64,${base64String}`,
      },
      {
        headers: {
          "Cookie": "DRAWEVER_TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2MDk4OWJlZDM5NzI3ODhiN2U1MjY0NCIsImVtYWlsIjoidGhlc2hhZG93YnJva2VyczEzM0BnbWFpbC5jb20iLCJmdWxsbmFtZSI6IlNoYWRvdyIsImNyZWRpdHMiOjAsImlhdCI6MTcxMTkwMTExOH0.TQmn5BBN4hrraSaggn9skoTJC7h7LDin9kq0zweSvdc",
        },
      }
    );

    return "https://www.drawever.com" + (apiResponse.data.urls[1] || apiResponse.data.urls[0]);
  } catch (error) {
    console.error("Error processing image:", error.message);
    return null;
  }
};

//funcionando 100%
const frasesanime = async () => {
  try {
    // pegar o html do link
    const html = await axios.get(`https://www.pensador.com/frases_anime`,{
              headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              })
    const $ = cheerio.load(html.data);
//console.log(html.data)
    // criar uma array do produto
    const produtos = [];

    // Percorra cada produto na página
    $('blockquote').each((i, el) => {
      const tag = $(el);
      const prota = tag.find('p.autor').text().trim();
      const frase = tag.find('p').text().trim();
      

      produtos.push({ prota, frase });
    });

    return produtos;

  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

//funcionando 100%
const trevomanga = async (nome) => {
  try {
    // pegar o html do link
    const html = await axios.get(`https://trevomangas.shop/search/${nome}`,{
              headers: {
              "Accept" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
            }
              })
    const $ = cheerio.load(html.data);
//console.log(html.data)
    // criar uma array do produto
    const produtos = [];

    // Percorra cada produto na página
    $('.leading-none').each((i, el) => {
      const tag = $(el);
      const titulo = tag.find('div.h-6').text().trim();
      const dias = tag.find('div.text-xs').text().trim();
      const capa = tag.find('img').attr('src');
      

      produtos.push({ titulo, dias, capa });
    });

    return produtos;

  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};


//funcionando 100%
const trevomangadl = async (link) => {
  try {
    // pegar o html do link
    const html = await axios.get(link,{
              headers: {
              "Accept" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
            }
              })
    const $ = cheerio.load(html.data);
//console.log(html.data)
    // criar uma array do produto
    const produtos = [];

    // Percorra cada produto na página
    $('div.items-center').each((i, el) => {
      const tag = $(el);
      let img = tag.find('img').attr('src')
      if (typeof img!== 'undefined') { produtos.push(img) }
    });

    return  produtos 

  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};



//funcionando 100%
const animesonline = async (nome) => {
  try {
    // pegar o html do link
    const html = await axios.get(`https://animesonlinecc.to/search/${nome}`,{
              headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              })
    const $ = cheerio.load(html.data);

    // criar uma array do produto
    const produtos = [];

    // Percorra cada produto na página
    $('.item').each((i, el) => {
      const tag = $(el);

      const nome = tag.find('h3').text().trim();
      const img = tag.find('img').attr('src');
      const link = tag.find('a').attr('href');

      produtos.push({ nome, img, link });
    });

    return produtos;

  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

//funcionando 100%
const mangas = async (link) => {
  try {
    // pegar o html do link
    const html = await axios.get(link ,{
              headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              })
    const $ = cheerio.load(html.data);

    // criar uma array do produto
    const produtos = [];

    // Percorra cada produto na página
    $('.page-break.no-gaps').each((i, el) => {
      const tag = $(el);

     const img = tag.find('img').attr('src').replace("\t\t\t\n\t\t\t", '');
      const paraburros = `img${i + 1}`;
      produtos.push({[paraburros]: img});
    });

    return produtos;

  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};


const mangaspesquisa = async (nome) => {
  try {
    const html = await axios.get(`https://lermangas.me/?s=${nome}&post_type=wp-manga&op=&author=&artist=&release=&adult=`,{
              headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              })
    const $ = cheerio.load(html.data);
    const arrayprenssada = [];
    $('.row.c-tabs-item__content').each((i, el) => {
      const tag = $(el);
     const titulo = tag.find('.h4').text().trim()
     const titulo_alternativo = tag.find('.post-content_item.mg_alternative > .summary-content').text().trim();
     const autores = tag.find('.post-content_item.mg_genres  > .summary-content').text().trim();
     const generos = tag.find('.post-content_item.mg_author   > .summary-content').text().trim();
     const artistas = tag.find('.post-content_item.mg_artists > .summary-content').text().trim();
     const status = tag.find('.post-content_item.mg_status  > .summary-content').text().trim();
     const lancamento = tag.find('.post-content_item.mg_release  > .release-year').text().trim();
     const capitulo_mais_recente = tag.find('.tab-meta > .meta-item.latest-chap > .font-meta.chapter').text().trim();
     const avaliacao = tag.find('.tab-meta > .meta-item.rating').text().trim();
     const data_horario = tag.find('.tab-meta > .meta-item.post-on').text().trim();
     const img = tag.find('img').attr('src')
     const link = tag.find('a').attr('href')
      resultado = {
        titulo,
        titulo_alternativo: titulo_alternativo ? titulo_alternativo: 'sem titulo alternativo',
        generos: generos ? generos: 'sem genero',
        autores: autores ? autores: 'sem autor',
        artistas: artistas ? artistas: 'sem artista',
        status: status ? status: 'sem status',
        lancamento: lancamento ? lancamento: 'sem lancamento',
        capitulo_mais_recente: capitulo_mais_recente ? capitulo_mais_recente: 'sem capitulo recente',
        avaliacao: avaliacao ? avaliacao: 'sem avaliações',
        data_horario: data_horario ? data_horario: 'sem data',
        img : img ? img: 'https:/tohka.tech/img/ayu.jpg',
        link : link ? link: 'https:/tohka.tech/',
        dono_da_api_sayo: 'https:/tohka.tech'
      }
       arrayprenssada.push(resultado);
      });
      return arrayprenssada;
  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

const mangasdlcenter = async (link) => {
  try {
    const html = await axios.get(link,{
              headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              })
    const $ = cheerio.load(html.data);
    const arrayprenssada = [];
    $('.wp-manga-chapter').each((i, el) => {
      const tag = $(el);
     const link = tag.find('a').attr('href');
      resultado = {
        link: link ? link: 'https:/tohka.tech/',
        dono_da_api_sayo: 'https:/tohka.tech'
      }
       arrayprenssada.push(resultado);
      });
      return arrayprenssada;
  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

const mangatodos = async (nome, capitulo) => {
  try {
    const mangaspesquisaResult = await mangaspesquisa(nome);
    if (mangaspesquisaResult.length === 0) {
      return { erro_na_pesquisa: "Manga não encontrado, tente um nome diferente." };
    }
    const mangaLink = mangaspesquisaResult[0].link;
    const mangasdlcentro = await mangasdlcenter(mangaLink);
    const capitulok = capitulo - 1
    if (mangasdlcentro.length < capitulo) return console.log(mangasdlcentro.length < capitulo ? { erro_na_solicitacao: "este capitulo vai somente ate o " + mangasdlcentro.length } : {});
    const chapterListaLink = mangasdlcentro[capitulok].link
    const mangasdlresultado = await mangas(chapterListaLink);
    console.log(mangasdlcentro.length)
    return mangasdlresultado;
  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

async function memedroid(nome) {
return new Promise((resolve, reject) => {
axios.get(`https://pt.memedroid.com/search?query=${nome}`).then( site => {
const $ = cheerio.load(site.data)
var sayoz = [];
$(".item-aux-container").each((_, say) => {
var titulo = $(say).find("a.item-header-title.dyn-link").text().trim();
//if (conteudo
var conteudoImg = $(say).find("img").attr('src')
var conteudovid = $(say).find("source").attr('src')
var gostaram = $(say).find(".green-1").text().trim()
var link = $(say).find("a").attr('href')
var data = $(say).find("a").attr('datetime')
var variavel = '/images/icons/icon_play.png'
let meme = conteudoImg
if (conteudoImg.includes(variavel)) {
		meme = conteudovid
}
var resultado = {
titulo,
meme,
gostaram,
link: 'https://pt.memedroid.com' + link
}
sayoz.push(resultado)
})
resolve(sayoz)}).catch(reject)
});
}

function tempo(estado) {
return new Promise((resolve, reject) => {
  axios.get(`https://www.tempo.com/hoje/${estado}.htm`,{
              headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              }).then( tod => {
  const $ = cheerio.load(tod.data)  
    let postagem = [];
    let previsao = $('.franjas').find('.resumen-dia').text().trim();
    let graus = $('.c-yellow.c-0').find('.title-mod.changeUnitT').text().trim();
    var resultado = {
     graus,
     previsao
    }
    postagem.push(resultado)
  resolve(postagem)
  }).catch(reject)
  });
}

function xvsz(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://www.xvideos.com/?k=${nome}`,{
              headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              }).then( tod => {
  const $ = cheerio.load(tod.data)
  var postagem = [];
$("div.thumb-inside").each((_, say) => {
    var duracao = $(say).find(".duration").text().trim();
    var link = $(say).find("a").attr('href');
    var capa = $(say).find("img").attr('data-src');
    var qualidade = $(say).find("span").text().trim();
    //$("div.thumb-under").each((_, say) => {
  //  var titulo = $('.thumb-under').find('p.title').text()
   // var canal = $('.thumb-under').find('span.name').text() 
    var resultado = {
     // titulo,
      link: 'https://www.xvideos.com' + link,      
      capa,   
      //canal,      
      qualidade
    }
    postagem.push(resultado)
 // })
  })
//  console.log(tod.data)
  resolve(postagem)
  }).catch(reject)
  });
}

function xv2z(nome) {
  return new Promise((resolve, reject) => {
     axios.get(`https://www.xvideos.com/?k=${nome}`,{
                 headers: {
                 "Accept-Language" : "pt-BR,pt;q=0.9",
                 "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                 "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
               }
                 }).then( tod => {
       const $ = cheerio.load(tod.data)
       var postagem = [];
       $(".thumb-under").each((_, say) => {
         var titulo = $(say).find(".title").text().trim();
         var canal =  $(say).find(".name").text().trim();
         var resultado = {
             titulo,     
             canal
           }
           postagem.push(resultado)
       });
      resolve(postagem)
      }).catch(reject)
    });
    }

async function xvz(nome) {
  const videosData = await xvsz(nome);
  const detailsData = await xv2z(nome);

  const videos = videosData.map((video, index) => {
    const titulo = detailsData[index].titulo;
    const canal = detailsData[index].canal;

    return {
      ...video,
      titulo,
      canal,
    };
  });

  return videos;
}

async function igdl(link) {        
const resultadolk = (await ndown(link))
var resultado = {
      link: resultadolk.data[0]
    }
 return(resultado)
}


async function hentaiword(nome) {
return new Promise((resolve, reject) => {
axios.get(`https://hentaiworld.tv/?s=${nome}`).then( site => {
const $ = cheerio.load(site.data)
var sayoz = [];
$(".ast-post-format-").each((_, say) => {
var titulo = $(say).find("div.video-title-text").text().trim();
var imagem = $(say).find("img").attr('src');
var likes = $(say).find(".episode-views > .post-likes").text().trim().split("K")[0] + 'K'
var ameis = $(say).find(".episode-views > .post-likes").text().trim().split("K")[1]
var resultado = {
titulo,
imagem,
likes,
ameis
}
sayoz.push(resultado)
})
resolve(sayoz)}).catch(reject)
});
}


function igstalk(nome) {
  return new Promise((resolve, reject) => {
    axios.get(`https://instuky.com/profile/${nome}`, {
			headers: {
			"cookie" : "cf_clearance=TauaclJEp3o8AF2Ucynglr8cer2MvHsAqZteFbP8gFE-1713889153-1.0.1.1-v.GosYenYk_Zuuu4RHzIL_.lgaVJUGXZdYd35kpjCr0j5XzDRz96F1nq0w7Q66KYjAnPyvjSqiqVwyI57kf_Fw; _ga_C7K5L64RS7=GS1.1.1713889153.1.0.1713889153.0.0.0; _ga=GA1.1.1732993487.1713889154",
			"accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
			"user-Agent" : "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.0 Safari/605.1.15 Midori/6"
		}
			}).then( tod => {
    const $ = cheerio.load(tod.data)  
    var postagem = [];
  $(".profile__body").each((_, say) => {
      var nome = $(say).find(".profile__nickname").text().trim();
      var usuario = $(say).find(".title").text().trim();
      var avatar = $(say).find("img").attr('src');
      var resultado = {
        nome: nome,
        usuario: usuario,
        avatar: avatar,
        link: "https://instagram.com/"+nome
      }
      postagem.push(resultado)
    })
    resolve(postagem)
    }).catch(reject)
    });
  }
async function hentaiGeral(nome) {
site = await axios.get(`https://www.waifu.im/search/?included_tags=${nome}`)
site2 = site.data.split("var files = ")[1]
fs.writeFileSync("./teste.json", site2.split(`\nif (has_cookie`)[0])
json = JSON.parse(fs.readFileSync('./teste.json').toString())
resultado = json[Math.floor(Math.random() * json.length)]
return resultado
}

async function waifur() {
return new Promise((resolve, reject) => {
axios.get(`https://www.waifu.im`).then( site => {
const $ = cheerio.load(site.data)
var sayoz = [];
$("div.container").each((_, say) => {
var imagem = $(say).find("img.img-fluid").attr('src');
var resultado = {
imagem
}
sayoz.push(resultado)
})
resolve(sayoz)}).catch(reject)
});
}

function pensador(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://www.pensador.com/busca.php?q=${nome}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.thought-card.mb-20").each((_, say) => {
    var frase = $(say).find("p").text().trim(); 
    var compartilhamentos = $(say).find("div.total-shares").text().trim(); 
    var autor = $(say).find("a").text().split("\n")[0];
    var imagem = $(say).find("div.sg-social-hidden.sg-social").attr('data-media');
    var resultado = {
      autor: autor,
      compartilhamentos: compartilhamentos,      
      imagem: imagem,
      frase: frase
    }
    postagem.push(resultado)
  })
//  console.log(tod.data)
  resolve(postagem)
  }).catch(reject)
  });
}

async function geturl(nome) {
  return new Promise((resolve, reject) => {
const search = yts(nome)
            .then(async(data) => {
                const url = []
                const pormat = data.all
                for (let i = 0; i < pormat.length; i++) {
                    if (pormat[i].type == 'video') {
                        let dapet = pormat[i]
                        url.push(dapet.url)
}
}
var resultado = { 
link: url[0] 
}               
return(resultado) 
}) 
resolve(search)
})
}

async function ytdl(link) {
const { thumbnail, audio: _audio, title } = await youtubedl(link).catch(async _ => await youtubedlv2(link)).catch(async _ => await youtubedlv3(link))
let audio, source, res, dlaudio, lastError, isLimit
for (let i in _audio) {
audio = _audio[i]
dlaudio = await audio.download()
var resultado = {
      capa: thumbnail,
      titulo: title,      
      audio: dlaudio
    }
}
  return(resultado)
 
}


 function gppq(pagina) {
return new Promise((resolve, reject) => {
 axios.get(`https://grupowhatsap.com/page/${pagina}/?amp=1`).then(tod => {
const $ = cheerio.load(tod.data)
var postagem = [];
$("div.grupo").each((_, say) => {
 var _ikk = $(say).find("a").attr('href');
 var _ikkli = $(say).find("img").attr('src');
 var _ikkkkk = {
img: _ikkli,
linkk: _ikk
 }
 postagem.push(_ikkkkk)
})
resolve(postagem)
 }).catch(reject)
});
 }
 
 
 const rastrear = async (id) => {
const res = await axios.get('https://www.linkcorreios.com.br/?id=' + id)
const $ = cheerio.load(res.data)
const breners = []
let info = $('ul.linha_status.m-0').find('li').text().trim();
let infopro = $('ul.linha_status').find('li').text().trim();
breners.push({ info, infopro })
return breners
}
 


const getgrupos = async () => {
let numberskk = ['1',
 '2',
 '3',
 '4',
 '5',
 '6',
 '7',
 '8',
 '9',
 '10',
 '11'] //acrecente mais!maximo e 60!
paginas = numberskk[Math.floor(Math.random() * numberskk.length)]
let ilinkkk = await gppq(paginas)
let linkedgpr = ilinkkk[Math.floor(Math.random() * ilinkkk.length)]
const res = await axios.get(linkedgpr.linkk)
const $ = cheerio.load(res.data)
var postagem = []
var img = $('div.post-thumb').find("amp-img").attr('src')
var nome = $('div.col-md-9').find('h1.pagina-titulo').text().trim()
var desc = $('div.col-md-9').find('p').text().trim()
var link = $('div.post-botao').find('a').attr('href')
postagem.push({ img, nome, desc, link })
return postagem
}



const pinterest = async (nome) => {
  try {
    const html = await axios.get(`https://br.pinterest.com/search/pins/?q=${nome}`, {
      headers: {
        "cookie" : '_auth=1; _pinterest_sess=TWc9PSZ2NjR5RStuSUo4c0ZtN1dCMDRHdFk0TlNUV3BpNkg2RGd4UVVKTUYrVW1TNjJHL1hsOGpaSTlJWnhITnA0S3Fnc2R5MXIzYy9ITFF3WG5PS3Jzb1ptUkxNMTVDeTR3WGhGaXFncVNoeVllbm5Vdk5ZR042a3RFeDhocU83SG1XZHJQVEhya3lYeXorWXZsa045Y1ovQlRpM0tPb1FML0RobEFFTGx5RDhHZVl4WnNFTUpTV2RnSUpDRTdMUDNHWGVwakhvU0FjRWdEMFhhUGc2YmE1UUpFaXdra2NRaFgzOCt0YTVScDRWRGx0M1BaSzJCUXA3RjNlMnVubTNhSUpUNGZVYzljamIvZXdjRUFVVUlKSElOb2p6SzFxRGVrRGZCT2lTVHBtdFBGWHcxa2R6dHlqM2JnNTNldjFEZ3pwOEZ3Q3FuekRWcWNtTGcyS0tvZG5PUmo1ZXdFU25iSkxyY2RLS2N1K0I1emllUkUzc1RYemJoZG80TVliczB5OXh5eXpDUmR3YWExUzk4TFI3MU91aFR3PT0mWkF2b0dhR29KeEcwUnprR2pGVHMxVzh0K0dzPQ==; __Secure-s_a=S1JVcGovaEpGTGhQdVJzZTJlTTF4R25LeWJ5R0tFSUlUYjJHYWRiYkszdEhUZzdmdXdQUllPS3NnVkViMElRQ09yUXZ1VWdOOTNzTUw5Z053clVMSVNxWmZHck1NUmM2MzVYRW02SnJaV2diZHpKYkxFa1FUTHBqNmlsV2wvZVdSSVlzUWJXblkzTVBIbUZMSEdRWFoyclg3MDUxbDBtQVE4Y2VWalhRdUM0bHNycnltU0NiQlVtRGZYbDRyNDJFQWhLV2FCZGVHMmVIcENWNTNGaytucDgvaUJYQWFkQVNrcGtXcGJzMVE4Qk9xaEZhTXJnZUlrcFJFeDRRelZLTis4QnBrQzRDUFl0TnhsYjExYmY5Qlk0LzVwSUZ6OGdyZTU0a3k4aUVTcFk9JmhQck5XUXdkYzZBMVlvSjZCQUtOSndFTGxtTT0=; _b="AX1q9yyQiPhIkp/T6frYJ+PfqogQwXAUKdtZwpxiUNzRjoq27SYZy6cLfZEdIdm9Jvg="; cm_sub=none; ar_debug=1'
      }
    })
    const $ = cheerio.load(html.data);
    const produtos = [];
    $('div > a').each((i, el) => {
      const tag = $(el);
      const link = tag.find('img').attr('src');
      if (link) {
        produtos.push( link );
      }
    });
    return produtos.filter(p => p.link !== undefined);
  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return { erro_na_solicitacao: "chame: 5562936180708" };
  }
};

const pinterest_gif = async (nome) => {
  try {
    const html = await axios.get(`https://br.pinterest.com/search/pins/?q=${nome} gif`, {
      headers: {
         "cookie" : '_auth=1; _pinterest_sess=TWc9PSZ2NjR5RStuSUo4c0ZtN1dCMDRHdFk0TlNUV3BpNkg2RGd4UVVKTUYrVW1TNjJHL1hsOGpaSTlJWnhITnA0S3Fnc2R5MXIzYy9ITFF3WG5PS3Jzb1ptUkxNMTVDeTR3WGhGaXFncVNoeVllbm5Vdk5ZR042a3RFeDhocU83SG1XZHJQVEhya3lYeXorWXZsa045Y1ovQlRpM0tPb1FML0RobEFFTGx5RDhHZVl4WnNFTUpTV2RnSUpDRTdMUDNHWGVwakhvU0FjRWdEMFhhUGc2YmE1UUpFaXdra2NRaFgzOCt0YTVScDRWRGx0M1BaSzJCUXA3RjNlMnVubTNhSUpUNGZVYzljamIvZXdjRUFVVUlKSElOb2p6SzFxRGVrRGZCT2lTVHBtdFBGWHcxa2R6dHlqM2JnNTNldjFEZ3pwOEZ3Q3FuekRWcWNtTGcyS0tvZG5PUmo1ZXdFU25iSkxyY2RLS2N1K0I1emllUkUzc1RYemJoZG80TVliczB5OXh5eXpDUmR3YWExUzk4TFI3MU91aFR3PT0mWkF2b0dhR29KeEcwUnprR2pGVHMxVzh0K0dzPQ==; __Secure-s_a=S1JVcGovaEpGTGhQdVJzZTJlTTF4R25LeWJ5R0tFSUlUYjJHYWRiYkszdEhUZzdmdXdQUllPS3NnVkViMElRQ09yUXZ1VWdOOTNzTUw5Z053clVMSVNxWmZHck1NUmM2MzVYRW02SnJaV2diZHpKYkxFa1FUTHBqNmlsV2wvZVdSSVlzUWJXblkzTVBIbUZMSEdRWFoyclg3MDUxbDBtQVE4Y2VWalhRdUM0bHNycnltU0NiQlVtRGZYbDRyNDJFQWhLV2FCZGVHMmVIcENWNTNGaytucDgvaUJYQWFkQVNrcGtXcGJzMVE4Qk9xaEZhTXJnZUlrcFJFeDRRelZLTis4QnBrQzRDUFl0TnhsYjExYmY5Qlk0LzVwSUZ6OGdyZTU0a3k4aUVTcFk9JmhQck5XUXdkYzZBMVlvSjZCQUtOSndFTGxtTT0=; _b="AX1q9yyQiPhIkp/T6frYJ+PfqogQwXAUKdtZwpxiUNzRjoq27SYZy6cLfZEdIdm9Jvg="; cm_sub=none; ar_debug=1'
      }
    })
    const $ = cheerio.load(html.data);
    const produtos = [];
    $('img[srcset]').each((i, el) => {
      const tag = $(el);
      const srcset = tag.attr('srcset');
      const gifLink = srcset.split(',').find(link => link.includes('gif'));
      if (gifLink) {
        produtos.push(gifLink.trim().replace(" 4x",''));
      }
    });
    return produtos.filter(p => p.link !== undefined);
  } catch (error) {
    console.error(`erro ao fazer a solicitação: ${error.message}`);
    return{ erro_na_solicitacao: "chame: 5562936180708" };
  }
};

function styletext(texto) {
    return new Promise((resolve, reject) => {
        axios.get('http://qaz.wtf/u/convert.cgi?text='+texto)
        .then(({ data }) => {
            let $ = cheerio.load(data)
            let hasil = []
            $('table > tbody > tr').each(function (a, b) {
                hasil.push({ nome: $(b).find('td:nth-child(1) > span').text(), fonte: $(b).find('td:nth-child(2)').text().trim() })
            })
            resolve(hasil)
        })
    })
}

//wallpaper.mob.org
function wallmob() {
return new Promise((resolve, reject) => {
  axios.get(`https://wallpaper.mob.org/gallery/tag=anime/`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.image-gallery-image ").each((_, say) => {
   var img = $(say).find("img").attr('src');
    var resultado = {
    img: img
    }
    postagem.push(resultado)
  })
//  console.log(tod.data)
  resolve(postagem)
  }).catch(reject)
  });
}

//Assistirhentai Pesquisa
function assistitht(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://www.assistirhentai.com/?s=${nome}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.videos").each((_, say) => {
    var nome = $(say).find("h2").text().trim(); 
    var img = $(say).find("img").attr('src');
    var link = $(say).find("a").attr('href');
    var data_up = $(say).find("span.video-data").text().trim(); 
    var tipo = $(say).find("span.selo-tipo").text().trim();     
    var eps = $(say).find("span.selo-tempo").text().trim();         
    var resultado = {
      nome: nome,
      img: img,
      link: link,
      data_up: data_up,
      tipo: tipo,
      total_ep: eps
    }
    postagem.push(resultado)
  })
//  console.log(tod.data)
  resolve(postagem)
  }).catch(reject)
  });
}

//Assistirhentai dl
function assistithtdl(link) {
return new Promise((resolve, reject) => {
  axios.get(`${link}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.meio").each((_, say) => {
    var nome = $(say).find("h1.post-titulo").text().trim(); 
    var img = $(say).find("img").attr('src');
    var descrição = $(say).find("p").text().trim(); 
    var link = $(say).find("source").attr('src');
    var resultado = {
      nome: nome,
      capa: img,
      descrição: descrição,
      link_dl: link
    }
    postagem.push(resultado)
  })
//  console.log(tod.data)
  resolve(postagem)
  }).catch(reject)
  });
}

//Porno gratis
function pornogratis(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://pornogratis.vlog.br/?s=${nome}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.videos-row").each((_, say) => {
    var nome = $(say).find("a").attr('title');
    var img = $(say).find("img").attr('src');
    var link = $(say).find("a").attr('href');
    var resultado = {
      nome: nome,
      img: img,
      link: link
    }
    postagem.push(resultado)
  })
//  console.log(tod.data)
  resolve(postagem)
  }).catch(reject)
  });
}

function xvideoss(nome) {
var link = `https://www.xvideos.com/?k=${nome}`;
var data = [];
var xv = [];
request(link, (err, req, body) => {
if (err) return console.log(err);
const Sayo_Reg = /<\/div><div class=\".+?\"><p class=\".+?\"><a href=\".+?\" .+? <span class=\".+?\"><\/span>/g;
const datas = body.match(Sayo_Reg);
data.push(...datas);
var Sayo_Regk = /\"\/.+?\"/g;
var Sayo_Regkk = /title=\".+?\">/g;
//var Sayo_Regkkk = /\"duration\">.+?/g;
for (let index of data) {
var Akame_R = index.match(Sayo_Regk);
var Akame_RR = index.match(Sayo_Regkk);
var Akame_RRR = Akame_RR[0].split('title=').join('').split('>').join('');
//var Akame_RRRR = index.match(Sayo_Regkkk);
var opções = {
título: JSON.parse(Akame_RRR),
//duração: JSON.parse(Akame_RRRR),
link: 'https://www.xvideos.com' + JSON.parse(Akame_R[0]),
};
//console.log(opções)
xv.push(opções);
}});};

function xvideosdl(link) {
const ___Xvdlkkk = [];
request(link, (err, req, body) => {
var ___Sayo_Reg = /html5player\.setVideoTitle\(\'.+?\'\)/g;
var ___Título_vD = body.match(___Sayo_Reg)[0].split('html5player.setVideoTitle(\'').join('').split('\')').join('');
var __Link_dO_Video_rrr = /html5player\.setVideoUrlHigh\(\'.+?\'\)/g;
var __Link_dO_Video_r = body.match(__Link_dO_Video_rrr)[0].split('html5player.setVideoUrlHigh').join('').split('(').join('').split(')').join('').split('\'').join('');
var __Duração_do_Vd_sec_dos_ofc011 = /class=\"duration\">.+?<\/span>/g;
var __Duração_do_Vd_sec_dos_ofc = body.match(__Duração_do_Vd_sec_dos_ofc011)[0].split('class=\"duration\">').join('').split('<').join('').split('span>').join('').split('/').join('');
var __Duração_do_Vd_sec_dos = __Duração_do_Vd_sec_dos_ofc.endsWith(' min') ? ' minutes': '' || __Duração_do_Vd_sec_dos_ofc.endsWith(' sec') ? ' seconds': '';
var __Duração_do_Vd = __Duração_do_Vd_sec_dos_ofc.split(' ')[0] + __Duração_do_Vd_sec_dos;
var __Visualizações___k = /class=\"mobile-hide\">.+?<\/strong>/g;
var __Visualizações_k = body.match(__Visualizações___k)[0].split('class=\"mobile-hide\">').join('').split('</strong>').join('');
var __Criador = /html5player\.setUploaderName\(\'.+?\'\)/g;
var __Criador_do_Video_safado = body.match(__Criador)[0].split('html5player.setUploaderName(\'').join('').split('\')').join('');
var obj = {
criador_vd: __Criador_do_Video_safado,
título: ___Título_vD,
link: __Link_dO_Video_r,
duração: __Duração_do_Vd,
visualizações: __Visualizações_k
};
___Xvdlkkk.push(obj);
//console.log(obj)
})}

function htdl(link) {
return new Promise((resolve, reject) => {
  axios.get(`${link}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.toggle").each((_, say) => {
    var link = $(say).find("video").attr('src');
    var resultado = {
      link: link
    }
    postagem.push(resultado)
  })
//  console.log(tod.data)
  resolve(postagem)
  }).catch(reject)
  });
}

function papeldeparede(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://wall.alphacoders.com/search.php?search=${nome}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.boxgrid").each((_, say) => {
    var titulo = $(say).find("a").attr('title');
    var link1 = $(say).find("a").attr('href');
    var link = `https://wall.alphacoders.com${link1}`
    var img = $(say).find("img").attr('src');    
    var resultado = {
      titulo: titulo,
      img: img,
      link: link
    }
    postagem.push(resultado)
  })
  resolve(postagem)
  }).catch(reject)
  });
}

function xnxxdl(link_video) { return new Promise((resolve, reject) => {
fetch(link_video, {method: 'get'}).then(sexokk => sexokk.text()).then(sexokk => {var sayo = cheerio.load(sexokk, {xmlMode: false});resolve({
criador: "breno/sayo",
resultado: {título: sayo('meta[property="og:title"]').attr('content'),duração: sayo('meta[property="og:duration"]').attr('content'),img: sayo('meta[property="og:image"]').attr('content'),tipo_vd: sayo('meta[property="og:video:type"]').attr('content'),vd_altura: sayo('meta[property="og:video:width"]').attr('content'),vd_largura: sayo('meta[property="og:video:height"]').attr('content'),informações: sayo('span.metadata').text(),resultado2: {qualidade_baixa: (sayo('#video-player-bg > script:nth-child(6)').html().match('html5player.setVideoUrlLow\\(\'(.*?)\'\\);') || [])[1],qualidade_alta: sayo('#video-player-bg > script:nth-child(6)').html().match('html5player.setVideoUrlHigh\\(\'(.*?)\'\\);' || [])[1],qualidade_HLS: sayo('#video-player-bg > script:nth-child(6)').html().match('html5player.setVideoHLS\\(\'(.*?)\'\\);' || [])[1],capa: sayo('#video-player-bg > script:nth-child(6)').html().match('html5player.setThumbUrl\\(\'(.*?)\'\\);' || [])[1],capa69: sayo('#video-player-bg > script:nth-child(6)').html().match('html5player.setThumbUrl169\\(\'(.*?)\'\\);' || [])[1],capa_slide: sayo('#video-player-bg > script:nth-child(6)').html().match('html5player.setThumbSlide\\(\'(.*?)\'\\);' || [])[1],capa_slide_grande: sayo('#video-player-bg > script:nth-child(6)').html().match('html5player.setThumbSlideBig\\(\'(.*?)\'\\);' || [])[1]}}})}).catch(err => reject({code: 503, status: false, result: err }))})}

//WIKIPEDIA
var wiki = async (query) => {
var res = await axios.get(`https://pt.m.wikipedia.org/wiki/${query}`)
var $ = cheerio.load(res.data)
var postagem = []
var titulo = $('#mf-section-0').find('p').text()
var capa = $('#mf-section-0').find('div > div > a > img').attr('src')
capaofc = capa ? capa : '//pngimg.com/uploads/wikipedia/wikipedia_PNG35.png'
img = 'https:' + capaofc
var título = $('h1#section_0').text()
postagem.push({ titulo, img })
return postagem
}

//FF
function ff(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://www.ffesportsbr.com.br/?s=${nome}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("article.home-post.col-xs-12.col-sm-12.col-md-4.col-lg-4.py-3").each((_, say) => {
    var titulo = $(say).find("h2").text().trim();
    var keywords = $(say).find("ul").text().trim();
    var publicado = $(say).find("span").text().trim();
    var link = $(say).find("a").attr('href');
    var img = $(say).find("img").attr('src');
    var resultado = {
      titulo: titulo,
      keywords: keywords,
      publicado: publicado,
      img: img,
      link: link
    }
    postagem.push(resultado)
  })
  resolve(postagem)
  }).catch(reject)
  });
}



//DAFONTE
const dafontSearch = async (query) => {
const base = `https://www.dafont.com`
const res = await axios.get(`${base}/search.php?q=${query}`)
const $ = cheerio.load(res.data)
const hasil = []
const total = $('div.dffont2').text().replace(` fonts on DaFont for ${query}`, '') 
$('div').find('div.container > div > div.preview').each(function(a, b) {
$('div').find('div.container > div > div.lv1left.dfbg').each(function(c, d) { 
$('div').find('div.container > div > div.lv1right.dfbg').each(function(e, f) { 
let link = `${base}/` + $(b).find('a').attr('href')
let titulo = $(d).text() 
let estilo = $(f).text() 
hasil.push({ titulo, estilo, total, link }) 
}) 
}) 
}) 
return hasil
}

const dafontDown = async (link) => {
const des = await axios.get(link)
const sup = cheerio.load(des.data)
const result = []
let estilo = sup('div').find('div.container > div > div.lv1right.dfbg').text() 
let titulo = sup('div').find('div.container > div > div.lv1left.dfbg').text() 
try {
isi = sup('div').find('div.container > div > span').text().split('.ttf')
saida = sup('div').find('div.container > div > span').eq(0).text().replace('ttf' , 'zip')
} catch {
isi = sup('div').find('div.container > div > span').text().split('.otf')
saida = sup('div').find('div.container > div > span').eq(0).text().replace('otf' , 'zip')
}
let download = 'http:' + sup('div').find('div.container > div > div.dlbox > a').attr('href')
result.push({ estilo, titulo, isi, saida, download})
return result
}

//GRUPO
function gpsrc(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://zaplinksbrasil.com.br/?s=${nome}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.grupo").each((_, say) => {
    var titulo = $(say).find("a").attr('title');
    var link = $(say).find("a").attr('href');
    var img = $(say).find("img").attr('src');
    var conteudo = $(say).find("div.listaCategoria").text().trim();
    var resultado = {
      titulo: titulo,
      img: img,
      conteudo: conteudo,
      link: link
    }
    postagem.push(resultado)
  })
  resolve(postagem)
  }).catch(reject)
  });
}

//STICKER SEARCH
function st(nome) { return new
 Promise((resolve, reject) => {
		axios.get(`https://getstickerpack.com/stickers?query=${query}`)
			.then(({
				data
			}) => {
				const $ = cheerio.load(data)
				const link = [];
				$('#stickerPacks > div > div:nth-child(3) > div > a')
				.each(function(a, b) {
					link.push($(b).attr('href'))
				})
				rand = link[Math.floor(Math.random() * link.length)]
				axios.get(rand)
					.then(({
						data
					}) => {
						const $$ = cheerio.load(data)
						const url = [];
						$$('#stickerPack > div > div.row > div > img')
						.each(function(a, b) {
							url.push($$(b).attr('src').split('&d=')[0])})
				 		resolve({
							criador: '@breno',
							titulo: $$('#intro > div > div > h1').text(),
							autor: $$('#intro > div > div > h5 > a').text(),
							autor_link: $$('#intro > div > div > h5 > a').attr('href'),
							figurinhas: url
		 				})})})})}


//PORNHUB
function pornhub(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://pt.pornhub.com/video/search?search=${nome}`,{
              headers: {
              "Accept-Language" : "pt-BR,pt;q=0.9",
              "accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
              "user-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3"
            }
              }).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("li.pcVideoListItem.js-pop.videoblock.videoBox").each((_, say) => {
    var titulo = $(say).find("a").attr('title');
    var link = $(say).find("a").attr('href');
    var img = $(say).find("img").attr('src');
    var video_preloader = $(say).find("img").attr('data-mediabook');
    var duração = $(say).find("var.duration").text().trim();
    var canal = $(say).find("div.usernameWrap").text().trim();    
    var visualizações = $(say).find("span.views").text().trim().replace("Spicevids",'');        
    var likes = $(say).find("div.value").text().trim();    
    var link2 = `https://pt.pornhub.com${link}`
    var resultado = {
      titulo,
      img,
      video_preloader,
      duração,
      canal,
      visualizações,
      likes,
      link2: link2.replace("javascript:void(0)", ' \nsem link pois e um anuncio')
    }
    postagem.push(resultado)
  })
  resolve(postagem)
  }).catch(reject)
  });
}

//XVIDEOS
function xvideos(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://xvideosporno.blog.br/?s=${nome}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.postbox").each((_, say) => {
    var titulo = $(say).find("a").attr('title');
    var link = $(say).find("a").attr('href');
    var img = $(say).find("img").attr('src');
    var duração = $(say).find("time.duration-top").text().trim();
    var qualidade = $(say).find("b.hd-top").text().trim();
    var resultado = {
      titulo: titulo,
      img: img,
      duração: duração,
      qualidade: qualidade,
      link: link
    }
    postagem.push(resultado)
  })
  resolve(postagem)
  }).catch(reject)
  });
}

//UPTODOWN
function uptodown(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://br.uptodown.com/android/search/${nome}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.item").each((_, say) => {
    var titulo = $(say).find("div.name").text().trim();
    var link = $(say).find("a").attr('href');
    var img = $(say).find("img.app_card_img.lazyload").attr('data-src');
    var descrição = $(say).find("div.description").text().trim();
    var resultado = {
      titulo: titulo,
      link: link,
      icone: img,
      descrição: descrição
    }
    postagem.push(resultado)
  })
  resolve(postagem)
  }).catch(reject)
  });
}

//GRUPOS WHATSAPP
function gpwhatsapp() {
return new Promise((resolve, reject) => {
  axios.get(`https://gruposwhats.app/`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.col-12.col-md-6.col-lg-4.mb-4.col-group").each((_, say) => {
    var nome = $(say).find("h5.card-title").text().trim();
    var descrição = $(say).find("p.card-text").text().trim();
    var link = $(say).find("a.btn.btn-success.btn-block.stretched-link.font-weight-bold").attr('href');
    var img = $(say).find("img.card-img-top.lazy").attr('data-src');
    var resultado = {
      nome: nome,
      link: link,
      descrição: descrição,
      img: img
    }
    postagem.push(resultado)
  })
  resolve(postagem)
  }).catch(reject)
  });
}


//HENTAIS TUBE
function hentaistube(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://www.hentaistube.com/buscar/?s=${nome}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.epiItem").each((_, say) => {
    var titulo = $(say).find("div.epiItemNome").text().trim();
    var link = $(say).find("a").attr('href');
    var img = $(say).find("img").attr('src');
    var resultado = {
      titulo: titulo,
      link: link,
      img: img
    }
    postagem.push(resultado)
  })
  resolve(postagem)
  }).catch(reject)
  });
}


//NERDING
function nerding(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://www.nerding.com.br/search?q=${nome}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.col-sm-6.col-xs-12.item-boxed-cnt").each((_, say) => {
    var titulo = $(say).find("h3.title").text().trim();
    var descrição = $(say).find("p.summary").text().trim();
    var imagem = $(say).find("img.lazyload.img-responsive").attr('src');
    var link = $(say).find("a.pull-right.read-more").attr('href');
    var review = $(say).find("span.label-post-category").text().trim();
//    var autor = $(say).find("p.post-meta-inner").text().trim();
    var resultado = {
      titulo: titulo,
      descrição: descrição,
      imagem: imagem,
      review: review,      
      link: link
//      autor: autor
    }
    postagem.push(resultado)
  })
  resolve(postagem)
  }).catch(reject)
  });
}

//APKMODHACKER
function apkmodhacker(nome) {
return new Promise((resolve, reject) => {
  axios.get(`https://apkmodhacker.com/?s=${nome}`).then( tod => {
  const $ = cheerio.load(tod.data)  
  var postagem = [];
$("div.post-inner.post-hover").each((_, say) => {
    var nome = $(say).find("h2.post-title.entry-title").text().trim();
    var descrição = $(say).find("div.entry.excerpt.entry-summary").text().trim();
    var imagem = $(say).find("img.attachment-thumb-medium.size-thumb-medium.wp-post-image").attr('src');
    var link = $(say).find("a").attr('href');
    var categoria = $(say).find("p.post-category").text().trim();
    var horario_upload = $(say).find("time.published.updated").attr('datetime');   
    var resultado = {
      nome: nome,
      descrição: descrição,
      categoria: categoria,
      imagem: imagem,
      link: link,
      horario_upload: horario_upload
    }
    postagem.push(resultado)
  })
  resolve(postagem)
  }).catch(reject)
  });
}



function wall4kpaper(nome) {
  return new Promise((resolve, reject) => {
    axios.get(`https://4kwallpapers.com/search/?q=${nome}`).then( tod => {
    const $ = cheerio.load(tod.data)  
    var postagem = [];
  $(".wallpapers__item").each((_, say) => {
      var titulo = $(say).find(".title2").text().trim();
      var img = $(say).find("img").attr('src');
      var link = $(say).find("a").attr('href');
      var resultado = {
        titulo,
        img,
        link
      }
      postagem.push(resultado)
    })
    resolve(postagem)
    }).catch(reject)
    });
  }

async function textmakers(codigo, msg) {
return new Promise((resolve, reject) => {
axios.get(`https://www.textstudio.com/logo/${codigo}/${msg}`).then( site => {
const $ = cheerio.load(site.data)
var sayoz = [];
$(".infos").each((_, say) => {
var img = $(say).find("img").attr('src');
var resultado = {
  img
}
sayoz.push(resultado)
})
resolve(sayoz)}).catch(reject)
});
}



const globosporte = async () => {
  try {
    const response = await axios.get(`https://ge.globo.com/`);
    const $ = cheerio.load(response.data);
    const postagem = [];
    $(".bastian-feed-item").each((_, say) => {
      const titulo = $(say).find("h2").text().trim();
      const postado = $(say).find(".feed-post-datetime").text().trim();
      const img = $(say).find("img").attr("src");
      const link = $(say).find("a").attr("href");
      const noticia = $(say).find(".feed-post-body-resumo").text().trim();
      postagem.push({ titulo, img, link, postado, noticia });
    });
    return postagem;
  } catch (error) {
    console.error(error);
  }
};

const g1 = async () => {
  try {
    const response = await axios.get(`https://g1.globo.com/`);
    const $ = cheerio.load(response.data);
    const postagem = [];
    $(".bastian-feed-item").each((_, say) => {
      const noticia = $(say).find("p").text().trim();
      const postado = $(say).find(".feed-post-datetime").text();
      const img = $(say).find("img").attr("src");
      const link = $(say).find("a").attr("href");
      postagem.push({ img, link, postado, noticia });
    });
    return postagem;
  } catch (error) {
    console.error(error);
  }
};
module.exports = {toanime, pinterestVideo, tiktokSearch, pindl, animeshentaiPesquisa, igStalks, geminiAi, searchSpotify, pinterest_gif, facebook_video, spotifydl, filmes, cota, wikipedia, wikipediat, biblia, playstore, apkgara, signos, mangatodos, mangaspesquisa , animesonline, mangas, globosporte, tempo, g1,textmakers, wall4kpaper, memedroid, xvz,  hentaiword, hentaiGeral, igdl, geturl, pensador, styletext, getgrupos, gpwhatsapp, hentaistube, nerding, apkmodhacker, xvideos, uptodown, pornhub, soundl, st, gpsrc, dafontSearch, dafontDown, igstalk, ff, papeldeparede, htdl, xvideoss, xvideosdl, assistithtdl, assistitht, pornogratis, wallmob, pinterest, rastrear, ytdl, waifur, frasesanime, trevomangadl, trevomanga, hentaivids, Mangax, animeVideo, animeVideo2, ssweb, translate, tt, tiktokstalk, tkstalk, xvideosDown, xnxxDownload, xnxxPesquisa, scrapeZacaNoticias, scrapeDetalhesNoticia, scrapeAllVideos }

//xvideos('porno').then((data) => console.log(data))
