const express = require('express');
const router = express.Router();
const passport = require('passport');
const { getHashedPassword, randomText } = require('../func.backend/function');
const { verificaNome, gerarUsuario, verificaZap, checkVerify, verificarEmail } = require('../backend/db');
const mailer = require('../email/otpValidation');
const { notAuthenticated, captchaRegister, captchaLogin } = require('../func.backend/auth');
const { usuario } = require('../backend/modelagem');
const Recaptcha = require('express-recaptcha').RecaptchaV2;
const emailverificakkk = require('../email/email');

const recaptcha = new Recaptcha(recaptcha_key_1, recaptcha_key_2);

// Rota para renderizar a página de login
router.get('/', notAuthenticated, (req, res) => {
  res.render('login', { layout: 'login' });
});

// Rota para renderizar a página de login com reCAPTCHA
router.get('/entrar', notAuthenticated, recaptcha.middleware.render, (req, res) => {
  res.render('login', { recaptcha: res.recaptcha, layout: 'login' });
});

// Rota para processar login
router.post('/entrar',recaptcha.middleware.verify, captchaLogin,  async (req, res, next) => {
  const { username, password } = req.body;
  try {
    const user = await usuario.findOne({ nome_usuario: username }).exec();
    if (!user) {
      req.flash('error_msg', 'Esse nome de usuário não está registrado');
      return res.redirect('/i/entrar');
    }
    if (await checkVerify(username)) {
      req.flash('error_msg', 'ops, você ainda não verificou sua conta!, verifique nesta pagina colocando seu usuario');
      return res.redirect('/verifica');
    }
    passport.authenticate('local', {
      successRedirect: '/docs',
      failureRedirect: '/i/entrar',
      failureFlash: true,
    })(req, res, next);
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Erro ao fazer login');
    return res.redirect('/i/entrar');
  }
});

// Rota para renderizar a página de registro
router.get('/rg', notAuthenticated,recaptcha.middleware.render, (req, res) => {
  res.render('registro', { recaptcha: res.recaptcha, layout: 'registro' });
});

// Rota para processar registro
router.post('/rg', recaptcha.middleware.verify, captchaRegister, async (req, res) => {
  const { username, nomorWa, email, password, confirmPassword } = req.body;
  try {
    // Validação de dados
    if (username.length < 3) {
      req.flash('error_msg', 'O nome de usuário deve ter pelo menos 3 caracteres');
      return res.redirect('/i/rg');
    }
    if (password.length < 6 || confirmPassword.length < 6) {
      req.flash('error_msg', 'A senha deve ter pelo menos 6 caracteres');
      return res.redirect('/i/rg');
    }
    if (password !== confirmPassword) {
      req.flash('error_msg', 'As senhas não correspondem.');
      return res.redirect('/i/rg');
    }

    const usuarioExiste = await verificaNome(username);
    const verificaZaps = await verificaZap(nomorWa);
    const verificaEmail = await verificarEmail(email);

    if (usuarioExiste || verificaZaps || verificaEmail) {
      req.flash('error_msg', 'Já existe um usuário com a mesma conta');
      return res.redirect('/i/rg');
    }

    const hashedPassword = getHashedPassword(password);
    const apikey = randomText(10);
    const id = randomText(5);
    const linkid = `https://${req.hostname}/verificar/conta?id=${id}`;

    const mailDetails = {
      from: 'tohka.api@gmail.com',
      to: email,
      subject: 'Verifique sua conta',
      html: emailverificakkk.emailverifica(linkid),
    };

    // Descomente para enviar o e-mail
     mailer.mailTransporter.sendMail(mailDetails);

    gerarUsuario(username, hashedPassword, email, apikey, id, nomorWa, 'imgaqui');
    req.flash('success_msg', 'Cadastro concluído! Agora, só verificar sua caixa de spam no seu gmail e verificar a sua conta!');
    return res.redirect('/i/entrar');
  } catch (err) {
    console.log(err);
    req.flash('error_msg', 'Erro ao cadastrar');
    return res.redirect('/i/rg');
  }
});

// Rota para logout
router.get('/logout', (req, res) => {
  req.logout();
  req.flash('success _msg', 'Sucesso ao sair');
  res.redirect('/i/entrar');
});

module.exports = router;
