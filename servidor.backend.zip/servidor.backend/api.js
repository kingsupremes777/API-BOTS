const express = require('express')
const router = express.Router()
const fs = require('fs')

const { verificaKey, verificaLimit, verificaAll } = require('../backend/db')
const { getFile } = require('../func.backend/function')
const { cekUsername, cekRequest } = require('../backend/premium')


const {
waifu,
hentaiwordr,
hentaisrandoms,
animesrandoms,
animesonlines,
mangatds,
pesquisamanga,
frasesanimes,
pesquisamangatrevo,
dlmangatrevor,
mangxx,
animeStatus2,
animeStatus
} = require('../apis/anime')

const {
pubgv,
anonovo,
natalmsg,
trigrev,
areia,
tela,
blackpinkepo,
brotoluz,
balckpingv2,
borracha,
brilhante,
papel,
diabo,
urso,
blur,
vietnam,
crack,
goldt,
grafit4,
biscoito,
pig,
seta,
grafite
} = require('../apis/ephoto')


const {
shadowx,
stonex,
writez,
summerz,
wolfmetalz,
naturez,
rosesz,
naturetypoz,
quotesunderz,
shinez,
smokez,
lovez,
undergrassz,
doublelovez,
coffecupz,
underwaterz,
smokyneonz,
starsz,
raimbowz,
ballonz,
metallicez,
embroideryz,
flamingz
} = require('../apis/photooxy')


const { 
metadinha,
styletextR,
tempoagora,
igstalkk,
print,
tradutor,
tikstalk,
tkstalks,
donodozaps
} = require('../apis/ferramentas')
const { 
apkmodhack,
gpwhatsappR,
nerdingR,
uptodownR,
gpsrcR,
dafontSearchR,
ffR,
papeldeparedeR,
pin,
gpsale,
hentaistuber,
assistithtsrc,
pornhubsrc,
pornogratiss,
pensadorr,
xvds,
instastalk,
wallpp,
ytss,
bibliaa,
playstoree,
apkgaraa,
wiki,
googleimg,
cotacao,
film,
pingif,
spotifysrc,
tiktokpesquisa,
pinMp4,
xnxxPesquisaa,
animeshentaiPesquisaX,
PortalZacarias
} = require('../apis/pesquisa')
const {
tiktokdl,
twidl,
sounddl,
topdl,
threds,
topsrc,
mediafiredl,
igdlr,
spotifyplay,
ytmp3_2,
ytmp4_2,
playv_2,
play_2,
spotifys,
facebookvd,
ttk2,
pintdl,
igdl2,
xvideoDow,
xnxxDow,
PortalZacariasDlAll,
PortalZacariasDl
} = require('../apis/download')
const {
gethtml,
rastre,
imgig,
simis,
globoesportes,
g1s,
chatgpt,
blackbox,
dbsbot,
signo,
gemini
} = require('../apis/outros')

const { 
welcome,
goodbye,
comunismo,
bolsonaro,
bnw,
blurr,
affect,
beautiful,
circle,
del,
gay,
invert,
facepalm,
dither,
jail,
magik,
pixelate,
rip,
sepia,
rotate,
trash,
wanted,
wasted,
twitch, 
namoro,
levelup2,
menufy,
spotifyc,
cardrankz,
musicaz,
welgodby,
menudit,
zapd,
vasco,
menugif,
adoratv,
lolifofs,
lolifofss,
pcloli,
interro,
brasil,
editcanva,
carinhor,
menubysayoz,
editred,
editwite,
bemvdadeus,
bemvdadeus2,
menudioss,
ping
} = require('../apis/canvas')

const { 
ttp,
attp1r,
attp2r,
attp3r,
attp4r,
attp5r,
attp6r,
attp7r,
emojimix,
puxadatxt,
limetext,
logsFlame,
generatePhLogo
} = require('../apis/mysirv')


const {
ass,
hentai,
milf,
oral,
paizuri,
ecchi,
ero,
hentaimp4
} = require('../apis/hentai')

 router.get('/perfilz', async (req, res) => {
 let usuario = req.query.usuario
 if (!usuario) return res.status(400).send({ status: 400, message: 'coloque seu nome no parametro', rasultado: 'error' })
 let allperfil = await verificaAll(usuario)
 if (!allperfil) return res.status(404).send({ status: 404, message: `apikey ${apikey} não encontrada.` })
 res.status(200).send({ status: 200, message: 'on', resultado: {nome : allperfil.nome_usuario, numero: allperfil.numero_zap, status: allperfil.status, foto: allperfil.perfil, admin: allperfil.admin, limit: allperfil.limit, dinheiro: allperfil.dinheiro, totalreq: allperfil.totalreq, exp: allperfil.exp, nivel: allperfil.nivel, bronze: allperfil.bronze, prata: allperfil.prata, diamante: allperfil.diamante  }})
 })
 //anime
  router.get('/anime/frases', frasesanimes)
  router.get('/anime/trevomangas', pesquisamangatrevo)
 router.get('/anime/trevomangasdl', dlmangatrevor)
 router.get('/anime/waifu', waifu)
 router.get('/anime/animesonline', animesonlines)
 router.get('/anime/random', animesrandoms)         
 router.get('/anime/mangatds', mangatds)  
  router.get('/anime/manga', mangxx)  
 router.get('/anime/pesquisarmanga', pesquisamanga)  
 router.get('/anime/animestatus', animeStatus)  
 router.get('/anime/animestatus2', animeStatus2)  
 //hentai
 router.get('/hentai/random', hentaisrandoms)
 router.get('/hentai/hentaiword', hentaiwordr)
 router.get('/hentai/ass', ass)
 router.get('/hentai/hentai', hentai)
 router.get('/hentai/milf', milf)
 router.get('/hentai/oral', oral)
 router.get('/hentai/paizuri', paizuri)
 router.get('/hentai/ecchi', ecchi)
 router.get('/hentai/ero', ero)
 router.get('/hentai/mp4', hentaimp4)
 
 //attp => ttp

 //router.get('/maker/ttp', ttp)
 router.get('/maker/attp1', attp1r) 
 router.get('/maker/attp2', attp2r)  
 /*router.get('/maker/attp3', attp3r)  
 router.get('/maker/attp4', attp4r)  
 router.get('/maker/attp5', attp5r)   
 router.get('/maker/attp6', attp6r)    
 router.get('/maker/attp7', attp7r)     
 router.get('/maker/emojimix', emojimix)  
 router.get('/maker/puxadatxt', puxadatxt)   
 router.get('/maker/puxadatxt2', limetext) */

 //canvas
 router.get('/canvas/ping', ping)
 router.get('/canvas/menudios', menudioss)
 router.get('/canvas/bemvindod2', bemvdadeus2)
 router.get('/canvas/bemvindod', bemvdadeus)
 router.get('/canvas/menubysayo', menubysayoz)
 router.get('/canvas/carinho', carinhor)
 router.get('/canvas/editroxo', editcanva)
 router.get('/canvas/editvermelha', editred)
 router.get('/canvas/editbranca', editwite)
 router.get('/canvas/brasil', brasil)
 router.get('/canvas/interro', interro)
 router.get('/canvas/lolinopc', pcloli)
 router.get('/canvas/lolifofaa', lolifofss)
 router.get('/canvas/lolifofa', lolifofs)
 router.get('/canvas/adorartv', adoratv)
 router.get('/canvas/menuedit', menudit)   
 router.get('/canvas/vasco', vasco)  
 router.get('/canvas/perfilzap', zapd)   
 router.get('/canvas/bvgb', welgodby)
 router.get('/canvas/twitter', twitch)
 router.get('/canvas/namoro', namoro)
 router.get('/canvas/levelup', levelup2) 
 router.get('/canvas/menufy', menufy)  
 router.get('/canvas/spotify', spotifyc) 
 router.get('/canvas/rankz', cardrankz)  
 router.get('/canvas/musica', musicaz)   
 router.get('/canvas/welcome', welcome)
 router.get('/canvas/goodbye', goodbye)
 router.get('/canvas/comunismo', comunismo)  
 router.get('/canvas/bolsonaro', bolsonaro) 
 router.get('/canvas/bnw', bnw) 
 router.get('/canvas/affect', affect) 
 router.get('/canvas/blur', blurr) 
 router.get('/canvas/beautiful', beautiful)   
 router.get('/canvas/circle', circle) 
 router.get('/canvas/del', del) 
 router.get('/canvas/invert', invert) 
 router.get('/canvas/gay', gay) 
 router.get('/canvas/facepalm', facepalm)      
 router.get('/canvas/dither', dither) 
 router.get('/canvas/jail', jail) 
 router.get('/canvas/magik', magik) 
 router.get('/canvas/rip', rip)   
 router.get('/canvas/sepia', sepia) 
 router.get('/canvas/rotate', rotate) 
 router.get('/canvas/pixelate', pixelate) 
 router.get('/canvas/trash', trash) 
 router.get('/canvas/wasted', wasted)
 router.get('/canvas/wanted', wanted)
 
 //especial
 router.get('/especial/getsource', gethtml)    
 //outros
  router.get('/dbs', dbsbot)
 router.get('/outros/gemini', gemini)
  router.get('/outros/waifu', imgig)
  router.get('/outros/globoesportes', globoesportes)
  router.get('/outros/chatgpt', chatgpt)
 router.get('/outros/blackbox', blackbox)
  router.get('/outros/g1', g1s)  
  router.get('/outros/signos', signo)  
 router.get('/outros/rastrear/shoppee', rastre)    

PortalZacariasDlAll,
PortalZacariasDl

//download
 router.get('/dl/PortalZacariasDlAll', PortalZacariasDlAll) 
 router.get('/dl/PortalZacariasDl', PortalZacariasDl) 
 router.get('/dl/tiktok2', ttk2) 
 router.get('/dl/pinterest', pintdl) 
 router.get('/dl/play2', play_2) 
 router.get('/dl/playv2', playv_2) 
 router.get('/dl/ytmp3v2', ytmp3_2) 
 router.get('/dl/ytmp4v2', ytmp4_2)
 router.get('/dl/xvideos', xvideoDow)
  router.get('/dl/xnxx', xnxxDow)
 router.get('/dl/play', spotifyplay) 
 router.get('/dl/tiktok', tiktokdl) 
 router.get('/dl/twitter', twidl)  
 router.get('/dl/spotify', spotifys)  
 router.get('/dl/facebookvideo', facebookvd) 
 router.get('/dl/topflix', topdl)    
 router.get('/dl/mediafire', mediafiredl)          
 router.get('/dl/igdl', igdlr)
 router.get('/dl/threads', threds)
 router.get('/dl/igdl2', igdl2)
 router.get('/dl/soundcloud', sounddl) 

 router.get('/logos/logo', logsFlame)
 router.get('/logos/pornhub', generatePhLogo)
 
//photooxy
 router.get('/photooxy/shadow', shadowx)
 router.get('/photooxy/stone', stonex)
 router.get('/photooxy/write', writez)
 router.get('/photooxy/summer', summerz)
 router.get('/photooxy/wolfmetal', wolfmetalz)
 router.get('/photooxy/nature', naturez)
 router.get('/photooxy/roses', rosesz) 
 router.get('/photooxy/naturetypo', naturetypoz)  
 router.get('/photooxy/quotesunder', quotesunderz)   
 router.get('/photooxy/shine', shinez)
 router.get('/photooxy/smoke', smokez)
 router.get('/photooxy/undergrass', undergrassz)
 router.get('/photooxy/doublelove', doublelovez)
 router.get('/photooxy/coffecup', coffecupz)
 router.get('/photooxy/underwater', underwaterz)
 router.get('/photooxy/love', lovez)
 router.get('/photooxy/smokyneon', smokyneonz)
 router.get('/photooxy/stars', starsz)
 router.get('/photooxy/raimbow', raimbowz)
 router.get('/photooxy/ballon', ballonz)  
 router.get('/photooxy/metallice', metallicez)
 router.get('/photooxy/embroidery', embroideryz)
 router.get('/photooxy/flaming', flamingz)

// Textpro
 
// router.get('/textpro/candy', candyT)
 
 //ephoto
  router.get('/ephoto/pubgv', pubgv)
  router.get('/ephoto/anonovo', anonovo)  
  router.get('/ephoto/trigrev', trigrev)  
  router.get('/ephoto/areia', areia)  
  router.get('/ephoto/tela', tela)  
  router.get('/ephoto/blackpinkepo', blackpinkepo)  
  router.get('/ephoto/brotoluz', brotoluz)  
  router.get('/ephoto/balckpingv2', balckpingv2)  
  router.get('/ephoto/borracha', borracha)  
  router.get('/ephoto/brilhante', brilhante)  
  router.get('/ephoto/papel', papel)  
  router.get('/ephoto/diabo', diabo)                    
  router.get('/ephoto/urso', urso)  
  router.get('/ephoto/blur', blur)  
  router.get('/ephoto/vietnam', vietnam)  
  router.get('/ephoto/crack', crack)  
  router.get('/ephoto/goldt', goldt)  
  router.get('/ephoto/grafit4', grafit4)  
  router.get('/ephoto/biscoito', biscoito)  
  router.get('/ephoto/pig', pig)  
  router.get('/ephoto/seta', seta)  
  router.get('/ephoto/grafite', grafite)      
 
 //ferramentas
 router.get('/ferramenta/donodozap', donodozaps)
 router.get('/ferramenta/metadinha', metadinha)
 router.get('/ferramenta/stilodetxt', styletextR)
 router.get('/ferramenta/simisim', simis)
 router.get('/ferramenta/tempo', tempoagora)
 router.get('/ferramenta/igstalk', igstalkk)
 router.get('/ferramenta/tiktokstalk', tikstalk)
 router.get('/ferramenta/print', print)
 router.get('/ferramenta/tradutor', tradutor)
 router.get('/ferramenta/tkstalk', tkstalks)
 //pesquisa
router.get('/pesquisa/portalzacarias', PortalZacarias) 
router.get('/pesquisa/xnxx', xnxxPesquisaa)
router.get('/pesquisa/tiktok', tiktokpesquisa) 
router.get('/pesquisa/spotify', spotifysrc)
router.get('/pesquisa/filme', film)
router.get('/pesquisa/cotacao', cotacao)
router.get('/pesquisa/gimg', googleimg)
router.get('/pesquisa/wiki', wiki)
router.get('/pesquisa/yt', ytss)
router.get('/pesquisa/wallpaper', wallpp)
router.get('/pesquisa/xvideos', xvds)
router.get('/pesquisa/apkmodhack', apkmodhack)
router.get('/pesquisa/gpwhatsapp', gpwhatsappR)
router.get('/pesquisa/nerding', nerdingR)
router.get('/pesquisa/uptodown', uptodownR)
router.get('/pesquisa/gpsrc', gpsrcR)
router.get('/pesquisa/dafontSearch', dafontSearchR)
router.get('/pesquisa/papeldeparede', papeldeparedeR)
router.get('/pesquisa/topflix', topsrc)  
router.get('/pesquisa/pinterest', pin)  
router.get('/pesquisa/pinterestgif', pingif)
router.get('/pesquisa/pinterestvideo', pinMp4)
router.get('/pesquisa/randomgp', gpsale)  
router.get('/pesquisa/hentaistuber', hentaistuber)
router.get('/pesquisa/assistirhentai', assistithtsrc)  
router.get('/pesquisa/pornhubsrc', pornhubsrc)  
router.get('/pesquisa/pornogratis', pornogratiss)  
router.get('/pesquisa/pensador', pensadorr)   
router.get('/pesquisa/biblia', bibliaa)  
router.get('/pesquisa/playstore', playstoree) 
router.get('/pesquisa/apkgara', apkgaraa) 
router.get('/pesquisa/animeshentai', animeshentaiPesquisaX) 


 router.get('/toFile', async(req, res) => {
 let url = req.query.url 
 const buffer = await getFile(url)
 fs.writeFileSync(__path+ `/tmp/temp.${buffer.ext}`, buffer.data)
 res.sendFile(__path+ `/tmp/temp.${buffer.ext}`)
 })
 
 
router.use(function (req, res, next) {
if (res.statusCode == '200') {
 res.render('404', {
 layout: '404'
})
 }
})
router.use(function (req, res, next) {
if (res.statusCode == '400') {
 res.render('ErroLink', {
 layout: 'ErroLink'
})
 }
})

module.exports = router
