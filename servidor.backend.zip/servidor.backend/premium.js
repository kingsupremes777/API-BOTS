const express = require('express');
const router = express.Router();

const { verificaNome, resetarAllLimit, resetTodayReq, banir, desbanir, checkBanimento, addcodiguin, enviar_email, verificarEmailv2 } = require('../backend/db');
const { adicionar_premium, deletar_premium, checkPremium, changeKey, resetOneLimit, setperfil, setmusica } = require('../backend/premium');
const { isAuthenticated } = require('../func.backend/auth');
const { randomText } = require('../func.backend/function');
const multer = require('multer');
const fs = require('fs')
const path = require('path');
const { getBuffer, getRandom } = require("../func.backend/buff");

function makeid(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() *
            charactersLength));
    }
    return result;
}

const codigogerado = randomText(4);

const storage = multer.diskStorage({
    destination: 'public/file',
    filename: (req, file, cb) => {
        cb(null, makeid(5) +
            path.extname(file.originalname))
    }
});

const upload = multer({
    storage,
    limits: {
        fileSize: 5000000 // 100 MB
    }
})

// Rota para adicionar premium
router.post('/add', isAuthenticated, async (req, res) => {
    try {
        let { username, expired, customKey, token } = req.body;
        if (token !== tokens) {
            req.flash('error_msg', 'Token inválido');
            return res.redirect('/admin');
        }
        let checking = await verificaNome(username);
        if (!checking) {
            req.flash('error_msg', 'O nome de usuário não está registrado');
            return res.redirect('/admin');
        } else {
            let checkPrem = await checkPremium(username)
            if (checkPrem) {
                req.flash('error_msg', 'Este usuário já tem Premium');
                return res.redirect('/admin');
            } else {
                let checkMail = await verificarEmailv2(username)
                adicionar_premium(username, customKey, expired)
                enviar_email(`parabéns ${username} agora você e um usuário premium 👏\n\nDIAS: ${expired}`, checkMail).then((res) => console.log(res)).catch((err) => console.log(err))
                req.flash('success_msg', `Premium adicionado para ${username} com sucesso`);
                return res.redirect('/admin');
            }
        }
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Erro ao adicionar premium');
        return res.redirect('/admin');
    }
})

// Rota para deletar premium
router.post('/delete', isAuthenticated, async (req, res) => {
    try {
        let { username, token } = req.body;
        if (token !== tokens) {
            req.flash('error_msg', 'Token inválido');
            return res.redirect('/admin');
        }
        let checking = await verificaNome(username);
        if (!checking) {
            req.flash('error_msg', 'Este usuário não está registrado');
            return res.redirect('/admin');
        } else {
            let checkPrem = await checkPremium(username)
            if (checkPrem) {
                deletar_premium(username);
                let checkMail = await verificarEmailv2(username)
                enviar_email(`${username} seu premium foi deletado pelo administrador`, checkMail).then((res) => console.log(res)).catch((err) => console.log(err))
                req.flash('success_msg', `Premium de ${username} foi deletado`);
                return res.redirect('/admin');
            } else {
                req.flash('error_msg', 'Este usuário não tem Premium');
                return res.redirect('/admin');
            }
        }
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Erro ao deletar premium');
        return res.redirect('/admin');
    }
})

// Rota para gerar código
router.post('/codiguin', isAuthenticated, async (req, res) => {
    try {
        let { username, valorcode, token } = req.body;
        if (token !== tokens) {
            req.flash('error_msg', 'Token inválido');
            return res.redirect('/admin');
        }
        let checking = await verificaNome(username);
        if (!checking) {
            req.flash('error_msg', 'Este usuário não está registrado');
            return res.redirect('/admin');
        } else {
            let checkMail = await verificarEmailv2(username)
            enviar_email(`${username} parabéns você recebeu um código promocional no valor de ${valorcode} de dinheiro, resgate ele o quanto antes\n\nCÓDIGO: ${codigogerado}\npara resgatá-lo entre aqui: https://tohka.tech/resgatar`, checkMail)
            addcodiguin(username, codigogerado, valorcode)
            req.flash('success_msg', `Código gerado com sucesso, código para resgatá-lo ${codigogerado} envie para o comprador resgatar.`);
            return res.redirect('/admin');
        }
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Erro ao gerar código');
        return res.redirect('/admin');
    }
})

// Rota para banir usuário
router.post('/banir', isAuthenticated, async (req, res) => {
    try {
        let { username, expired, token, motivo } = req.body;
        if (token !== tokens) {
            req.flash('error_msg', 'Token inválido');
            return res.redirect('/admin');
        }
        let checking = await verificaNome(username);
        if (!checking) {
            req.flash('error_msg', 'O nome de usuário não está registrado');
            return res.redirect('/admin');
        } else {
            let checkBan = await checkBanimento(username)
            if (checkBan) {
                req.flash('error_msg', 'Este usuário já esta banido');
                return res.redirect('/admin');
            } else {
                banir(username, expired, motivo)
                let checkMail = await verificarEmailv2(username)
                enviar_email(`${username} sua conta foi baninda por desrespeitar nossas leis!, motivo do Banimento:\n\n${motivo}`, checkMail)
                req.flash('success_msg', `A conta de ${username} foi banida com sucesso`);
                return res.redirect('/admin');
            }
        }
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Erro ao banir usuário');
        return res.redirect('/admin');
    }
})

// Rota para desbanir usuário
router.post('/desbanir', isAuthenticated, async (req, res) => {
    try {
        let { username, token } = req.body;
        if (token !== tokens) {
            req.flash('error_msg', 'Token inválido');
            return res.redirect('/admin');
        }
        let checking = await verificaNome(username);
        if (!checking) {
            req.flash('error_msg', 'O nome de usuário não está registrado');
            return res.redirect('/admin');
        } else {
            let checkBan = await checkBanimento(username)
            if (!checkBan) {
                req.flash('error_msg', 'Este usuário não esta banido');
                return res.redirect('/admin');
            } else {
                desbanir(username)
                let checkMail = await verificarEmailv2(username)
                enviar_email(`${username} parabéns  sua conta foi desbanida por um dos nossos administradores!`, checkMail)
                req.flash('success_msg', `A conta de ${username} foi desbanida com sucesso`);
                return res.redirect('/admin');
            }
        }
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Erro ao desbanir usuário');
        return res.redirect('/admin');
    }
})

// Rota para customizar apikey
router.post('/custom', isAuthenticated, async (req, res) => {
    try {
        let { customKey } = req.body;
        let { nome_usuario, numero_zap, email } = req.user
        let checkPrem = await checkPremium(nome_usuario);
        if (checkPrem) {
            changeKey(nome_usuario, customKey)
            req.flash('success_msg', `Sua apikey foi customizada para ${customKey}`);
            enviar_email(`❗ _APIKEY_ ❗\n\n Olá ${nome_usuario} você acabou de alterar sua apikey para : ${customKey}\n\n\npor ventura não foi você que mudou, contate algum administrador do site`, email)
            res.redirect('/perfil');
        } else {
            req.flash('error_msg', 'Você não é um usuário premium');
            res.redirect('/perfil');
        }
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Erro ao customizar apikey');
        res.redirect('/perfil');
    }
})

// Rota para customizar perfil
router.post('/setperfil', isAuthenticated, upload.single('file'), async (req, res) => {
    try {
        let { img } = req.body;
        let { nome_usuario, numero_zap, email } = req.user
        let checkPrem = await checkPremium(nome_usuario);
        if (checkPrem) {
            try {
                buffz = await getBuffer("https://" + req.hostname + "/file/" + req.file.filename)
                ran = getRandom('.jpg')
                await fs.writeFileSync(ran, buffz)
                setperfil(nome_usuario, buffz)
                req.flash('success_msg', `Sua foto de perfil foi customizada!`);
                enviar_email(`❗ _FOTO_ ❗\n\n Olá ${nome_usuario} você acabou de alterar sua foto de perfil!\n\n\npor ventura não foi você que mudou, contate algum administrador do site`, email)
                res.redirect('/perfil');
            } catch (err) {
                req.flash('success_msg', `arquivo não compatível`);
                return res.redirect('/perfil');
            }
        } else {
            req.flash('error_msg', 'Você não é um usuário premium');
            res.redirect('/perfil');
        }
        fs.unlinkSync(ran)
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Erro ao customizar perfil');
        res.redirect('/perfil');
    }
})

// Rota para customizar música
router.post('/setmusica', isAuthenticated, async (req, res) => {
    try {
        let { music } = req.body;
        let { nome_usuario, numero_zap, email } = req.user
        let checkPrem = await checkPremium(nome_usuario);
        if (checkPrem) {
            setmusica(nome_usuario, music)
            req.flash('success_msg', `Sua música foi customizada!`);
            enviar_email(`❗ _MÚSICA_ ❗\n\n Olá ${nome_usuario} você acabou de alterar sua música\n\n\npor ventura não foi você que mudou, contate algum administrador do site`, email)
            res.redirect('/perfil');
        } else {
            req.flash('error_msg', 'Você não é um usuário premium');
            res.redirect('/perfil');
        }
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Erro ao customizar música');
        res.redirect('/perfil');
    }
})

// Rota para resetar limite
router.post('/limit', isAuthenticated, async (req, res) => {
    try {
        let { username, token } = req.body;
        if (token !== tokens) {
            req.flash('error_msg', 'Token inválido');
            return res.redirect('/admin');
        }
        let reset = await checkPremium(username);
        if (!reset) {
            resetOneLimit(username)
            req.flash('success_msg', `A apikey do usuário ${username} foi resetada com sucesso para ${limitOfc}`);
            res.redirect('/admin');
        } else {
            req.flash('error_msg', 'Você não pode resetar uma apikey premium');
            res.redirect('/admin');
        }
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Erro ao resetar limite');
        return res.redirect('/admin');
    }
})

// Rota para resetar todos os limites
router.post('/resetall', isAuthenticated, async (req, res) => {
    try {
        let { token } = req.body;
        if (token !== tokens) {
            req.flash('error_msg', 'Token inválido');
            return res.redirect('/admin');
        } else {
            resetarAllLimit(); 
            resetTodayReq();
            req.flash('success_msg', `limit de todas as apikey foram redefinidos com sucesso`);
            return res.redirect('/admin');
        }
    } catch (err) {
        console.error(err);
        req.flash('error_msg', 'Erro ao resetar todos os limites');
        return res.redirect('/admin');
    }
})

module.exports = router;
