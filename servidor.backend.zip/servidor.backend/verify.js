const express = require('express');
const router = express.Router();

const { notAuthenticated } = require('../func.backend/auth');
const { verifyUser  } = require('../backend/db');

// Rota para redirecionar para a página de login
router.get('/', notAuthenticated, (req, res) => {
  res.redirect('/i/entrar');
});

// Rota para verificar a conta do usuário
router.get('/conta', notAuthenticated, async (req, res, next) => {
  try {
    const id = req.query.id;
    if (!id) {
      req.flash('error_msg', 'ID não fornecido');
      return res.redirect('/i/entrar');
    }

    const check = await verifyUser (id);
    if (!check) {
      req.flash('error_msg', 'Falhou! Talvez o ID não esteja correto.');
      return res.redirect('/i/entrar');
    }

    req.flash('success_msg', 'Parabéns! Sua conta foi verificada. Agora você pode fazer login');
    return res.redirect('/i/entrar');
  } catch (err) {
    console.error(err);
    req.flash('error_msg', 'Erro ao verificar a conta');
    return res.redirect('/i/entrar');
  }
});

module.exports = router;
