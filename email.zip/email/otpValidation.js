const nodemailer = require('nodemailer');

module.exports={
    mailTransporter: nodemailer.createTransport({
        service: "gmail",
        auth: {
            user:"tohka.api@gmail.com",
            pass: "slub lqaa nuty gldt"
        },
    }), 
      
    //  OTP : `${Math.floor(1000 + Math.random() * 9000)}`,

}